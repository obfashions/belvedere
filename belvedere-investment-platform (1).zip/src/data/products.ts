/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'bel_pure',
    name: 'Belvedere Pure Elegance',
    price: 15000,
    cycleDays: 30,
    dailyReturnPercent: 16.67, // Yields ~2500 UGX daily
    dailyEarnings: 2500,
    totalEarnings: 75000,
    roi: 500,
    imageUrl: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=800&q=80',
    description: 'Our signature ultra-premium rye vodka. Crafted from Polish rye and purified water, distilled by fire for a crisp, noble finish.'
  },
  {
    id: 'bel_intense',
    name: 'Belvedere Midnight Intense',
    price: 30000,
    cycleDays: 30,
    dailyReturnPercent: 17.33, // Yields ~5200 UGX daily
    dailyEarnings: 5200,
    totalEarnings: 156000,
    roi: 520,
    imageUrl: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80',
    description: 'Distilled at a higher proof to accentuate premium spices and rich cocoa notes. Designed for elite beverage curators.'
  },
  {
    id: 'bel_citrus',
    name: 'Belvedere Organic Citrus',
    price: 70000,
    cycleDays: 30,
    dailyReturnPercent: 18.00, // Yields ~12600 UGX daily
    dailyEarnings: 12600,
    totalEarnings: 378000,
    roi: 540,
    imageUrl: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80',
    description: 'Infused with organic lemon, lime, and Mediterranean citrus peels for a refreshingly bright and crisp luxury taste.'
  },
  {
    id: 'bel_bart_lake',
    name: 'Belvedere Lake Bartężek Single Rye',
    price: 100000,
    cycleDays: 30,
    dailyReturnPercent: 18.50, // Yields ~18500 UGX daily
    dailyEarnings: 18500,
    totalEarnings: 555000,
    roi: 555,
    imageUrl: 'https://images.unsplash.com/photo-1560512823-829485b8bf24?auto=format&fit=crop&w=800&q=80',
    description: 'Crafted with rare Diamond Dankowskie rye grown on the shores of Lake Bartężek, offering clean, fresh, and nutty notes.'
  },
  {
    id: 'bel_smog_forest',
    name: 'Belvedere Smogóry Forest Single Rye',
    price: 150000,
    cycleDays: 30,
    dailyReturnPercent: 19.00, // Yields ~28500 UGX daily
    dailyEarnings: 28500,
    totalEarnings: 855000,
    roi: 570,
    imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80',
    description: 'Made from rye grown in Poland\'s heavily forested Smogóry region, highlighting bold, savory, toasted caramel tones.'
  },
  {
    id: 'bel_heritage_176',
    name: 'Belvedere Heritage 176 Malted',
    price: 300000,
    cycleDays: 35,
    dailyReturnPercent: 20.00, // Yields ~60000 UGX daily
    dailyEarnings: 60000,
    totalEarnings: 2100000,
    roi: 700,
    imageUrl: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80',
    description: 'A blend of neutral spirit and rye malt distillate, unlocking ancient malting secrets of Polish distillers.'
  },
  {
    id: 'bel_bespoke_gold',
    name: 'Belvedere Bespoke Imperial Gold',
    price: 500000,
    cycleDays: 35,
    dailyReturnPercent: 21.00, // Yields ~105000 UGX daily
    dailyEarnings: 105000,
    totalEarnings: 3675000,
    roi: 735,
    imageUrl: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187?auto=format&fit=crop&w=800&q=80',
    description: 'Housed in a custom metallic gold luminescent bottle, representing the ultimate apex of bespoke luxury distilling.'
  },
  {
    id: 'bel_luminous_royal',
    name: 'Belvedere Luminous Royal Reserve',
    price: 1000000,
    cycleDays: 40,
    dailyReturnPercent: 23.00, // Yields ~230000 UGX daily
    dailyEarnings: 230000,
    totalEarnings: 9200000,
    roi: 920,
    imageUrl: 'https://images.unsplash.com/photo-1551538827-9c037cb4f32a?auto=format&fit=crop&w=800&q=80',
    description: 'The crowning jewel of the Belvedere estate. Distilled to perfection and aged in premium oak casks for royal collectors.'
  }
];

export const DEFAULT_ANNOUNCEMENTS = [
  {
    id: 'ann_welcome',
    title: 'Welcome to BELVEDERE Investment Platform!',
    content: 'All new members receive UGX 5,000 automatically in their registration account! Share your invitation links to earn 25% Level 1, 3% Level 2, and 2% Level 3 direct network commission instantly. Let us toast to secure, premium, long-term beverage assets.',
    isPinned: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'ann_pwa',
    title: 'Secure PWA Android App Installation is Live',
    content: 'Install the official BELVEDERE Platform directly from Google Chrome on your Android device. Simply press "Add to Home Screen" or the install icon in the search bar to enjoy lightning-fast access, native notifications, and a highly polished full-screen experience.',
    isPinned: false,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString()
  },
  {
    id: 'ann_lworx',
    title: 'Payment Integration System (LWorx-Pay Ready)',
    content: 'We have fully prepared the infrastructure to support LWorx-Pay automatic recharges and withdrawals. Our technical integration team is configuring the payment APIs to enable instant MTN & Airtel Mobile Money cashouts. Check the Payout and Recharge forms for testing instructions!',
    isPinned: false,
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString()
  }
];

export const DEFAULT_GIFT_CODES = [
  {
    id: 'gift_pure',
    code: 'BELVPURE',
    rewardAmount: 10000,
    usageLimit: 100,
    usageCount: 0,
    claimedBy: [],
    createdAt: new Date().toISOString()
  },
  {
    id: 'gift_royal',
    code: 'BELVROYAL',
    rewardAmount: 25000,
    usageLimit: 50,
    usageCount: 0,
    claimedBy: [],
    createdAt: new Date().toISOString()
  }
];

export const SPIN_REWARDS = [
  { id: 'spin_1', name: 'UGX 1,000 Cash', type: 'cash', value: 1000, probability: 0.35, color: '#0f2042' },
  { id: 'spin_2', name: 'UGX 5,000 Cash', type: 'cash', value: 5000, probability: 0.20, color: '#1a365d' },
  { id: 'spin_3', name: 'UGX 10,000 Cash', type: 'cash', value: 10000, probability: 0.10, color: '#2b4c7e' },
  { id: 'spin_4', name: 'Belvedere Pure Elegance', type: 'product', value: 15000, probability: 0.05, color: '#b89d4d' }, // Free Plan
  { id: 'spin_5', name: 'UGX 500 Bonus', type: 'cash', value: 500, probability: 0.20, color: '#132c56' },
  { id: 'spin_6', name: 'Try Your Luck Again', type: 'none', value: 0, probability: 0.10, color: '#09152b' }
];

export const MOCK_NAMES = [
  'Joseph K.', 'Grace A.', 'Moses O.', 'Sarah N.', 'David M.', 'Florence K.', 'Peter S.',
  'Teddy N.', 'Alex B.', 'Cissy A.', 'John B.', 'Mariam N.', 'Ronald O.', 'Esther M.',
  'Emmanuel K.', 'Shaban N.', 'Jane O.', 'Richard K.', 'Paul M.', 'Sula O.', 'Prossy K.'
];
