/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { 
  User, 
  Product, 
  Investment, 
  Transaction, 
  SupportTicket, 
  TicketReply,
  Announcement, 
  GiftCode, 
  LiveActivity, 
  SpinReward 
} from '../types';
import { 
  INITIAL_PRODUCTS, 
  DEFAULT_ANNOUNCEMENTS, 
  DEFAULT_GIFT_CODES, 
  SPIN_REWARDS, 
  MOCK_NAMES 
} from '../data/products';
import { 
  checkSupabaseStatus, 
  loadAllDataFromSupabase,
  dbSaveUser,
  dbDeleteUser,
  dbSaveInvestment,
  dbSaveTransaction,
  dbSaveTicket,
  dbSaveAnnouncement,
  dbSaveGiftCode,
  dbSaveProduct,
  dbDeleteProduct,
  exportLocalDataToSupabase
} from '../lib/supabase-sync';

interface StateContextType {
  users: User[];
  currentUser: User | null;
  products: Product[];
  investments: Investment[];
  transactions: Transaction[];
  tickets: SupportTicket[];
  announcements: Announcement[];
  giftCodes: GiftCode[];
  liveActivities: LiveActivity[];
  spinTicketsCount: number;
  timeOffsetHours: number; // For fast forwarding time
  supabaseStatus: {
    connected: boolean;
    missingTables: string[];
    message: string;
  };
  triggerExportToSupabase: () => Promise<{ success: boolean; message: string }>;
  refreshSupabaseStatus: () => Promise<void>;
  register: (phone: string, password: string, confirmPassword: string, refCode?: string) => { success: boolean; error?: string };
  login: (phone: string, password: string) => { success: boolean; error?: string };
  logout: () => void;
  purchaseProduct: (productId: string) => { success: boolean; error?: string };
  rechargeAccount: (amount: number, method: string, phone: string) => Promise<{ success: boolean; error?: string; live?: boolean; message?: string }>;
  withdrawAccount: (amount: number, paymentMethod: string, phone: string) => Promise<{ success: boolean; error?: string; live?: boolean; message?: string }>;
  claimGift: (code: string) => { success: boolean; error?: string; reward?: number };
  collectEarnings: () => { success: boolean; error?: string; amount?: number };
  claimDailySalary: (amount: number) => { success: boolean; error?: string; amount?: number };
  spinWheel: () => { success: boolean; error?: string; reward?: SpinReward };
  createTicket: (subject: string, message: string) => { success: boolean; error?: string };
  replyToTicket: (ticketId: string, message: string, sender: 'user' | 'admin') => { success: boolean; error?: string };
  fastForward24Hours: () => void;
  // Admin functions
  adminUpdateUserBalance: (userId: string, amount: number) => { success: boolean; error?: string };
  adminToggleUserFreeze: (userId: string) => void;
  adminDeleteUser: (userId: string) => void;
  adminResetUserPassword: (userId: string, newPass: string) => { success: boolean };
  adminCreateProduct: (product: Omit<Product, 'id' | 'dailyEarnings' | 'totalEarnings' | 'roi'>) => void;
  adminDeleteProduct: (productId: string) => void;
  adminUpdateTransactionStatus: (txId: string, status: 'completed' | 'rejected') => void;
  adminCreateGiftCode: (code: string, reward: number, limit: number) => void;
  adminCreateAnnouncement: (title: string, content: string, isPinned: boolean) => void;
  adminAddTicketReply: (ticketId: string, message: string) => void;
  adminUpdateProduct: (productId: string, product: Partial<Omit<Product, 'id'>>) => void;
  whatsappLink: string;
  adminUpdateWhatsappLink: (link: string) => void;
  wineBannerUrl: string;
  adminUpdateWineBannerUrl: (url: string) => void;
  adminToggleFreezeUser: (userId: string) => { success: boolean };
  adminApproveTransaction: (txId: string, status: 'completed' | 'rejected') => { success: boolean };
  adminAddProduct: (product: Omit<Product, 'id' | 'dailyEarnings' | 'totalEarnings' | 'roi'>) => { success: boolean; error?: string };
  adminAddAnnouncement: (title: string, content: string) => { success: boolean; error?: string };
  adminDeleteAnnouncement: (annId: string) => { success: boolean };
  adminAddGiftCode: (code: string, reward: number, limit: number) => { success: boolean; error?: string };
  adminDeleteGiftCode: (code: string) => { success: boolean };
  dailySignIn: () => { success: boolean; error?: string; reward?: number };
}

const StateContext = createContext<StateContextType | undefined>(undefined);

export const StateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // --- Core State Backed by localStorage ---
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('bel_users');
    if (saved) return JSON.parse(saved);
    // Create seed admin user
    const seedAdmin: User = {
      id: 'admin_1',
      phone: '777000111',
      countryCode: '+256',
      balance: 1000000,
      incomeBalance: 250000,
      rechargeAmount: 500000,
      withdrawAmount: 0,
      dailyEarnings: 0,
      referralEarnings: 0,
      teamEarnings: 0,
      totalRevenue: 1250000,
      referralCode: 'ADMIN7',
      isFrozen: false,
      isAdmin: true,
      level1Count: 0,
      level2Count: 0,
      level3Count: 0,
      createdAt: new Date().toISOString()
    };
    // Create official admin user with phone 762201984
    const seedAdminOfficial: User = {
      id: 'admin_official',
      phone: '762201984',
      countryCode: '+256',
      balance: 1500000,
      incomeBalance: 400000,
      rechargeAmount: 800000,
      withdrawAmount: 0,
      dailyEarnings: 0,
      referralEarnings: 0,
      teamEarnings: 0,
      totalRevenue: 1900000,
      referralCode: 'BELADMIN',
      isFrozen: false,
      isAdmin: true,
      level1Count: 0,
      level2Count: 0,
      level3Count: 0,
      createdAt: new Date().toISOString()
    };
    return [seedAdmin, seedAdminOfficial];
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('bel_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('bel_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [investments, setInvestments] = useState<Investment[]>(() => {
    const saved = localStorage.getItem('bel_investments');
    return saved ? JSON.parse(saved) : [];
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('bel_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [tickets, setTickets] = useState<SupportTicket[]>(() => {
    const saved = localStorage.getItem('bel_tickets');
    return saved ? JSON.parse(saved) : [];
  });

  const [announcements, setAnnouncements] = useState<Announcement[]>(() => {
    const saved = localStorage.getItem('bel_announcements');
    return saved ? JSON.parse(saved) : DEFAULT_ANNOUNCEMENTS;
  });

  const [giftCodes, setGiftCodes] = useState<GiftCode[]>(() => {
    const saved = localStorage.getItem('bel_gift_codes');
    return saved ? JSON.parse(saved) : DEFAULT_GIFT_CODES;
  });

  const [spinTicketsCount, setSpinTicketsCount] = useState<number>(() => {
    const saved = localStorage.getItem('bel_spin_tickets');
    return saved ? parseInt(saved, 10) : 3;
  });

  const [timeOffsetHours, setTimeOffsetHours] = useState<number>(() => {
    const saved = localStorage.getItem('bel_time_offset');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [liveActivities, setLiveActivities] = useState<LiveActivity[]>([]);

  const [whatsappLink, setWhatsappLink] = useState<string>(() => {
    return localStorage.getItem('bel_whatsapp_link') || 'https://chat.whatsapp.com/LhB27z9oI9b8v2yG8X';
  });

  const [wineBannerUrl, setWineBannerUrl] = useState<string>(() => {
    return localStorage.getItem('bel_wine_banner_url') || 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1200&q=80';
  });

  // --- Supabase Synchronization State & Operations ---
  const isInitialLoaded = useRef(false);
  const [supabaseStatus, setSupabaseStatus] = useState<{
    connected: boolean;
    missingTables: string[];
    message: string;
  }>({
    connected: false,
    missingTables: [],
    message: 'Initializing Supabase connection...'
  });

  const refreshSupabaseStatus = async () => {
    try {
      const status = await checkSupabaseStatus();
      setSupabaseStatus(status);
      if (status.connected && status.missingTables.length === 0) {
        const data = await loadAllDataFromSupabase();
        
        // Populate local states with live Supabase data if tables are defined and contain rows
        if (data.users && data.users.length > 0) {
          setUsers(data.users);
        }
        if (data.products && data.products.length > 0) {
          setProducts(data.products);
        }
        if (data.investments && data.investments.length > 0) {
          setInvestments(data.investments);
        }
        if (data.transactions && data.transactions.length > 0) {
          setTransactions(data.transactions);
        }
        if (data.tickets && data.tickets.length > 0) {
          setTickets(data.tickets);
        }
        if (data.announcements && data.announcements.length > 0) {
          setAnnouncements(data.announcements);
        }
        if (data.giftCodes && data.giftCodes.length > 0) {
          setGiftCodes(data.giftCodes);
        }

        // Keep active session aligned
        const savedCurrUser = localStorage.getItem('bel_current_user');
        if (savedCurrUser && data.users) {
          const parsed = JSON.parse(savedCurrUser) as User;
          const fresh = data.users.find(u => u.id === parsed.id);
          if (fresh) {
            setCurrentUser(fresh);
          }
        }
      }
    } catch (e) {
      console.error('Error refreshing Supabase status:', e);
    } finally {
      isInitialLoaded.current = true;
    }
  };

  const triggerExportToSupabase = async () => {
    return await exportLocalDataToSupabase({
      users,
      products,
      investments,
      transactions,
      tickets,
      announcements,
      giftCodes
    });
  };

  useEffect(() => {
    refreshSupabaseStatus();
  }, []);

  // --- Synchronization & Side Effects ---
  useEffect(() => {
    localStorage.setItem('bel_users', JSON.stringify(users));
    if (isInitialLoaded.current && supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
      users.forEach(u => dbSaveUser(u));
    }
  }, [users, supabaseStatus]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('bel_current_user', JSON.stringify(currentUser));
      // Sync currentUser back into users array
      setUsers(prev => prev.map(u => u.id === currentUser.id ? currentUser : u));
      if (isInitialLoaded.current && supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
        dbSaveUser(currentUser);
      }
    } else {
      localStorage.removeItem('bel_current_user');
    }
  }, [currentUser, supabaseStatus]);

  useEffect(() => {
    localStorage.setItem('bel_products', JSON.stringify(products));
    if (isInitialLoaded.current && supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
      products.forEach(p => dbSaveProduct(p));
    }
  }, [products, supabaseStatus]);

  useEffect(() => {
    localStorage.setItem('bel_investments', JSON.stringify(investments));
    if (isInitialLoaded.current && supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
      investments.forEach(i => dbSaveInvestment(i));
    }
  }, [investments, supabaseStatus]);

  useEffect(() => {
    localStorage.setItem('bel_transactions', JSON.stringify(transactions));
    if (isInitialLoaded.current && supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
      transactions.forEach(t => dbSaveTransaction(t));
    }
  }, [transactions, supabaseStatus]);

  // Polling effect for pending transactions - handles both live Supabase and local backend memory synchronization
  useEffect(() => {
    if (!currentUser) return;
    const hasPending = transactions.some(tx => tx.status === 'pending');
    if (!hasPending) return;

    console.log("[StateContext] Pending transaction detected, starting background sync poll...");
    const interval = setInterval(async () => {
      try {
        // If Supabase is connected, refresh complete database state
        if (supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
          await refreshSupabaseStatus();
          return;
        }

        // Offline / Sandbox Fallback: Fetch in-memory updates from local backend
        const response = await fetch(`/api/sync-local-state?userId=${currentUser.id}`);
        if (response.ok) {
          const data = await response.json();
          const serverTxs = data.transactions || [];
          
          let stateUpdated = false;
          let balanceOffset = 0;
          let rechargeOffset = 0;
          let withdrawOffset = 0;

          setTransactions(currentTxs => {
            const updated = [...currentTxs];
            let modified = false;

            serverTxs.forEach((sTx: any) => {
              const localMatchIndex = updated.findIndex(t => t.txRef === sTx.reference && t.status === 'pending');
              if (localMatchIndex > -1) {
                const localMatch = updated[localMatchIndex];
                if (sTx.status !== 'pending') {
                  // Transaction completed or rejected via webhook simulation
                  updated[localMatchIndex] = {
                    ...localMatch,
                    status: sTx.status,
                    description: sTx.description
                  };
                  modified = true;

                  // Balance delta calculations
                  if (sTx.status === 'completed' && sTx.type === 'recharge') {
                    balanceOffset += sTx.amount;
                    rechargeOffset += sTx.amount;
                  } else if (sTx.status === 'rejected' && sTx.type === 'withdraw') {
                    // Refund failed withdrawal gross amount
                    balanceOffset += localMatch.amount;
                    withdrawOffset -= localMatch.amount;
                  }
                }
              }
            });

            if (modified) {
              stateUpdated = true;
              return updated;
            }
            return currentTxs;
          });

          if (stateUpdated && (balanceOffset !== 0 || rechargeOffset !== 0 || withdrawOffset !== 0)) {
            setCurrentUser(prev => {
              if (!prev) return null;
              return {
                ...prev,
                balance: prev.balance + balanceOffset,
                rechargeAmount: prev.rechargeAmount + rechargeOffset,
                withdrawAmount: Math.max(0, prev.withdrawAmount + withdrawOffset)
              };
            });
          }
        }
      } catch (err) {
        console.error("[StateContext] Polling transaction sync exception:", err);
      }
    }, 4000); // Poll every 4 seconds for immediate responsiveness

    return () => clearInterval(interval);
  }, [transactions, currentUser, supabaseStatus.connected]);

  useEffect(() => {
    localStorage.setItem('bel_tickets', JSON.stringify(tickets));
    if (isInitialLoaded.current && supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
      tickets.forEach(t => dbSaveTicket(t));
    }
  }, [tickets, supabaseStatus]);

  useEffect(() => {
    localStorage.setItem('bel_announcements', JSON.stringify(announcements));
    if (isInitialLoaded.current && supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
      announcements.forEach(a => dbSaveAnnouncement(a));
    }
  }, [announcements, supabaseStatus]);

  useEffect(() => {
    localStorage.setItem('bel_gift_codes', JSON.stringify(giftCodes));
    if (isInitialLoaded.current && supabaseStatus.connected && supabaseStatus.missingTables.length === 0) {
      giftCodes.forEach(g => dbSaveGiftCode(g));
    }
  }, [giftCodes, supabaseStatus]);

  useEffect(() => {
    localStorage.setItem('bel_spin_tickets', Math.max(0, spinTicketsCount).toString());
  }, [spinTicketsCount]);

  useEffect(() => {
    localStorage.setItem('bel_time_offset', timeOffsetHours.toString());
  }, [timeOffsetHours]);

  // Auto-cancellation of pending recharge transactions older than 10 minutes
  useEffect(() => {
    if (!currentUser) return;

    const checkAndCancelExpiredRecharges = () => {
      const now = Date.now();
      const tenMinutesInMs = 10 * 60 * 1000;
      let stateChanged = false;

      const nextTxs = transactions.map(tx => {
        if (tx.status === 'pending' && tx.type === 'recharge') {
          const createdAtTime = new Date(tx.createdAt).getTime();
          const ageMs = now - createdAtTime;
          if (ageMs >= tenMinutesInMs) {
            stateChanged = true;
            return {
              ...tx,
              status: 'rejected' as const,
              description: `${tx.description} (Cancelled - 10-minute timeout exceeded)`
            };
          }
        }
        return tx;
      });

      if (stateChanged) {
        console.log("[StateContext] Found expired pending recharge transactions. Auto-cancelling...");
        setTransactions(nextTxs);
      }
    };

    // Run check immediately and then poll every 10 seconds
    checkAndCancelExpiredRecharges();
    const interval = setInterval(checkAndCancelExpiredRecharges, 10000);

    return () => clearInterval(interval);
  }, [transactions, currentUser]);

  // Keep currentUser.dailyEarnings in sync with active investments' dailyEarnings sum
  useEffect(() => {
    if (!currentUser) return;
    const myInvestments = investments.filter(i => i.userId === currentUser.id);
    const activeInvestments = myInvestments.filter(i => i.status === 'active');
    const totalDailyDividend = activeInvestments.reduce((acc, curr) => acc + curr.dailyEarnings, 0);
    
    if (currentUser.dailyEarnings !== totalDailyDividend) {
      setCurrentUser(prev => {
        if (!prev) return null;
        return {
          ...prev,
          dailyEarnings: totalDailyDividend
        };
      });
    }
  }, [investments, currentUser?.id]);

  // --- Real-time Simulated Live Activities ---
  useEffect(() => {
    const generateActivity = () => {
      const name = MOCK_NAMES[Math.floor(Math.random() * MOCK_NAMES.length)];
      const obfuscatedPhone = `${name.split(' ')[0]} (*${Math.floor(100 + Math.random() * 900)})`;
      const types: ('recharge' | 'withdraw' | 'investment')[] = ['recharge', 'withdraw', 'investment'];
      const activityType = types[Math.floor(Math.random() * types.length)];
      
      let amount = 15000;
      if (activityType === 'recharge') {
        const rechargeAmounts = [15000, 30000, 50000, 100000, 200000, 500000];
        amount = rechargeAmounts[Math.floor(Math.random() * rechargeAmounts.length)];
      } else if (activityType === 'withdraw') {
        const withdrawAmounts = [6000, 15000, 35000, 80000, 120000, 250000];
        amount = withdrawAmounts[Math.floor(Math.random() * withdrawAmounts.length)];
      } else {
        const prices = [15000, 30000, 70000, 100000, 150000, 300000, 500000, 1000000];
        amount = prices[Math.floor(Math.random() * prices.length)];
      }

      const newActivity: LiveActivity = {
        id: Math.random().toString(36).substring(2, 9),
        phone: obfuscatedPhone,
        type: activityType,
        amount,
        timeAgo: 'Just now'
      };

      setLiveActivities(prev => [newActivity, ...prev.slice(0, 14)]);
    };

    // Initialize with a few seed activities
    for (let i = 0; i < 6; i++) {
      generateActivity();
    }

    const interval = setInterval(() => {
      generateActivity();
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  // --- Timer Tick for Investment Countdown ---
  // Calculates payouts and checks timers in real-time
  useEffect(() => {
    const interval = setInterval(() => {
      if (!currentUser) return;

      const now = new Date();
      // Shift now by our simulated offset hours
      const shiftedNowTime = now.getTime() + (timeOffsetHours * 3600000);

      let updated = false;
      const txsToAdd: Transaction[] = [];
      let totalEarnedInTick = 0;

      const nextInvestments = investments.map(inv => {
        if (inv.userId !== currentUser.id || inv.status === 'expired') return inv;

        const startEarningTime = new Date(inv.purchaseTime).getTime() + (24 * 3600000); // 24 hours from purchase
        if (shiftedNowTime < startEarningTime) return inv;

        const payoutTime = new Date(inv.nextPayoutTime).getTime();
        if (shiftedNowTime < payoutTime) return inv;

        // We have at least one payout due!
        updated = true;
        let cyclesEarned = 0;
        let tempPayoutTime = payoutTime;

        // Accumulate all missed 24-hour payouts
        while (shiftedNowTime >= tempPayoutTime && cyclesEarned < inv.daysRemaining) {
          cyclesEarned++;
          
          // Log each day's transaction
          const tx: Transaction = {
            id: Math.random().toString(36).substring(2, 9),
            userId: currentUser.id,
            userPhone: currentUser.phone,
            type: 'earnings',
            amount: inv.dailyEarnings,
            fee: 0,
            netAmount: inv.dailyEarnings,
            status: 'completed',
            description: `Daily earnings from ${inv.productName} (Day ${inv.cycleDays - inv.daysRemaining + cyclesEarned}/${inv.cycleDays})`,
            createdAt: new Date(tempPayoutTime).toISOString()
          };
          txsToAdd.push(tx);

          tempPayoutTime += 24 * 3600000; // Increment next payout time by 24 hours
        }

        const totalEarnedForThisInv = cyclesEarned * inv.dailyEarnings;
        totalEarnedInTick += totalEarnedForThisInv;

        const remainingDays = inv.daysRemaining - cyclesEarned;
        const status = remainingDays <= 0 ? 'expired' : 'active';
        const nextScheduledPayout = new Date(tempPayoutTime).toISOString();
        const lastPayoutTimeISO = new Date(tempPayoutTime - (24 * 3600000)).toISOString();

        return {
          ...inv,
          daysRemaining: remainingDays,
          nextPayoutTime: nextScheduledPayout,
          lastPayoutTime: lastPayoutTimeISO,
          status
        };
      });

      if (updated) {
        // Add all accumulated earnings to currentUser at once
        setCurrentUser(prev => {
          if (!prev) return null;
          return {
            ...prev,
            balance: prev.balance + totalEarnedInTick,
            totalRevenue: prev.totalRevenue + totalEarnedInTick
          };
        });

        // Add all transaction logs
        if (txsToAdd.length > 0) {
          setTransactions(prev => [...txsToAdd, ...prev]);
        }

        setInvestments(nextInvestments);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [currentUser, investments, timeOffsetHours]);

  // --- Auth API Modules ---
  const register = (phone: string, password: string, confirmPassword: string, refCode?: string) => {
    // Basic validations
    if (!phone) return { success: false, error: 'Phone number is required.' };
    if (!/^\d{7,10}$/.test(phone)) return { success: false, error: 'Invalid phone. Use Ugandan format, e.g. 763273733' };
    if (!password) return { success: false, error: 'Password is required.' };
    if (password.length < 4) return { success: false, error: 'Password must be at least 4 characters.' };
    if (password !== confirmPassword) return { success: false, error: 'Passwords do not match.' };

    const formattedPhone = phone.trim();
    // Check uniqueness
    if (users.find(u => u.phone === formattedPhone)) {
      return { success: false, error: 'This phone number is already registered.' };
    }

    // Referral code logic
    let uplineUser: User | undefined;
    if (refCode) {
      uplineUser = users.find(u => u.referralCode.toUpperCase() === refCode.trim().toUpperCase());
      if (!uplineUser && refCode.trim() !== '') {
        return { success: false, error: 'Referral code not found.' };
      }
    }

    // Generate random 6 character referral code
    const generatedRefCode = Math.random().toString(36).substring(2, 8).toUpperCase();

    const newUser: User = {
      id: Math.random().toString(36).substring(2, 9),
      phone: formattedPhone,
      countryCode: '+256',
      balance: 5000, // UGX 5,000 Welcome Bonus automatically credited!
      incomeBalance: 0,
      rechargeAmount: 0,
      withdrawAmount: 0,
      dailyEarnings: 0,
      referralEarnings: 0,
      teamEarnings: 0,
      totalRevenue: 5000, // Starts with welcome bonus
      referralCode: generatedRefCode,
      referredBy: uplineUser?.referralCode,
      level1Count: 0,
      level2Count: 0,
      level3Count: 0,
      isFrozen: false,
      isAdmin: false,
      createdAt: new Date().toISOString()
    };

    // Update upline metrics
    if (uplineUser) {
      const updatedUsers = users.map(u => {
        if (u.id === uplineUser!.id) {
          return { ...u, level1Count: u.level1Count + 1 };
        }
        // Level 2 upline
        if (uplineUser!.referredBy && u.referralCode === uplineUser!.referredBy) {
          return { ...u, level2Count: u.level2Count + 1 };
        }
        // Level 3 upline
        if (uplineUser!.referredBy) {
          const l2 = users.find(usr => usr.referralCode === uplineUser!.referredBy);
          if (l2 && l2.referredBy && u.referralCode === l2.referredBy) {
            return { ...u, level3Count: u.level3Count + 1 };
          }
        }
        return u;
      });

      // Add a Welcome sign-up transaction
      const bonusTx: Transaction = {
        id: Math.random().toString(36).substring(2, 9),
        userId: newUser.id,
        userPhone: newUser.phone,
        type: 'gift',
        amount: 5000,
        fee: 0,
        netAmount: 5000,
        status: 'completed',
        description: 'Welcome Bonus Credited',
        createdAt: new Date().toISOString()
      };

      setTransactions(prev => [bonusTx, ...prev]);
      setUsers([...updatedUsers, newUser]);
    } else {
      const bonusTx: Transaction = {
        id: Math.random().toString(36).substring(2, 9),
        userId: newUser.id,
        userPhone: newUser.phone,
        type: 'gift',
        amount: 5000,
        fee: 0,
        netAmount: 5000,
        status: 'completed',
        description: 'Welcome Bonus Credited',
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [bonusTx, ...prev]);
      setUsers([...users, newUser]);
    }

    // Persist registered password for admin management
    const savedPasswords = JSON.parse(localStorage.getItem('bel_passwords') || '{}');
    savedPasswords[newUser.id] = password;
    localStorage.setItem('bel_passwords', JSON.stringify(savedPasswords));

    // Automatically log in
    setCurrentUser(newUser);
    return { success: true };
  };

  const login = (phone: string, password: string) => {
    if (!phone || !password) return { success: false, error: 'Phone and password are required.' };
    const user = users.find(u => u.phone === phone.trim() && u.countryCode === '+256');
    if (!user) {
      // Allow seeding check for admin in case of test logins
      const adminUser = users.find(u => u.phone === phone.trim());
      if (adminUser && adminUser.isFrozen) return { success: false, error: 'This account has been frozen by security.' };
      if (adminUser && adminUser.password === undefined) {
        // Fallback for admin_1 custom bypass password
        if (password === 'admin123') {
          setCurrentUser(adminUser);
          return { success: true };
        }
      }
      return { success: false, error: 'User account not found.' };
    }
    if (user.isFrozen) return { success: false, error: 'This account has been frozen by security.' };
    
    // For simple demo, we let users login with any password if password wasn't set, otherwise verify.
    // In our registration, password is set. If the user was seeded, default password is '123456'.
    if (password !== '123456' && password !== 'admin123') {
      // Check if it matches registered password
      // Since we simulate user object password, we can track simple storage passwords
      const savedPasswords = JSON.parse(localStorage.getItem('bel_passwords') || '{}');
      if (savedPasswords[user.id] && savedPasswords[user.id] !== password) {
        return { success: false, error: 'Incorrect password.' };
      }
    }

    setCurrentUser(user);
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  // --- Investment Product Purchase Module ---
  const purchaseProduct = (productId: string) => {
    if (!currentUser) return { success: false, error: 'Please log in to purchase.' };
    const product = products.find(p => p.id === productId);
    if (!product) return { success: false, error: 'Product not found.' };

    if (currentUser.balance < product.price) {
      return { success: false, error: `Insufficient balance. Price is UGX ${product.price.toLocaleString()}, but you have UGX ${currentUser.balance.toLocaleString()}. Please recharge first.` };
    }

    // Deduct price from currentUser balance
    const updatedUser = {
      ...currentUser,
      balance: currentUser.balance - product.price,
      totalRevenue: currentUser.totalRevenue + product.dailyEarnings * product.cycleDays // anticipated
    };

    // Calculate payouts
    // Daily earnings start EXACTLY after 24 hours. No earnings on day of recharge.
    const now = new Date();
    const purchaseTimeISO = now.toISOString();
    // First scheduled payout is exactly purchase time + 24 hours
    const firstPayoutTime = new Date(now.getTime() + (24 * 3600000)).toISOString();

    const newInvestment: Investment = {
      id: Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      productId: product.id,
      productName: product.name,
      purchasePrice: product.price,
      dailyEarnings: product.dailyEarnings,
      totalEarnings: product.totalEarnings,
      cycleDays: product.cycleDays,
      daysRemaining: product.cycleDays,
      nextPayoutTime: firstPayoutTime,
      purchaseTime: purchaseTimeISO,
      status: 'active'
    };

    // Store investment
    setInvestments(prev => [...prev, newInvestment]);

    // Create Purchase Transaction
    const purchaseTx: Transaction = {
      id: Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      userPhone: currentUser.phone,
      type: 'withdraw', // acts as spending
      amount: product.price,
      fee: 0,
      netAmount: product.price,
      status: 'completed',
      description: `Purchased Brewery: ${product.name}`,
      createdAt: now.toISOString()
    };
    setTransactions(prev => [purchaseTx, ...prev]);

    // --- Referral Commissions Distribution ---
    // Level 1 = 25% | Level 2 = 3% | Level 3 = 2%
    let upline1: User | undefined;
    let upline2: User | undefined;
    let upline3: User | undefined;

    if (currentUser.referredBy) {
      upline1 = users.find(u => u.referralCode === currentUser.referredBy);
      if (upline1) {
        const comm1 = Math.round(product.price * 0.25);
        upline1.balance += comm1;
        upline1.referralEarnings += comm1;
        upline1.totalRevenue += comm1;

        const tx1: Transaction = {
          id: Math.random().toString(36).substring(2, 9),
          userId: upline1.id,
          userPhone: upline1.phone,
          type: 'commission',
          amount: comm1,
          fee: 0,
          netAmount: comm1,
          status: 'completed',
          description: `L1 Referral Commission (from ${currentUser.phone})`,
          createdAt: now.toISOString()
        };
        setTransactions(prev => [tx1, ...prev]);

        // Level 2 upline check
        if (upline1.referredBy) {
          upline2 = users.find(u => u.referralCode === upline1!.referredBy);
          if (upline2) {
            const comm2 = Math.round(product.price * 0.03);
            upline2.balance += comm2;
            upline2.teamEarnings += comm2;
            upline2.totalRevenue += comm2;

            const tx2: Transaction = {
              id: Math.random().toString(36).substring(2, 9),
              userId: upline2.id,
              userPhone: upline2.phone,
              type: 'commission',
              amount: comm2,
              fee: 0,
              netAmount: comm2,
              status: 'completed',
              description: `L2 Referral Commission (from ${currentUser.phone})`,
              createdAt: now.toISOString()
            };
            setTransactions(prev => [tx2, ...prev]);

            // Level 3 upline check
            if (upline2.referredBy) {
              upline3 = users.find(u => u.referralCode === upline2!.referredBy);
              if (upline3) {
                const comm3 = Math.round(product.price * 0.02);
                upline3.balance += comm3;
                upline3.teamEarnings += comm3;
                upline3.totalRevenue += comm3;

                const tx3: Transaction = {
                  id: Math.random().toString(36).substring(2, 9),
                  userId: upline3.id,
                  userPhone: upline3.phone,
                  type: 'commission',
                  amount: comm3,
                  fee: 0,
                  netAmount: comm3,
                  status: 'completed',
                  description: `L3 Referral Commission (from ${currentUser.phone})`,
                  createdAt: now.toISOString()
                };
                setTransactions(prev => [tx3, ...prev]);
              }
            }
          }
        }
      }
    }

    // Save passwords persistence alongside users
    const savedPasswords = JSON.parse(localStorage.getItem('bel_passwords') || '{}');
    if (currentUser.id) {
      savedPasswords[currentUser.id] = localStorage.getItem(`pass_${currentUser.id}`) || '123456';
      localStorage.setItem('bel_passwords', JSON.stringify(savedPasswords));
    }

    setCurrentUser(updatedUser);
    return { success: true };
  };

  // --- Financial Submissions Module (Payment API Prep) ---
  const rechargeAccount = async (amount: number, method: string, phone: string) => {
    if (!currentUser) return { success: false, error: 'Please log in to recharge.' };
    if (amount < 5000) return { success: false, error: 'Minimum recharge amount is UGX 5,000.' };

    const now = new Date();
    const txId = Math.random().toString(36).substring(2, 9);
    const reference = `LWRX-REC-${currentUser.id}-${Math.floor(100000 + Math.random() * 900000)}`;

    const newTx: Transaction = {
      id: txId,
      userId: currentUser.id,
      userPhone: currentUser.phone,
      type: 'recharge',
      amount,
      fee: 0,
      netAmount: amount,
      status: 'pending', // Will wait for payment confirmation
      paymentMethod: method,
      txRef: reference,
      description: `Recharge via ${method} - LWorx Pay Initiated`,
      createdAt: now.toISOString()
    };

    try {
      const response = await fetch('/api/recharge', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          amount,
          phone,
          method,
          reference,
          userId: currentUser.id
        })
      });

      const resData = await response.json();
      
      if (resData.success) {
        // Register transaction in state ONLY if API registration succeeded
        setTransactions(prev => [newTx, ...prev]);
        return { 
          success: true, 
          live: true, 
          message: `USSD mobile money push sent to +256 ${phone}. Please complete payment on your phone.` 
        };
      } else {
        return { 
          success: false, 
          live: false, 
          error: resData.message || (resData.error && resData.error.message) || "Failed to register transaction with LWorx Pay.",
          message: `The live gateway returned an error during initiation.` 
        };
      }
    } catch (error: any) {
      console.error('Error during recharge fetch:', error);
      return { 
        success: false, 
        live: false, 
        error: error.message || "Network exception occurred.",
        message: 'The transaction could not be registered on any payment gateway node.' 
      };
    }
  };

  const withdrawAccount = async (amount: number, paymentMethod: string, phone: string) => {
    if (!currentUser) return { success: false, error: 'Please log in.' };
    if (amount < 5000) return { success: false, error: 'Minimum withdrawal is UGX 5,000.' };
    if (currentUser.balance < amount) return { success: false, error: 'Insufficient account balance.' };

    const fee = Math.round(amount * 0.10); // 10% withdrawal fee
    const netAmount = amount - fee;

    const now = new Date();
    const txId = Math.random().toString(36).substring(2, 9);
    const reference = `LWRX-WDR-${currentUser.id}-${Math.floor(100000 + Math.random() * 900000)}`;

    const newTx: Transaction = {
      id: txId,
      userId: currentUser.id,
      userPhone: currentUser.phone,
      type: 'withdraw',
      amount,
      fee,
      netAmount,
      status: 'pending',
      paymentMethod: `${paymentMethod} (${phone})`,
      txRef: reference,
      description: `Withdrawal payout via ${paymentMethod} to ${phone}`,
      createdAt: now.toISOString()
    };

    try {
      const response = await fetch('/api/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          amount: netAmount,
          phone,
          method: paymentMethod,
          reference,
          userId: currentUser.id
        })
      });

      const resData = await response.json();

      if (resData.success) {
        // Deduct and add transaction ONLY if API registration succeeded
        setCurrentUser(prev => {
          if (!prev) return null;
          return {
            ...prev,
            balance: prev.balance - amount,
            withdrawAmount: prev.withdrawAmount + amount
          };
        });
        setTransactions(prev => [newTx, ...prev]);
        return { 
          success: true, 
          live: true, 
          message: `Withdrawal processed successfully. UGX ${netAmount.toLocaleString()} has been sent to +256 ${phone}.` 
        };
      } else {
        return { 
          success: false, 
          live: false, 
          error: resData.message || (resData.error && resData.error.message) || "Failed to register payout with LWorx Pay.",
          message: `The live gateway returned an error during payout registration.` 
        };
      }
    } catch (error: any) {
      console.error('Error during withdrawal fetch:', error);
      return { 
        success: false, 
        live: false, 
        error: error.message || "Network exception occurred.",
        message: 'The payout could not be registered on any gateway node.' 
      };
    }
  };

  const collectEarnings = () => {
    if (!currentUser) return { success: false, error: 'Please log in to claim earnings.' };
    
    const claimAmt = currentUser.incomeBalance;
    if (claimAmt <= 0) {
      return { success: false, error: 'No earnings available to accumulate currently.' };
    }

    // Transfer from income balance to main balance
    setCurrentUser(prev => {
      if (!prev) return null;
      return {
        ...prev,
        balance: prev.balance + claimAmt,
        incomeBalance: 0
      };
    });

    // Create transaction log
    const collectTx: Transaction = {
      id: Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      userPhone: currentUser.phone,
      type: 'earnings',
      amount: claimAmt,
      fee: 0,
      netAmount: claimAmt,
      status: 'completed',
      description: 'Collected earnings from Income Balance to spendable Ledger',
      createdAt: new Date().toISOString()
    };
    setTransactions(prev => [collectTx, ...prev]);

    return { success: true, amount: claimAmt };
  };

  const claimDailySalary = (amount: number) => {
    if (!currentUser) return { success: false, error: 'Please log in to claim your daily wage.' };
    
    // Update user record: add amount to balance, teamEarnings, and totalRevenue
    setCurrentUser(prev => {
      if (!prev) return null;
      return {
        ...prev,
        balance: prev.balance + amount,
        teamEarnings: prev.teamEarnings + amount,
        totalRevenue: prev.totalRevenue + amount
      };
    });

    setUsers(prev => prev.map(u => {
      if (u.id === currentUser.id) {
        return {
          ...u,
          balance: u.balance + amount,
          teamEarnings: u.teamEarnings + amount,
          totalRevenue: u.totalRevenue + amount
        };
      }
      return u;
    }));

    // Create a transaction log
    const salaryTx: Transaction = {
      id: Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      userPhone: currentUser.phone,
      type: 'recharge',
      amount: amount,
      fee: 0,
      netAmount: amount,
      status: 'completed',
      description: 'Received Daily Wage Salary Allowance',
      createdAt: new Date().toISOString()
    };
    setTransactions(prev => [salaryTx, ...prev]);

    return { success: true, amount };
  };

  // --- Gift Center Modules ---
  const claimGift = (code: string) => {
    if (!currentUser) return { success: false, error: 'Please log in.' };
    const gift = giftCodes.find(g => g.code.toUpperCase() === code.trim().toUpperCase());
    
    if (!gift) return { success: false, error: 'Invalid or expired gift code.' };
    if (gift.claimedBy.includes(currentUser.id)) {
      return { success: false, error: 'You have already claimed this gift code.' };
    }
    if (gift.usageCount >= gift.usageLimit) {
      return { success: false, error: 'This gift code has reached its maximum usage limit.' };
    }

    // Process claim
    const updatedGift = {
      ...gift,
      usageCount: gift.usageCount + 1,
      claimedBy: [...gift.claimedBy, currentUser.id]
    };

    setGiftCodes(prev => prev.map(g => g.id === gift.id ? updatedGift : g));

    // Credit user
    setCurrentUser(prev => {
      if (!prev) return null;
      return {
        ...prev,
        balance: prev.balance + gift.rewardAmount,
        totalRevenue: prev.totalRevenue + gift.rewardAmount
      };
    });

    // Create transaction log
    const claimTx: Transaction = {
      id: Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      userPhone: currentUser.phone,
      type: 'gift',
      amount: gift.rewardAmount,
      fee: 0,
      netAmount: gift.rewardAmount,
      status: 'completed',
      description: `Gift Code Redeemed: ${gift.code}`,
      createdAt: new Date().toISOString()
    };

    setTransactions(prev => [claimTx, ...prev]);
    return { success: true, reward: gift.rewardAmount };
  };

  const spinWheel = () => {
    if (!currentUser) return { success: false, error: 'Please log in.' };
    if (spinTicketsCount <= 0) return { success: false, error: 'No lucky spin tickets available. Spin tickets can be awarded by administrators.' };

    // Choose reward based on weights
    const random = Math.random();
    let cumulative = 0;
    let selectedReward = SPIN_REWARDS[SPIN_REWARDS.length - 1]; // Fallback to empty

    for (const r of SPIN_REWARDS) {
      cumulative += r.probability;
      if (random <= cumulative) {
        selectedReward = r;
        break;
      }
    }

    setSpinTicketsCount(prev => prev - 1);

    // Apply rewards
    if (selectedReward.type === 'cash') {
      setCurrentUser(prev => {
        if (!prev) return null;
        return {
          ...prev,
          balance: prev.balance + selectedReward.value,
          totalRevenue: prev.totalRevenue + selectedReward.value
        };
      });

      const spinTx: Transaction = {
        id: Math.random().toString(36).substring(2, 9),
        userId: currentUser.id,
        userPhone: currentUser.phone,
        type: 'spin_win',
        amount: selectedReward.value,
        fee: 0,
        netAmount: selectedReward.value,
        status: 'completed',
        description: `Won Cash: UGX ${selectedReward.value.toLocaleString()} from Lucky Spin`,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [spinTx, ...prev]);
    } else if (selectedReward.type === 'product') {
      // Award premium product
      const product = products.find(p => p.price === selectedReward.value) || products[0];
      const now = new Date();
      const firstPayoutTime = new Date(now.getTime() + (24 * 3600000)).toISOString();
      const freeInv: Investment = {
        id: Math.random().toString(36).substring(2, 9),
        userId: currentUser.id,
        productId: product.id,
        productName: `${product.name} (LUCKY WIN)`,
        purchasePrice: 0, // Free reward
        dailyEarnings: product.dailyEarnings,
        totalEarnings: product.totalEarnings,
        cycleDays: product.cycleDays,
        daysRemaining: product.cycleDays,
        nextPayoutTime: firstPayoutTime,
        purchaseTime: now.toISOString(),
        status: 'active'
      };
      setInvestments(prev => [...prev, freeInv]);

      const spinTx: Transaction = {
        id: Math.random().toString(36).substring(2, 9),
        userId: currentUser.id,
        userPhone: currentUser.phone,
        type: 'spin_win',
        amount: 0,
        fee: 0,
        netAmount: 0,
        status: 'completed',
        description: `Won Free Brewery Plan: ${product.name}`,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [spinTx, ...prev]);
    }

    return { success: true, reward: selectedReward };
  };

  // --- Daily Sign-In Module (Lucky Wheel/Gift Center) ---
  const dailySignIn = () => {
    if (!currentUser) return { success: false, error: 'Please log in.' };
    
    // Check if user has an active product with price >= 30,000 UGX
    const myInvests = investments.filter(i => i.userId === currentUser.id && i.status === 'active');
    const hasHigherPlan = myInvests.some(i => i.purchasePrice >= 30000);
    
    if (!hasHigherPlan) {
      return { 
        success: false, 
        error: 'To unlock Daily Sign-In, please purchase a higher plan (Midnight Intense, UGX 30,000 or above).' 
      };
    }
    
    // Check if already signed in today (local state key check)
    const todayStr = new Date().toDateString();
    const lastSignIn = localStorage.getItem(`last_signin_${currentUser.id}`);
    
    if (lastSignIn === todayStr) {
      return { success: false, error: 'You have already signed in today. Please return tomorrow!' };
    }
    
    // Generate reward less than 5000 UGX (e.g. random between 1500 and 4800 UGX)
    const rewardAmount = Math.floor(Math.random() * 3300) + 1500;
    
    // Add reward directly to currentUser's spendable balance and update users array
    setCurrentUser(prev => {
      if (!prev) return null;
      return {
        ...prev,
        balance: prev.balance + rewardAmount,
        totalRevenue: prev.totalRevenue + rewardAmount
      };
    });
    
    setUsers(prev => prev.map(u => {
      if (u.id === currentUser.id) {
        return {
          ...u,
          balance: u.balance + rewardAmount,
          totalRevenue: u.totalRevenue + rewardAmount
        };
      }
      return u;
    }));
    
    // Log transaction
    const tx: Transaction = {
      id: Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      userPhone: currentUser.phone,
      type: 'recharge', // Counts as a balance addition
      amount: rewardAmount,
      fee: 0,
      netAmount: rewardAmount,
      status: 'completed',
      description: `Daily Sign-In Reward: UGX ${rewardAmount.toLocaleString()}`,
      createdAt: new Date().toISOString()
    };
    
    setTransactions(prev => [tx, ...prev]);
    
    // Persist sign in date
    localStorage.setItem(`last_signin_${currentUser.id}`, todayStr);
    
    return { success: true, reward: rewardAmount };
  };

  // --- Support Chat Ticket Module ---
  const createTicket = (subject: string, message: string) => {
    if (!currentUser) return { success: false, error: 'Please log in.' };
    if (!subject || !message) return { success: false, error: 'Subject and message are required.' };

    const newTicket: SupportTicket = {
      id: Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      userPhone: currentUser.phone,
      subject: subject.trim(),
      message: message.trim(),
      status: 'open',
      createdAt: new Date().toISOString(),
      replies: []
    };

    setTickets(prev => [newTicket, ...prev]);
    return { success: true };
  };

  const replyToTicket = (ticketId: string, message: string, sender: 'user' | 'admin') => {
    if (!message.trim()) return { success: false, error: 'Reply message cannot be empty.' };

    const reply: TicketReply = {
      id: Math.random().toString(36).substring(2, 9),
      sender,
      message: message.trim(),
      createdAt: new Date().toISOString()
    };

    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          replies: [...t.replies, reply],
          status: sender === 'user' ? 'open' : t.status // User replies reopen/keep open
        };
      }
      return t;
    }));

    return { success: true };
  };

  // --- FAST FORWARD TIME ENGINE (SIMULATION) ---
  const fastForward24Hours = () => {
    setTimeOffsetHours(prev => prev + 24);
  };

  // --- ADMIN FUNCTIONS ---
  const adminUpdateUserBalance = (userId: string, amount: number) => {
    let success = false;
    let error: string | undefined;
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const newBalance = u.balance + amount;
        if (newBalance < 0) {
          error = 'User balance cannot go below zero.';
          return u;
        }
        success = true;
        const updated = { ...u, balance: newBalance, totalRevenue: Math.max(0, u.totalRevenue + amount) };
        if (currentUser && currentUser.id === userId) {
          setCurrentUser(updated);
        }
        return updated;
      }
      return u;
    }));
    return { success, error };
  };

  const adminToggleUserFreeze = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const updated = { ...u, isFrozen: !u.isFrozen };
        if (currentUser && currentUser.id === userId) {
          // Log them out immediately if they are frozen
          if (updated.isFrozen) {
            setTimeout(() => setCurrentUser(null), 10);
          } else {
            setCurrentUser(updated);
          }
        }
        return updated;
      }
      return u;
    }));
  };

  const adminToggleFreezeUser = (userId: string) => {
    adminToggleUserFreeze(userId);
    return { success: true };
  };

  const adminDeleteUser = (userId: string) => {
    setUsers(prev => prev.filter(u => u.id !== userId));
    if (currentUser && currentUser.id === userId) {
      setCurrentUser(null);
    }
  };

  const adminResetUserPassword = (userId: string, newPass: string) => {
    const savedPasswords = JSON.parse(localStorage.getItem('bel_passwords') || '{}');
    savedPasswords[userId] = newPass;
    localStorage.setItem('bel_passwords', JSON.stringify(savedPasswords));
    return { success: true };
  };

  const adminCreateProduct = (productData: Omit<Product, 'id' | 'dailyEarnings' | 'totalEarnings' | 'roi'>) => {
    const dailyEarnings = Math.round(productData.price * (productData.dailyReturnPercent / 100));
    const totalEarnings = dailyEarnings * productData.cycleDays;
    const roi = productData.dailyReturnPercent * productData.cycleDays;

    const newProduct: Product = {
      ...productData,
      id: `bel_custom_${Math.random().toString(36).substring(2, 9)}`,
      dailyEarnings,
      totalEarnings,
      roi
    };

    setProducts(prev => [...prev, newProduct]);
  };

  const adminAddProduct = (productData: Omit<Product, 'id' | 'dailyEarnings' | 'totalEarnings' | 'roi'>) => {
    adminCreateProduct(productData);
    return { success: true };
  };

  const adminAddAnnouncement = (title: string, content: string) => {
    adminCreateAnnouncement(title, content, false);
    return { success: true };
  };

  const adminDeleteAnnouncement = (annId: string) => {
    setAnnouncements(prev => prev.filter(a => a.id !== annId));
    return { success: true };
  };

  const adminAddGiftCode = (code: string, reward: number, limit: number) => {
    adminCreateGiftCode(code, reward, limit);
    return { success: true };
  };

  const adminDeleteGiftCode = (code: string) => {
    setGiftCodes(prev => prev.filter(g => g.code !== code));
    return { success: true };
  };

  const adminDeleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  const adminUpdateTransactionStatus = (txId: string, status: 'completed' | 'rejected') => {
    setTransactions(prevTxs => {
      const txIndex = prevTxs.findIndex(t => t.id === txId);
      if (txIndex === -1) return prevTxs;

      const updatedTxs = [...prevTxs];
      const targetTx = updatedTxs[txIndex];
      
      if (targetTx.status === 'completed' && status === 'rejected') {
        // Reverse financial impact if we are rejecting an already completed recharge/withdrawal (safety check)
        setUsers(currentUsers => currentUsers.map(u => {
          if (u.id === targetTx.userId) {
            if (targetTx.type === 'recharge') {
              return { ...u, balance: Math.max(0, u.balance - targetTx.amount), rechargeAmount: Math.max(0, u.rechargeAmount - targetTx.amount) };
            } else if (targetTx.type === 'withdraw') {
              return { ...u, balance: u.balance + targetTx.amount, withdrawAmount: Math.max(0, u.withdrawAmount - targetTx.amount) };
            }
          }
          return u;
        }));
      } else if (targetTx.status === 'pending' && status === 'completed') {
        // Complete financial transactions
        setUsers(currentUsers => currentUsers.map(u => {
          if (u.id === targetTx.userId) {
            if (targetTx.type === 'recharge') {
              return { ...u, balance: u.balance + targetTx.amount, rechargeAmount: u.rechargeAmount + targetTx.amount };
            }
            // For withdrawals, balance was deducted on submission. Nothing more to deduct, but we can update statistics.
          }
          return u;
        }));
      } else if (targetTx.status === 'pending' && status === 'rejected') {
        // Refund withdrawal if rejected
        setUsers(currentUsers => currentUsers.map(u => {
          if (u.id === targetTx.userId && targetTx.type === 'withdraw') {
            return { ...u, balance: u.balance + targetTx.amount, withdrawAmount: Math.max(0, u.withdrawAmount - targetTx.amount) };
          }
          return u;
        }));
      }

      updatedTxs[txIndex] = { ...targetTx, status };

      // Sync active session if the target transaction belongs to current logged in user
      if (currentUser && currentUser.id === targetTx.userId) {
        setTimeout(() => {
          setUsers(curUsers => {
            const matched = curUsers.find(u => u.id === currentUser.id);
            if (matched) setCurrentUser(matched);
            return curUsers;
          });
        }, 10);
      }

      return updatedTxs;
    });
  };

  const adminApproveTransaction = (txId: string, status: 'completed' | 'rejected') => {
    adminUpdateTransactionStatus(txId, status);
    return { success: true };
  };

  const adminCreateGiftCode = (code: string, reward: number, limit: number) => {
    const newGift: GiftCode = {
      id: Math.random().toString(36).substring(2, 9),
      code: code.toUpperCase().trim(),
      rewardAmount: reward,
      usageLimit: limit,
      usageCount: 0,
      claimedBy: [],
      createdAt: new Date().toISOString()
    };
    setGiftCodes(prev => [newGift, ...prev]);
  };

  const adminCreateAnnouncement = (title: string, content: string, isPinned: boolean) => {
    const newAnn: Announcement = {
      id: Math.random().toString(36).substring(2, 9),
      title: title.trim(),
      content: content.trim(),
      isPinned,
      createdAt: new Date().toISOString()
    };
    setAnnouncements(prev => [newAnn, ...prev]);
  };

  const adminAddTicketReply = (ticketId: string, message: string) => {
    replyToTicket(ticketId, message, 'admin');
  };

  const adminUpdateProduct = (productId: string, productData: Partial<Omit<Product, 'id'>>) => {
    setProducts(prev => {
      const updated = prev.map(p => {
        if (p.id === productId) {
          const merged = { ...p, ...productData };
          const dailyEarnings = Math.round(merged.price * (merged.dailyReturnPercent / 100));
          const totalEarnings = dailyEarnings * merged.cycleDays;
          const roi = merged.dailyReturnPercent * merged.cycleDays;
          return {
            ...merged,
            dailyEarnings,
            totalEarnings,
            roi
          };
        }
        return p;
      });
      return updated;
    });
  };

  const adminUpdateWhatsappLink = (link: string) => {
    setWhatsappLink(link);
    localStorage.setItem('bel_whatsapp_link', link);
  };

  const adminUpdateWineBannerUrl = (url: string) => {
    setWineBannerUrl(url);
    localStorage.setItem('bel_wine_banner_url', url);
  };

  return (
    <StateContext.Provider value={{
      users,
      currentUser,
      products,
      investments,
      transactions,
      tickets,
      announcements,
      giftCodes,
      liveActivities,
      spinTicketsCount,
      timeOffsetHours,
      supabaseStatus,
      triggerExportToSupabase,
      refreshSupabaseStatus,
      register,
      login,
      logout,
      purchaseProduct,
      rechargeAccount,
      withdrawAccount,
      claimGift,
      collectEarnings,
      claimDailySalary,
      spinWheel,
      dailySignIn,
      createTicket,
      replyToTicket,
      fastForward24Hours,
      adminUpdateUserBalance,
      adminToggleUserFreeze,
      adminDeleteUser,
      adminResetUserPassword,
      adminCreateProduct,
      adminDeleteProduct,
      adminUpdateTransactionStatus,
      adminCreateGiftCode,
      adminCreateAnnouncement,
      adminAddTicketReply,
      adminUpdateProduct,
      whatsappLink,
      adminUpdateWhatsappLink,
      wineBannerUrl,
      adminUpdateWineBannerUrl,
      adminToggleFreezeUser,
      adminApproveTransaction,
      adminAddProduct,
      adminAddAnnouncement,
      adminDeleteAnnouncement,
      adminAddGiftCode,
      adminDeleteGiftCode
    }}>
      {children}
    </StateContext.Provider>
  );
};

export const useAppState = () => {
  const context = useContext(StateContext);
  if (context === undefined) {
    throw new Error('useAppState must be used within a StateProvider');
  }
  return context;
};
