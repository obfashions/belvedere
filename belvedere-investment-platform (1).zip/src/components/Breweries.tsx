/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../state/StateContext';
import { ShoppingBag, CheckCircle, Percent, Clock, AlertTriangle, ShieldCheck } from 'lucide-react';

export const Breweries: React.FC = () => {
  const { products, purchaseProduct, currentUser } = useAppState();
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [purchasingId, setPurchasingId] = useState<string | null>(null);

  const handlePurchase = (productId: string, productName: string) => {
    setErrorMsg('');
    setSuccessMsg('');
    setPurchasingId(productId);

    // Minor loading delay for luxury feeling
    setTimeout(() => {
      const res = purchaseProduct(productId);
      setPurchasingId(null);
      if (res.success) {
        setSuccessMsg(`Congratulations! You have successfully acquired the ${productName} asset plan. Your daily dividends will start accruing exactly after 24 hours.`);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setErrorMsg(res.error || 'Failed to complete acquisition.');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 1200);
  };

  return (
    <div className="w-full max-w-lg mx-auto px-4 pt-2.5 pb-24 space-y-4" id="breweries_container">
      
      {/* Breweries Title Header */}
      <div className="text-left" id="breweries_title_header">
        <div className="flex items-center gap-2 text-[#d4af37]">
          <ShieldCheck className="w-5 h-5" />
          <span className="text-[10px] font-black tracking-widest uppercase">INSURED ASSETS</span>
        </div>
        <h2 className="text-xl font-bold tracking-tight text-slate-800 mt-1">
          Belvedere Premium Asset Plans
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          Acquire fractional shares in premium Belvedere spirits batches and custom barrels. All earnings are insured and cleared automatically.
        </p>
      </div>

      {/* Purchase Feedback Popups */}
      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-3 text-left text-xs text-emerald-800" id="breweries_success">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-bold">ASSET ACQUIRED</h4>
            <p className="text-[11px] mt-1 leading-normal">{successMsg}</p>
          </div>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3 text-left text-xs text-red-800" id="breweries_error">
          <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-bold">TRANSACTION FAILED</h4>
            <p className="text-[11px] mt-1 leading-normal">{errorMsg}</p>
          </div>
        </div>
      )}

      {/* Available Balance Quick Widget */}
      {currentUser && (
        <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 flex justify-between items-center text-left gap-4 text-xs" id="quick_balance_banner">
          <div className="min-w-0 flex-1">
            <span className="text-slate-500 font-bold block uppercase tracking-widest text-[9px]">YOUR SPENDABLE BALANCE</span>
            <span className="text-sm font-extrabold text-slate-800 mt-0.5 block break-all font-mono">UGX {currentUser.balance.toLocaleString()}</span>
          </div>
          <div className="text-right shrink-0">
            <span className="text-slate-500 font-bold block uppercase tracking-widest text-[9px]">DISTILLERY RATING</span>
            <span className="text-xs font-bold text-amber-500 mt-0.5 block">★★★★★ PREMIUM AAA</span>
          </div>
        </div>
      )}

      {/* Products Grid */}
      <div className="grid grid-cols-2 gap-4" id="products_grid">
        {products.map((prod) => {
          // Calculate stats
          const dailyEarnings = Math.round(prod.price * (prod.dailyReturnPercent / 100));
          const totalEarnings = dailyEarnings * prod.cycleDays;
          const roi = Math.round(prod.dailyReturnPercent * prod.cycleDays);

          const isPurchasing = purchasingId === prod.id;

          // Make name Belvedere themed
          const belName = prod.name;

          return (
            <div key={prod.id} className="w-full rounded-2xl bg-white border border-slate-200 overflow-hidden flex flex-col justify-between hover:border-[#C8102E]/20 transition duration-300 shadow-sm hover:shadow-md" id={`product_card_${prod.id}`}>
              
              {/* Product Hero Banner */}
              <div className="relative h-28 w-full border-b border-slate-100 overflow-hidden group" id={`product_img_box_${prod.id}`}>
                <img src={prod.imageUrl} alt={belName} className="w-full h-full object-cover filter brightness-95 saturate-120 group-hover:scale-105 transition duration-700" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/10 via-transparent to-transparent" />
                
                {/* Float Badge */}
                <span className="absolute top-2 right-2 bg-red-600 border border-red-500/15 text-white text-[8px] font-mono px-1.5 py-0.5 rounded uppercase tracking-widest font-extrabold">
                  ROI {roi}%
                </span>
              </div>

              {/* Product Content Details */}
              <div className="p-3 flex-1 flex flex-col justify-between text-left" id={`product_content_${prod.id}`}>
                <div className="space-y-1">
                  <h3 className="text-xs font-black text-slate-800 tracking-wide line-clamp-2 min-h-[32px]">{belName}</h3>
                  <p className="text-[10px] text-slate-500 leading-normal font-light line-clamp-3">{prod.description}</p>
                </div>

                {/* Technical Specifications */}
                <div className="space-y-1.5 bg-slate-50 border border-slate-200 rounded-xl p-2.5 mt-3 text-[10px]" id={`product_specs_${prod.id}`}>
                  <div className="flex justify-between border-b border-slate-200/50 pb-1">
                    <span className="text-slate-400 font-bold uppercase tracking-widest text-[8px]">PRICE</span>
                    <span className="font-extrabold text-slate-800 font-mono">UGX {prod.price.toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between border-b border-slate-200/50 pb-1">
                    <span className="text-slate-400 font-bold uppercase tracking-widest text-[8px]">TERM</span>
                    <span className="font-bold text-slate-600">{prod.cycleDays} Days</span>
                  </div>

                  <div className="flex justify-between border-b border-slate-200/50 pb-1">
                    <span className="text-slate-400 font-bold uppercase tracking-widest text-[8px]">DAILY</span>
                    <span className="font-bold text-emerald-600 font-mono">UGX {dailyEarnings.toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400 font-bold uppercase tracking-widest text-[8px]">TOTAL</span>
                    <span className="font-extrabold text-amber-600 font-mono">UGX {totalEarnings.toLocaleString()}</span>
                  </div>
                </div>

                {/* Purchase Button */}
                <button
                  onClick={() => handlePurchase(prod.id, belName)}
                  disabled={isPurchasing}
                  className={`w-full py-2 rounded-xl text-[9px] font-black tracking-widest mt-3.5 border transition uppercase cursor-pointer ${
                    isPurchasing
                      ? 'bg-slate-100 text-slate-400 border-transparent cursor-not-allowed'
                      : 'bg-gradient-to-r from-red-600 to-red-700 hover:shadow-red-600/10 text-white border-transparent hover:opacity-95'
                  }`}
                  id={`btn_buy_${prod.id}`}
                >
                  {isPurchasing ? 'PROCESSING...' : `BUY PLAN`}
                </button>
              </div>

            </div>
          );
        })}
      </div>
    </div>
  );
};
