/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../state/StateContext';
import { ArrowLeft, Award, CheckCircle, Clock, ShieldAlert } from 'lucide-react';

interface IncomeProps {
  onBackToMine?: () => void;
}

export const Income: React.FC<IncomeProps> = ({ onBackToMine }) => {
  const { currentUser, claimDailySalary } = useAppState();
  const [claimFeedback, setClaimFeedback] = useState<{ success: boolean; msg: string } | null>(null);

  if (!currentUser) return null;

  // Determine current Level 1 referral count (representing effective investors)
  const l1Count = currentUser.level1Count || 0;

  // Calculate current daily salary tier
  let dailySalaryAmount = 1000; // Default starter daily salary for test/demo ease
  let activeMilestoneIndex = -1;

  if (l1Count >= 20) {
    dailySalaryAmount = 34000;
    activeMilestoneIndex = 3;
  } else if (l1Count >= 10) {
    dailySalaryAmount = 14500;
    activeMilestoneIndex = 2;
  } else if (l1Count >= 5) {
    dailySalaryAmount = 6000;
    activeMilestoneIndex = 1;
  } else if (l1Count >= 2) {
    dailySalaryAmount = 2400;
    activeMilestoneIndex = 0;
  }

  // Defined Milestones from Screen 3
  const milestones = [
    { target: 2, salary: 2400, label: '1.When your Invite 2 Level 1 users to invest; daily salary UGX 2400.' },
    { target: 5, salary: 6000, label: '2.When your Invite 5 Level 1 users to invest; daily salary UGX 6000.' },
    { target: 10, salary: 14500, label: '3.When your Invite 10 Level 1 users to invest; daily salary UGX 14500.' },
    { target: 20, salary: 34000, label: '4.When your Invite 20 Level 1 users to invest; daily salary UGX 34000.' }
  ];

  // Daily claiming constraint tracker
  const todayDateStr = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
  const lastClaimKey = `bud_last_salary_claim_${currentUser.id}`;
  const alreadyClaimedToday = localStorage.getItem(lastClaimKey) === todayDateStr;

  const handleClaimSalary = () => {
    setClaimFeedback(null);

    // Guard: Claimed once per day constraint
    if (alreadyClaimedToday) {
      setClaimFeedback({
        success: false,
        msg: 'Daily wage can only be received once per day. Please come back tomorrow!'
      });
      return;
    }

    // Call state dispatcher
    const res = claimDailySalary(dailySalaryAmount);
    if (res.success) {
      // Persist claim lock
      localStorage.setItem(lastClaimKey, todayDateStr);
      setClaimFeedback({
        success: true,
        msg: `Successfully received UGX ${dailySalaryAmount.toLocaleString()} Daily Wage Salary! credited directly to your spendable balance.`
      });
    } else {
      setClaimFeedback({
        success: false,
        msg: res.error || 'Claiming failed. Please contact support.'
      });
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto px-0 pt-0 pb-24 space-y-4 text-slate-800 font-sans" id="bud_daily_wage_plan_page">
      
      {/* 1. Page Header with solid red styling */}
      <div className="bg-[#C8102E] text-white px-4 py-4 flex items-center justify-between shadow-md" id="wage_header_bar">
        <button 
          onClick={onBackToMine}
          className="p-1.5 hover:bg-white/10 rounded-full transition text-white cursor-pointer shrink-0"
          id="btn_back_from_wage"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-base font-extrabold tracking-wide text-white mx-auto text-center pr-8">
          Daily wage plan
        </h2>
      </div>

      {/* 2. Top Instructions Alert Box */}
      <div className="px-4 pt-2" id="instructions_alert_container">
        <div className="bg-red-50/90 border border-red-100 rounded-xl p-4 text-left shadow-sm" id="instructions_alert_box">
          <p className="text-xs text-red-900 leading-relaxed font-semibold">
            You will receive a daily allowance when your Level 1 team reaches its target number of invited investments; thereafter, you can receive the maximum daily allowance daily.
          </p>
        </div>
      </div>

      {/* 3. Rewards Earned Card */}
      <div className="px-4" id="rewards_earned_container">
        <div className="relative overflow-hidden bg-gradient-to-br from-red-600 to-red-700 rounded-2xl p-5 text-left text-white shadow-lg" id="rewards_earned_card">
          {/* Circular Watermark Badge */}
          <div className="absolute right-4 bottom-4 text-white/10" id="stamp_badge_watermark">
            <svg className="w-20 h-20 transform rotate-12" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="50" cy="50" r="40" strokeDasharray="4 4" />
              <circle cx="50" cy="50" r="34" />
              <path d="M35 50 L45 60 L65 40" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>

          <span className="text-2xl font-black font-mono block">
            UGX {currentUser.teamEarnings.toLocaleString()}
          </span>
          <span className="text-xs text-white/90 font-medium tracking-wide mt-1 block">
            Total rewards earned
          </span>
        </div>
      </div>

      {/* 4. Daily Salary Claim Card */}
      <div className="px-4" id="salary_claim_container">
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-md flex items-center justify-between gap-4 text-left" id="salary_claim_card">
          <div>
            <span className="text-lg font-black text-slate-800 font-mono block">
              UGX {dailySalaryAmount.toLocaleString()}
            </span>
            <span className="text-xs text-slate-500 font-bold block mt-0.5">
              Daily salary
            </span>
          </div>

          {/* Claim Button */}
          <button
            onClick={handleClaimSalary}
            disabled={alreadyClaimedToday}
            className={`px-6 py-2.5 rounded-full font-black text-xs tracking-wider uppercase transition shadow-md cursor-pointer ${
              alreadyClaimedToday 
                ? 'bg-slate-200 text-slate-500 shadow-none cursor-not-allowed' 
                : 'bg-emerald-600 hover:bg-emerald-500 text-white hover:scale-105 active:scale-95'
            }`}
            id="btn_claim_salary"
          >
            {alreadyClaimedToday ? 'Received' : 'Receive'}
          </button>
        </div>
        
        {/* Info label */}
        <p className="text-[11px] text-slate-400 font-bold text-center mt-2" id="daily_wage_policy_text">
          Daily wage can only be received once per day.
        </p>

        {/* Claim Feedback message */}
        {claimFeedback && (
          <div className={`mt-3 p-3 rounded-xl border text-xs text-left font-bold ${
            claimFeedback.success 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
              : 'bg-red-50 border-red-200 text-red-800'
          }`} id="claim_salary_feedback">
            {claimFeedback.success ? (
              <div className="flex gap-2">
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{claimFeedback.msg}</span>
              </div>
            ) : (
              <div className="flex gap-2">
                <ShieldAlert className="w-4 h-4 shrink-0 text-red-600" />
                <span>{claimFeedback.msg}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 5. Staggered Milestones List */}
      <div className="px-4 space-y-4" id="milestones_list_container">
        <h3 className="text-xs font-black tracking-widest text-slate-500 uppercase text-left pl-1">
          Milestone Progression Targets
        </h3>

        <div className="space-y-4" id="milestones_staggered">
          {milestones.map((mil, idx) => {
            const isCompleted = l1Count >= mil.target;
            const progressPct = Math.min(100, Math.round((l1Count / mil.target) * 100));

            return (
              <div key={idx} className="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-100 text-left" id={`milestone_card_${idx}`}>
                {/* Milestone Red Banner Header */}
                <div className={`px-4 py-2.5 text-[11px] font-bold ${isCompleted ? 'bg-red-700 text-white' : 'bg-slate-100 text-slate-700'}`} id={`mil_header_${idx}`}>
                  {mil.label}
                </div>

                {/* Progress Detail white box */}
                <div className="p-4 grid grid-cols-2 gap-4 text-xs" id={`mil_detail_${idx}`}>
                  <div>
                    <span className="font-extrabold text-slate-800 font-mono block">
                      {l1Count} / {mil.target}
                    </span>
                    <span className="text-[10px] text-slate-500 font-bold block mt-0.5">
                      Effective investment users
                    </span>
                  </div>

                  <div>
                    <span className="font-extrabold text-[#C8102E] font-mono block">
                      UGX {mil.salary.toLocaleString()}
                    </span>
                    <span className="text-[10px] text-slate-500 font-bold block mt-0.5">
                      Available rewards
                    </span>
                  </div>
                </div>

                {/* Visual Progress bar */}
                <div className="px-4 pb-3" id={`mil_progress_${idx}`}>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${isCompleted ? 'bg-red-600' : 'bg-slate-400'}`} 
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
