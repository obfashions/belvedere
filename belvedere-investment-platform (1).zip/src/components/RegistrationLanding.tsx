/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useAppState } from '../state/StateContext';
import { BelvedereLogo } from './Branding';
import { Phone, Lock, UserPlus, LogIn, Award, Gift, ArrowDown, ChevronRight, HelpCircle } from 'lucide-react';

interface RegistrationLandingProps {
  onSuccess: () => void;
}

export const RegistrationLanding: React.FC<RegistrationLandingProps> = ({ onSuccess }) => {
  const { register, login, products } = useAppState();
  const [isLogin, setIsLogin] = useState(false);
  
  // Form fields
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Auto-detect referral code from URL parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref') || params.get('refcode');
    if (ref) {
      setReferralCode(ref.toUpperCase());
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (isLogin) {
      // Login
      const res = login(phone, password);
      if (res.success) {
        onSuccess();
      } else {
        setError(res.error || 'Login failed. Please check credentials.');
      }
    } else {
      // Registration
      const res = register(phone, password, confirmPassword, referralCode);
      if (res.success) {
        setSuccessMsg('Registration successful! UGX 5,000 Welcome Bonus credited.');
        setTimeout(() => {
          onSuccess();
        }, 1500);
      } else {
        setError(res.error || 'Registration failed.');
      }
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto px-4 pt-1 pb-12" id="bel_landing_container">
      {/* Brand Header */}
      <div className="text-center mb-3" id="bel_brand_header">
        <BelvedereLogo className="h-10" darkText={true} />
        <p className="text-[11px] text-slate-600 font-medium mt-1.5 tracking-wider max-w-xs mx-auto" id="bel_brand_desc">
          Invest in premium Belvedere spirits and beverage assets with high-yield daily dividends in UGX.
        </p>
      </div>

      {/* Luxury Beverage Drinks Banner */}
      <div className="mb-4 rounded-xl overflow-hidden border border-slate-200 bg-white shadow-md relative group" id="beverage_portfolio_banner_reg">
        <div className="h-24 w-full relative bg-cover bg-center transition-all duration-700 group-hover:scale-105 animate-fadeIn" style={{ backgroundImage: "url('/src/assets/images/budweiser_banner_1782477094730.jpg')" }}>
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/45 via-transparent to-transparent" />
        </div>
        
        {/* Banner Details Overlay */}
        <div className="absolute bottom-2 left-3 right-3 text-left space-y-0.5" id="reg_banner_details">
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[8px] font-black uppercase text-white tracking-widest bg-red-600 px-1.5 py-0.5 rounded">
              VERIFIED PORTFOLIO
            </span>
          </div>
          <h4 className="text-[11px] font-black text-white uppercase tracking-wider">
            Belvedere Fine Spirits & Luxury Barrels
          </h4>
          <p className="text-[9px] text-white/90 font-sans leading-tight">
            Distillery backed fractional assets. Generate daily dividends up to 25% UGX.
          </p>
        </div>
      </div>

      {/* Main Authentication Card */}
      <div className="bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200/80 p-5 shadow-xl relative" id="auth_card">
        
        {/* Compact Integrated Welcome Bonus Card inside form wrapper */}
        <div className="mb-4 rounded-xl p-2.5 bg-gradient-to-r from-red-50 to-red-100/50 border border-red-200 flex items-center gap-2.5 relative overflow-hidden" id="welcome_bonus_card">
          <div className="p-1.5 rounded-lg bg-red-100 text-red-600" id="welcome_icon_holder">
            <Gift className="w-4 h-4" />
          </div>
          <div className="text-left" id="welcome_bonus_text">
            <span className="text-[9px] font-extrabold text-[#C8102E] uppercase tracking-wider">
              🎁 NEW MEMBER UGX 5,000 WELCOME BONUS ACTIVE
            </span>
            <p className="text-[9px] text-slate-600 leading-none mt-0.5" id="welcome_bonus_sub">
              Credited instantly to your account on successful registration.
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 mb-4" id="auth_tabs">
          <button
            onClick={() => { setIsLogin(false); setError(''); }}
            className={`flex-1 pb-3 text-center text-sm font-semibold tracking-wide transition-all border-b-2 ${!isLogin ? 'text-slate-800 border-[#C8102E]' : 'text-slate-400 border-transparent hover:text-slate-600'}`}
            id="tab_register"
          >
            <UserPlus className="inline-block w-4 h-4 mr-2 -mt-0.5" />
            CREATE ACCOUNT
          </button>
          <button
            onClick={() => { setIsLogin(true); setError(''); }}
            className={`flex-1 pb-3 text-center text-sm font-semibold tracking-wide transition-all border-b-2 ${isLogin ? 'text-slate-800 border-[#C8102E]' : 'text-slate-400 border-transparent hover:text-slate-600'}`}
            id="tab_login"
          >
            <LogIn className="inline-block w-4 h-4 mr-2 -mt-0.5" />
            SIGN IN
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4" id="auth_form">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl text-left font-medium animate-shake" id="auth_error">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-green-50 border border-green-200 text-green-700 text-xs rounded-xl text-left font-semibold" id="auth_success">
              {successMsg}
            </div>
          )}

          {/* Phone Field */}
          <div className="text-left" id="field_phone_container">
            <label className="block text-xs font-bold text-slate-600 mb-1 tracking-wider uppercase">
              PHONE NUMBER (AS USERNAME)
            </label>
            <div className="relative flex items-center rounded-xl bg-slate-50 border border-slate-200 focus-within:border-red-600 focus-within:ring-1 focus-within:ring-red-600 transition" id="field_phone_wrapper">
              <span className="pl-4 pr-2 text-slate-500 font-semibold text-sm border-r border-slate-200 select-none">
                +256
              </span>
              <Phone className="absolute right-4 text-slate-400 w-4 h-4 pointer-events-none" />
              <input
                type="tel"
                placeholder="763273733"
                value={phone}
                onChange={e => setPhone(e.target.value.replace(/\D/g, ''))}
                className="w-full bg-transparent py-3.5 pl-3 pr-10 text-slate-800 text-sm outline-none focus:ring-0 placeholder:text-slate-400 font-semibold"
                id="input_phone"
                required
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1 pl-1">
              Do not enter country code again. Simply type the carrier digits.
            </p>
          </div>

          {/* Password Field */}
          <div className="text-left" id="field_password_container">
            <label className="block text-xs font-bold text-slate-600 mb-1 tracking-wider uppercase">
              PASSWORD
            </label>
            <div className="relative flex items-center rounded-xl bg-slate-50 border border-slate-200 focus-within:border-red-600 focus-within:ring-1 focus-within:ring-red-600 transition" id="field_password_wrapper">
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full bg-transparent py-3.5 pl-4 pr-10 text-slate-800 text-sm outline-none focus:ring-0 placeholder:text-slate-400 font-semibold"
                id="input_password"
                required
              />
              <Lock className="absolute right-4 text-slate-400 w-4 h-4 pointer-events-none" />
            </div>
          </div>

          {/* Confirm Password Field (Register Only) */}
          {!isLogin && (
            <div className="text-left" id="field_confirm_container">
              <label className="block text-xs font-bold text-slate-600 mb-1 tracking-wider uppercase">
                CONFIRM PASSWORD
              </label>
              <div className="relative flex items-center rounded-xl bg-slate-50 border border-slate-200 focus-within:border-red-600 focus-within:ring-1 focus-within:ring-red-600 transition" id="field_confirm_wrapper">
                <input
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  className="w-full bg-transparent py-3.5 pl-4 pr-10 text-slate-800 text-sm outline-none focus:ring-0 placeholder:text-slate-400 font-semibold"
                  id="input_confirm"
                  required
                />
                <Lock className="absolute right-4 text-slate-400 w-4 h-4 pointer-events-none" />
              </div>
            </div>
          )}

          {/* Referral Code (Optional, Register Only) */}
          {!isLogin && (
            <div className="text-left" id="field_ref_container">
              <label className="block text-xs font-bold text-slate-600 mb-1 tracking-wider uppercase">
                REFERRAL CODE (OPTIONAL)
              </label>
              <div className="relative flex items-center rounded-xl bg-slate-50 border border-slate-200 focus-within:border-red-600 focus-within:ring-1 focus-within:ring-red-600 transition" id="field_ref_wrapper">
                <input
                  type="text"
                  placeholder="E.g. BELV67"
                  value={referralCode}
                  onChange={e => setReferralCode(e.target.value.toUpperCase())}
                  className="w-full bg-transparent py-3.5 pl-4 pr-10 text-slate-800 text-sm uppercase outline-none focus:ring-0 placeholder:text-slate-400 font-mono font-bold text-amber-600"
                  id="input_ref"
                />
                <Award className="absolute right-4 text-slate-400 w-4 h-4 pointer-events-none" />
              </div>
              <p className="text-[10px] text-slate-400 mt-1 pl-1">
                Enter an invitation code to join an active investment group.
              </p>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-4 rounded-xl font-bold text-sm tracking-widest text-white transition bg-gradient-to-r from-red-600 to-red-700 shadow-md cursor-pointer hover:opacity-90 uppercase"
            id="submit_auth"
          >
            {isLogin ? 'SECURE LOGIN' : 'CREATE ACCOUNT & RECEIVE UGX 5,000'}
          </button>
        </form>

        {/* Quick Access Demo Button */}
        <div className="relative flex py-2 items-center justify-center font-sans mt-4" id="demo_divider">
          <div className="flex-grow border-t border-slate-200"></div>
          <span className="flex-shrink mx-3 text-[9px] text-slate-400 font-bold uppercase tracking-widest">OR USE SANDBOX TESTER</span>
          <div className="flex-grow border-t border-slate-200"></div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-2 font-sans" id="quick_test_signins">
          <button
            type="button"
            onClick={() => {
              setPhone('777000111');
              setPassword('admin123');
              setIsLogin(true);
              // Allow state propagation then submit form
              setTimeout(() => {
                const btn = document.getElementById('submit_auth');
                if (btn) (btn as HTMLButtonElement).click();
              }, 150);
            }}
            className="py-3 px-2.5 bg-amber-50 hover:bg-amber-100 text-amber-700 font-bold text-[10px] uppercase tracking-wider rounded-xl border border-amber-200 cursor-pointer transition flex items-center justify-center gap-1.5"
            id="quick_admin_signin"
          >
            <span>🔑 DEMO ADMIN</span>
          </button>
          <button
            type="button"
            onClick={() => {
              // Quick automatic registration of random demo investor
              const randPhone = '70' + Math.floor(1000000 + Math.random() * 9000000);
              const demoPass = '123456';
              const res = register(randPhone, demoPass, demoPass, '');
              if (res.success) {
                onSuccess();
              } else {
                setError(res.error || 'Failed to auto-sign-in demo investor.');
              }
            }}
            className="py-3 px-2.5 bg-red-50 hover:bg-red-100 text-[#C8102E] font-bold text-[10px] uppercase tracking-wider rounded-xl border border-red-200 cursor-pointer transition flex items-center justify-center gap-1.5"
            id="quick_investor_signin"
          >
            <span>🥃 DEMO INVESTOR</span>
          </button>
        </div>

        {/* Disclaimer / Notice */}
        <div className="mt-4 text-center text-[10px] text-slate-400" id="auth_footer">
          By continuing, you verify that you are at least 18 years of age. All transactions are securely audited in UGX Uganda Shillings.
        </div>
      </div>

      {/* Divider */}
      <div className="my-12 flex flex-col items-center justify-center gap-2 text-center" id="plans_preview_divider">
        <span className="text-[11px] text-slate-600 tracking-widest font-bold uppercase">
          EXPLORE PREMIUM INVESTMENT PLANS
        </span>
        <p className="text-xs text-slate-500 font-light max-w-xs leading-tight">
          Review our long-term premium beverage asset packages below before registration.
        </p>
        <ArrowDown className="w-5 h-5 text-slate-400 animate-bounce mt-2" />
      </div>

      {/* Investment Plan Preview Panel */}
      <div className="space-y-4" id="plans_preview_grid">
        {products.slice(0, 3).map((prod) => {
          return (
            <div key={prod.id} className="relative rounded-2xl bg-white border border-slate-200 p-4 text-left flex gap-4 overflow-hidden shadow-sm hover:shadow-md transition duration-200" id={`preview_plan_${prod.id}`}>
              {/* Product Image Panel */}
              <div className="w-24 h-24 rounded-xl overflow-hidden relative border border-slate-200 shrink-0 shadow-inner" id={`preview_img_${prod.id}`}>
                <img src={prod.imageUrl} alt={prod.name} className="w-full h-full object-cover filter brightness-95 saturate-120" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/10 to-transparent" />
              </div>

              {/* Product Details */}
              <div className="flex-1 flex flex-col justify-between" id={`preview_details_${prod.id}`}>
                <div>
                  <h5 className="font-bold text-sm text-slate-800 tracking-wide leading-snug">
                    {prod.name}
                  </h5>
                  <p className="text-[10px] text-slate-500 mt-1 line-clamp-1">
                    {prod.description}
                  </p>
                </div>

                {/* Performance Metrics */}
                <div className="grid grid-cols-3 gap-2 border-t border-slate-100 pt-2 mt-2" id={`preview_metrics_${prod.id}`}>
                  <div>
                    <span className="block text-[8px] text-slate-400 uppercase tracking-widest">PRICE</span>
                    <span className="text-xs font-bold text-slate-800">UGX {prod.price.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="block text-[8px] text-slate-400 uppercase tracking-widest">DAILY</span>
                    <span className="text-xs font-bold text-emerald-600">UGX {prod.dailyEarnings.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="block text-[8px] text-slate-400 uppercase tracking-widest">CYCLE</span>
                    <span className="text-xs font-semibold text-slate-600">{prod.cycleDays} Days</span>
                  </div>
                </div>

                {/* Buy Button Overlay pointing to signup */}
                <button
                  onClick={() => {
                    setIsLogin(false);
                    window.scrollTo({ top: 120, behavior: 'smooth' });
                  }}
                  className="mt-3 flex items-center justify-between text-[10px] bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded-lg text-slate-700 hover:bg-[#C8102E] hover:text-white hover:border-[#C8102E] transition uppercase font-semibold w-full cursor-pointer"
                  id={`preview_btn_${prod.id}`}
                >
                  <span>REGISTER TO INVEST</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-white" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8 text-center" id="preview_more_notice">
        <p className="text-xs text-slate-500">
          And {products.length - 3} more premium plans waiting for you inside!
        </p>
      </div>
    </div>
  );
};
