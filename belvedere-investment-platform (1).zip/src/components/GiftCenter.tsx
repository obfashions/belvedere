/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../state/StateContext';
import { SPIN_REWARDS } from '../data/products';
import { Gift, Sparkles, AlertTriangle, CheckCircle, Smartphone, HelpCircle } from 'lucide-react';

export const GiftCenter: React.FC = () => {
  const { claimGift, spinWheel, spinTicketsCount, dailySignIn, currentUser, investments } = useAppState();

  // Gift Code state
  const [giftCode, setGiftCode] = useState('');
  const [giftSuccess, setGiftSuccess] = useState('');
  const [giftError, setGiftError] = useState('');
  const [isClaiming, setIsClaiming] = useState(false);

  // Spin Wheel state
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinError, setSpinError] = useState('');
  const [spinSuccess, setSpinSuccess] = useState('');
  const [wheelRotation, setWheelRotation] = useState(0);

  // Daily Sign In state
  const [signInError, setSignInError] = useState('');
  const [signInSuccess, setSignInSuccess] = useState('');
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [hasSignedInToday, setHasSignedInToday] = useState(() => {
    if (!currentUser) return false;
    return localStorage.getItem(`last_signin_${currentUser.id}`) === new Date().toDateString();
  });

  const handleDailySignIn = () => {
    if (isSigningIn) return;
    setSignInError('');
    setSignInSuccess('');
    setIsSigningIn(true);

    setTimeout(() => {
      const res = dailySignIn();
      setIsSigningIn(false);
      if (res.success) {
        setSignInSuccess(`Daily Sign-In Successful! You earned UGX ${res.reward!.toLocaleString()} cash credited instantly to your available balance.`);
        setHasSignedInToday(true);
      } else {
        setSignInError(res.error || 'Daily Sign-In failed.');
      }
    }, 1000);
  };

  // Claims
  const handleClaimCode = (e: React.FormEvent) => {
    e.preventDefault();
    setGiftError('');
    setGiftSuccess('');

    if (!giftCode.trim()) return;

    setIsClaiming(true);

    setTimeout(() => {
      const res = claimGift(giftCode);
      setIsClaiming(false);
      if (res.success) {
        setGiftSuccess(`Voucher successfully redeemed! UGX ${res.reward!.toLocaleString()} has been credited to your spendable ledger balance.`);
        setGiftCode('');
      } else {
        setGiftError(res.error || 'Voucher code invalid.');
      }
    }, 1200);
  };

  // Interactive Spin Wheel Handler
  const handleSpinWheel = () => {
    if (isSpinning) return;
    setSpinError('');
    setSpinSuccess('');

    if (spinTicketsCount <= 0) {
      setSpinError('No lucky spin tickets available. Request tickets from platform operators.');
      return;
    }

    setIsSpinning(true);

    // Call context to get spin reward index
    const res = spinWheel();
    if (!res.success) {
      setSpinError(res.error || 'Spin operation failed.');
      setIsSpinning(false);
      return;
    }

    const wonReward = res.reward!;
    const rewardIndex = SPIN_REWARDS.findIndex(r => r.id === wonReward.id);

    // Segment size is 360 / 6 = 60 degrees.
    // Calculate angle to align the winning segment at the 12 o'clock pointer (pointing at top index).
    // Let's spin multiple full rotations (e.g. 5 rotations = 1800 degrees) + align segment
    const segmentAngle = 60;
    // Calculate mid-angle for segment: rewardIndex * segmentAngle
    const targetAngle = 360 - (rewardIndex * segmentAngle) - (segmentAngle / 2);
    const newRotation = wheelRotation + 1800 + targetAngle - (wheelRotation % 360);

    setWheelRotation(newRotation);

    // Wait for spin transition (2.8s) to display results
    setTimeout(() => {
      setIsSpinning(false);
      if (wonReward.type === 'none') {
        setSpinSuccess(`Spin Complete: ${wonReward.name}. Better luck on your next premium barrel spin!`);
      } else if (wonReward.type === 'cash') {
        setSpinSuccess(`Jackpot! You won UGX ${wonReward.value.toLocaleString()} cash credited instantly to your available balance.`);
      } else {
        setSpinSuccess(`Grand Prize! You won a FREE Active Contract License: ${wonReward.name}. Track daily dividends in your Income dashboard!`);
      }
    }, 2800);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 pt-2.5 pb-24 space-y-8 text-left" id="gift_center_hub">
      
      {/* Title Header */}
      <div id="gift_title_header">
        <span className="text-[10px] font-black tracking-widest text-[#d4af37] uppercase bg-[#d4af37]/10 px-2.5 py-1 rounded">VOUCHERS & GAMES</span>
        <h2 className="text-2xl font-bold tracking-tight text-white mt-2">
          Promotional Gift Center
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Redeem secret distributor promo vouchers or spin the luxury champagne wheel to secure liquid assets instantly.
        </p>
      </div>

      {/* Grid: Left Column (Spin Wheel), Right Column (Voucher Claims) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8" id="gift_grid">
        
        {/* Lucky Spin Wheel Card */}
        <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 flex flex-col items-center justify-between text-center relative" id="wheel_panel">
          
          <div className="w-full text-left border-b border-white/5 pb-4 mb-4" id="wheel_hdr">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#d4af37] animate-pulse" />
              Belvedere Luxury Spin Wheel
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              You have <span className="font-bold text-[#d4af37] font-mono">{spinTicketsCount}</span> spin ticket(s) remaining.
            </p>
          </div>

          {spinSuccess && (
            <div className="w-full p-3.5 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-200 text-left mb-4" id="spin_success">
              {spinSuccess}
            </div>
          )}

          {spinError && (
            <div className="w-full p-3.5 bg-red-950/40 border border-red-500/30 rounded-xl text-xs text-red-300 text-left mb-4" id="spin_error">
              {spinError}
            </div>
          )}

          {/* Interactive Visual Wheel Canvas / CSS construction */}
          <div className="relative w-72 h-72 my-6 flex items-center justify-center shrink-0" id="wheel_visual_container">
            {/* Pointer Pin at 12 o'clock */}
            <div className="absolute top-0 z-20 -mt-1" id="wheel_pointer">
              <div className="w-0 h-0 border-l-[12px] border-r-[12px] border-t-[20px] border-l-transparent border-r-transparent border-t-[#d4af37] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]" />
              <div className="w-3 h-3 rounded-full bg-white mx-auto -mt-6 border border-black" />
            </div>

            {/* Segmented Wheel */}
            <div
              className="w-64 h-64 rounded-full border-4 border-slate-300 shadow-2xl relative overflow-hidden transition-transform ease-out duration-[2800ms]"
              style={{ 
                transform: `rotate(${wheelRotation}deg)`,
                backgroundImage: 'radial-gradient(circle, #1e293b 20%, #000000 100%)'
              }}
              id="spin_wheel_circle"
            >
              {/* Outer decorative gold ring */}
              <div className="absolute inset-2 border border-[#d4af37]/30 rounded-full pointer-events-none" />

              {/* Render 6 pie segments */}
              {SPIN_REWARDS.map((rew, index) => {
                const angle = index * 60;
                return (
                  <div
                    key={rew.id}
                    className="absolute top-0 left-0 w-full h-full origin-center text-white"
                    style={{
                      transform: `rotate(${angle}deg)`,
                      clipPath: 'polygon(50% 50%, 50% 0, 100% 0, 100% 50%)' // Slices precisely 60 degrees
                    }}
                  >
                    {/* Background wedge segment color */}
                    <div 
                      className="w-full h-full absolute" 
                      style={{ 
                        backgroundColor: rew.color,
                        transform: 'rotate(30deg)', // Centers wedge within clipPath
                        opacity: 0.8
                      }} 
                    />
                  </div>
                );
              })}

              {/* Wedge texts layered over top */}
              {SPIN_REWARDS.map((rew, index) => {
                const angle = index * 60 + 30; // Center offset
                return (
                  <div
                    key={`text-${rew.id}`}
                    className="absolute top-0 left-0 w-full h-full flex items-center justify-center origin-center text-white select-none pointer-events-none"
                    style={{ transform: `rotate(${angle}deg)` }}
                  >
                    <div className="text-[10px] font-extrabold tracking-tight rotate-90 translate-x-16 max-w-[65px] text-center text-white text-shadow">
                      {rew.name.replace(' Cash', '').replace(' Belvedere', 'Belv')}
                    </div>
                  </div>
                );
              })}

              {/* Center Core Cap (SPIN TRIGGER BUTTON) */}
              <div className="absolute inset-0 m-auto w-14 h-14 bg-gradient-to-br from-slate-900 to-black rounded-full border-2 border-slate-300 shadow-xl flex items-center justify-center z-10 select-none cursor-pointer" id="wheel_core_cap">
                <span className="text-[9px] font-black tracking-widest text-[#d4af37]">BELV</span>
              </div>
            </div>
          </div>

          {/* Trigger Button */}
          <button
            onClick={handleSpinWheel}
            disabled={isSpinning || spinTicketsCount <= 0}
            className={`w-full py-3.5 rounded-xl text-xs font-bold tracking-widest border transition uppercase cursor-pointer ${
              isSpinning
                ? 'bg-slate-800 text-slate-500 border-transparent cursor-not-allowed'
                : spinTicketsCount <= 0
                ? 'bg-slate-900 text-slate-500 border-white/5 cursor-not-allowed'
                : 'bg-gradient-to-r from-[#d4af37] to-[#b5952d] text-black border-amber-500/20 shadow-lg shadow-[#d4af37]/10'
            }`}
            id="btn_trigger_spin"
          >
            {isSpinning ? 'SPINNING CHAMBER...' : 'LAUNCH LUCKY SPIN'}
          </button>

          {/* Daily Active Member Sign-In Section */}
          <div className="w-full mt-6 pt-5 border-t border-white/10 text-left" id="daily_signin_panel">
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5 uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-blue-400 animate-pulse" />
              Daily Active Plan Sign-In
            </h4>
            <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
              Activate Midnight Intense (UGX 30,000) or higher to unlock. Earn random rewards less than <span className="text-[#d4af37] font-semibold">UGX 5,000</span> every day!
            </p>

            {signInSuccess && (
              <div className="mt-3 p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-200" id="signin_success_feedback">
                {signInSuccess}
              </div>
            )}

            {signInError && (
              <div className="mt-3 p-3 bg-red-950/40 border border-red-500/30 rounded-xl text-xs text-red-300" id="signin_error_feedback">
                {signInError}
              </div>
            )}

            <button
              onClick={handleDailySignIn}
              disabled={isSigningIn || hasSignedInToday}
              className={`w-full mt-3 py-3 rounded-xl text-xs font-bold tracking-widest border transition uppercase cursor-pointer ${
                hasSignedInToday
                  ? 'bg-emerald-950/20 text-emerald-500 border-emerald-500/20 cursor-not-allowed'
                  : isSigningIn
                  ? 'bg-slate-800 text-slate-500 border-transparent cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-700 to-[#112a5c] text-white border-blue-500/25 hover:border-blue-500/50'
              }`}
              id="btn_daily_signin"
            >
              {hasSignedInToday 
                ? 'SIGNED IN TODAY ✓' 
                : isSigningIn 
                ? 'AUTHENTICATING SIGN-IN...' 
                : 'CLAIM DAILY SIGN-IN BONUS'}
            </button>
          </div>
        </div>

        {/* Voucher Redemption Panel */}
        <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 text-left flex flex-col justify-between" id="voucher_panel">
          
          <div className="space-y-4" id="voucher_body">
            <div className="border-b border-white/5 pb-4" id="voucher_hdr">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Gift className="w-5 h-5 text-blue-400" />
                Claim Gift Vouchers
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Enter special distributor credentials or invitation reward gift codes below to receive cash balance credits.
              </p>
            </div>

            {giftSuccess && (
              <div className="p-4 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-200 flex gap-3" id="voucher_success_box">
                <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <span>{giftSuccess}</span>
              </div>
            )}

            {giftError && (
              <div className="p-4 bg-red-950/40 border border-red-500/30 rounded-xl text-xs text-red-300 flex gap-3" id="voucher_error_box">
                <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                <span>{giftError}</span>
              </div>
            )}

            <form onSubmit={handleClaimCode} className="space-y-4" id="voucher_form">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">VOUCHER GIFT CODE</label>
                <input
                  type="text"
                  placeholder="E.g. BELVPURE"
                  value={giftCode}
                  onChange={e => setGiftCode(e.target.value.toUpperCase())}
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-3.5 px-4 text-white uppercase text-sm outline-none focus:border-blue-500/40 font-mono font-bold tracking-widest placeholder:text-slate-700"
                  id="voucher_code_input"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isClaiming || !giftCode.trim()}
                className={`w-full py-3.5 rounded-xl text-xs font-bold tracking-widest border transition uppercase cursor-pointer ${
                  isClaiming || !giftCode.trim()
                    ? 'bg-slate-800 text-slate-500 border-transparent cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-700 to-[#102a5c] border-blue-500/20 text-white'
                }`}
                id="voucher_submit_btn"
              >
                {isClaiming ? 'VERIFYING VOUCHER SECURE KEY...' : 'REDEEM LIQUID VOUCHER'}
              </button>
            </form>
          </div>

          {/* Free promo code indicators */}
          <div className="p-4 rounded-xl bg-black/30 border border-white/5 space-y-2 mt-6" id="promo_hints_box">
            <h4 className="font-bold text-slate-400 uppercase tracking-widest text-[9px] border-b border-white/5 pb-1">Available System Vouchers (For Testing)</h4>
            <div className="flex justify-between text-xs font-mono">
              <span className="text-amber-500 font-bold">BELVPURE</span>
              <span className="text-slate-300">UGX 10,000 Bonus</span>
            </div>
            <div className="flex justify-between text-xs font-mono">
              <span className="text-amber-500 font-bold">BELVROYAL</span>
              <span className="text-slate-300">UGX 25,000 Bonus</span>
            </div>
          </div>

        </div>

      </div>

      <style>{`
        .text-shadow {
          text-shadow: 1px 1px 2px rgba(0,0,0,0.8);
        }
      `}</style>

    </div>
  );
};
