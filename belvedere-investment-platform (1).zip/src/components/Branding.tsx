/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sparkles, Trophy, Gift } from 'lucide-react';

export const BelvedereLogo: React.FC<{ className?: string; compact?: boolean; darkText?: boolean }> = ({ className = 'h-12', compact = false, darkText = false }) => {
  return (
    <div className="flex items-center justify-center gap-1.5" id="bud_logo">
      {/* Crown Icon representing Budweiser's iconic crown */}
      <svg className="w-5.5 h-5.5 text-[#d4af37] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.15)] shrink-0" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path d="M2 5 L6 13 L12 6 L18 13 L22 5 L17 19 H7 L2 5 Z" />
        <circle cx="2" cy="3.5" r="1" fill="#d4af37" />
        <circle cx="12" cy="4.5" r="1.2" fill="#d4af37" />
        <circle cx="22" cy="3.5" r="1" fill="#d4af37" />
      </svg>
      <span className={`text-2xl font-extrabold italic tracking-tight ${darkText ? 'text-slate-800' : 'text-white'} select-none`} style={{ fontFamily: '"Playfair Display", Georgia, "Times New Roman", serif' }}>
        Belvedere
      </span>
    </div>
  );
};

export const LuxuryBackground: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  return (
    <div className="absolute inset-0 w-full h-full bg-white text-slate-800 overflow-hidden pointer-events-none -z-10" id="bud_luxury_bg">
      {/* Extremely subtle warm peach/red & amber-gold ambient radial glows for light mode premium feel */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] rounded-full bg-gradient-to-br from-red-100/40 to-transparent opacity-60 filter blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-[600px] h-[600px] rounded-full bg-gradient-to-tl from-amber-100/30 to-transparent opacity-40 filter blur-[150px] pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[400px] h-[400px] rounded-full bg-gradient-to-br from-red-50/50 to-transparent opacity-50 filter blur-[100px] pointer-events-none" />

      {/* Carbonation Bubbles styled for white background */}
      {[...Array(15)].map((_, i) => {
        const size = Math.random() * 6 + 3; // 3px to 9px
        const left = Math.random() * 100;
        const delay = Math.random() * 8;
        const duration = Math.random() * 12 + 10;
        return (
          <div
            key={i}
            className="absolute bottom-[-20px] rounded-full bg-gradient-to-t from-amber-400/5 to-slate-200/30 border border-slate-300/10 pointer-events-none z-0"
            style={{
              width: `${size}px`,
              height: `${size}px`,
              left: `${left}%`,
              animation: `float-bubble ${duration}s linear infinite`,
              animationDelay: `${delay}s`,
            }}
          />
        );
      })}

      {/* Soft Wave Overlays for continuous liquid feeling */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none mix-blend-multiply overflow-hidden z-0" id="full_screen_liquid_scenery">
        <svg className="absolute w-[300vw] h-full fill-red-500/10 animate-wave-slow" viewBox="0 0 1000 1000" preserveAspectRatio="none" style={{ animationDuration: '40s' }}>
          <path d="M0,0 C150,300 350,100 500,500 C650,900 850,200 1000,1000 L1000,1000 L0,1000 Z" />
        </svg>
      </div>

      {children && (
        <div className="relative z-10 w-full min-h-screen flex flex-col pointer-events-auto">
          {children}
        </div>
      )}

      {/* Inject custom animation for bubble floats */}
      <style>{`
        @keyframes float-bubble {
          0% {
            transform: translateY(0) scale(1);
            opacity: 0;
          }
          10% {
            opacity: 0.4;
          }
          50% {
            transform: translateY(-50vh) scale(1.1);
            opacity: 0.5;
          }
          100% {
            transform: translateY(-105vh) scale(0.9);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
};

export const PromotionalBanners: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const banners = [
    {
      title: 'UGX 5,000 REGISTRATION REWARD',
      subtitle: 'Free Starter License Active',
      description: 'Earning passive dividends starts immediately after sign-up.',
      icon: <Gift className="w-5 h-5 text-[#d4af37]" />,
      color: 'from-red-950 to-red-900',
      badge: 'PROMO'
    },
    {
      title: 'BELVEDERE 3-TIER REFERRAL CLUB',
      subtitle: 'Earn up to 25%, 3%, 2% instantly',
      description: 'Collect massive network commissions straight to your spendable ledger.',
      icon: <Trophy className="w-5 h-5 text-[#d4af37]" />,
      color: 'from-red-900 to-amber-900',
      badge: 'HIGH INCOME'
    },
    {
      title: 'LUCKY BEER SPIN WHEEL',
      subtitle: 'Free Spins & Cash Rewards Daily',
      description: 'Spin daily at the Gift Center to win premium cash rewards.',
      icon: <Sparkles className="w-5 h-5 text-white animate-bounce" />,
      color: 'from-amber-900 to-red-950',
      badge: 'DAILY SPIN'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-white/10 bg-gradient-to-r p-4 shadow-lg transition-all duration-700 text-left" style={{ backgroundImage: `linear-gradient(135deg, var(--tw-gradient-stops))` }} id="bud_rotating_banners">
      <div className={`absolute inset-0 bg-gradient-to-r ${banners[currentIndex].color} opacity-95 transition-all duration-700`} />
      
      <div className="relative z-10 flex items-center justify-between gap-3 text-left">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center p-2 bg-white/10 rounded-xl border border-white/15 w-10 h-10 shrink-0 shadow-inner" id="banner_icon_holder">
            {banners[currentIndex].icon}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-1.5 py-0.5 bg-red-600 border border-white/20 text-white font-black text-[8px] tracking-widest rounded uppercase">
                {banners[currentIndex].badge}
              </span>
              <h4 className="text-xs font-extrabold text-white tracking-wide uppercase">
                {banners[currentIndex].title}
              </h4>
            </div>
            <p className="text-[10px] text-white/90 font-medium mt-0.5" id="banner_subtitle">
              {banners[currentIndex].subtitle} • <span className="text-white/60 font-light">{banners[currentIndex].description}</span>
            </p>
          </div>
        </div>

        {/* Small Dot Navigation indicators */}
        <div className="flex flex-col gap-1 shrink-0" id="banner_dots_container">
          {banners.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-1 h-1 rounded-full transition-all duration-300 ${currentIndex === idx ? 'bg-red-500 h-3' : 'bg-white/30'}`}
              id={`banner_dot_${idx}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
