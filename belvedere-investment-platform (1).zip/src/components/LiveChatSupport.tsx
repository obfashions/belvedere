import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Check, ShieldCheck, Activity, LogOut } from 'lucide-react';
import { useAppState } from '../state/StateContext';

interface Message {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  time: string;
}

export const LiveChatSupport: React.FC = () => {
  const { currentUser } = useAppState();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'agent',
      text: 'Hello! Welcome to Belvedere Support. I am the Belvedere System Administrator. How can I assist you with your investments, manual/auto recharges, or custom payouts today? (Note: All answers below are verified administrative actions.)',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  if (!currentUser) return null;

  const handleLeaveChat = () => {
    // Cancel the chat, reset history, and close the widget
    setMessages([
      {
        id: 'welcome',
        sender: 'agent',
        text: 'Hello! Welcome to Belvedere Support. I am the Belvedere System Administrator. How can I assist you with your investments, manual/auto recharges, or custom payouts today? (Note: All answers below are verified administrative actions.)',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    setInputText('');
    setIsTyping(false);
    setIsOpen(false);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userText = inputText.trim();
    const newUserMsg: Message = {
      id: `u_${Date.now()}`,
      sender: 'user',
      text: userText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newUserMsg]);
    setInputText('');
    setIsTyping(true);

    // Simulate real-time administrator responses after 2 seconds
    setTimeout(() => {
      setIsTyping(false);
      let reply = "Hello, I am the Belvedere System Administrator. I am looking into your account status. For mobile money deposits, please approve the push PIN notification on your device to complete the transaction.";
      
      const lowerText = userText.toLowerCase();
      if (lowerText.includes('recharge') || lowerText.includes('deposit') || lowerText.includes('pay')) {
        reply = "Our administrative treasury has received your recharge request. Recharges are processed through our LWORX mobile channel. Let me know if you need any manual ledger correction.";
      } else if (lowerText.includes('withdraw') || lowerText.includes('cashout') || lowerText.includes('money')) {
        reply = "I am overseeing all withdrawals today. Payout windows are open between 9 AM and 6 PM. If you initiate a withdrawal, I will personally review and release the funds to your MTN/Airtel Uganda wallet within minutes.";
      } else if (lowerText.includes('plan') || lowerText.includes('invest') || lowerText.includes('cask')) {
        reply = "As the administrator, I highly recommend our high-yield cask contracts. If you choose any tier in 'Breweries', I will secure your cask allocation and ensure your hourly/daily returns are credited directly to your balance.";
      } else if (lowerText.includes('wheel') || lowerText.includes('lucky') || lowerText.includes('spin')) {
        reply = "I can confirm your spin tickets are active. Remember, you can also claim our administrative Daily Active Sign-In Bonus in the Gift Center for rewards up to UGX 5,000 every day!";
      } else if (lowerText.includes('password') || lowerText.includes('security')) {
        reply = "Your credential security is paramount. If you wish to update your login password, please use the Account settings page, or contact me directly here so I can authorize a secure reset.";
      } else {
        reply = `Understood. As your Administrator, I've noted your request regarding "${userText}". How else can I assist you with your Belvedere assets or balance today?`;
      }

      const agentMsg: Message = {
        id: `a_${Date.now()}`,
        sender: 'agent',
        text: reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, agentMsg]);
    }, 2000);
  };

  return (
    <div className="fixed bottom-24 right-4 z-[9999] font-sans" id="floating_live_chat_root">
      {/* Floating Chat Bubble button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-blue-700 to-[#112a5c] text-white flex items-center justify-center shadow-2xl shadow-blue-500/30 border border-blue-400/40 hover:scale-110 active:scale-95 transition-all duration-300 cursor-pointer relative"
          id="btn_floating_chat_bubble"
        >
          <MessageSquare className="w-6 h-6 animate-pulse" />
          <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-950 rounded-full animate-ping" />
          <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-950 rounded-full" />
        </button>
      )}

      {/* Live Chat Overlay Window */}
      {isOpen && (
        <div 
          className="w-[320px] sm:w-[360px] h-[480px] bg-slate-950/95 border border-white/10 rounded-2xl shadow-2xl flex flex-col justify-between overflow-hidden backdrop-blur-xl animate-fade-in"
          id="live_chat_overlay_window"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-slate-900 to-[#112a5c] px-4 py-3.5 border-b border-white/10 flex justify-between items-center" id="live_chat_header">
            <div className="flex items-center gap-2">
              <div className="relative">
                <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold text-xs">
                  A
                </div>
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border border-slate-950 rounded-full animate-pulse" />
              </div>
              <div className="text-left">
                <h4 className="text-xs font-bold text-white tracking-wide">Belvedere Admin (Support)</h4>
                <span className="text-[9px] text-emerald-400 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> System Administrator Online
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={handleLeaveChat}
                className="px-2 py-1 rounded bg-red-950/60 border border-red-500/30 text-red-400 hover:text-white hover:bg-red-900/50 text-[10px] font-bold tracking-wider transition uppercase flex items-center gap-1 shrink-0"
                id="btn_leave_chat"
                title="Leave & Cancel Chat"
              >
                <LogOut className="w-3 h-3" />
                <span>Leave</span>
              </button>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition shrink-0"
                id="btn_close_live_chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 text-xs text-left" id="live_chat_messages_body">
            {messages.map((msg) => {
              const isAgent = msg.sender === 'agent';
              return (
                <div 
                  key={msg.id} 
                  className={`flex gap-2.5 max-w-[85%] ${isAgent ? 'mr-auto' : 'ml-auto flex-row-reverse'}`}
                  id={`live_msg_${msg.id}`}
                >
                  <div className={`p-3 rounded-2xl leading-relaxed text-slate-200 text-[11px] ${
                    isAgent 
                      ? 'bg-slate-900 border border-white/5 rounded-tl-none' 
                      : 'bg-blue-900/40 border border-blue-500/20 rounded-tr-none'
                  }`}>
                    {msg.text}
                    <div className="text-[8px] text-slate-500 text-right mt-1.5 flex items-center justify-end gap-1 font-mono">
                      <span>{msg.time}</span>
                      {!isAgent && <Check className="w-2.5 h-2.5 text-blue-400" />}
                    </div>
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex gap-2.5 max-w-[80%] items-center" id="live_chat_agent_typing">
                <div className="p-3 bg-slate-900 border border-white/5 rounded-2xl rounded-tl-none text-slate-400 flex items-center gap-1.5 text-[11px]">
                  <Activity className="w-3 h-3 text-blue-400 animate-spin" />
                  <span>Admin is typing...</span>
                </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>

          {/* Form Input */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-white/10 bg-black/40 flex gap-2" id="live_chat_input_form">
            <input
              type="text"
              placeholder="Type message to Admin..."
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              className="flex-1 bg-black/60 border border-white/10 focus:border-blue-500/40 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
              id="live_chat_text_input"
              required
            />
            <button
              type="submit"
              disabled={isTyping || !inputText.trim()}
              className={`p-2.5 rounded-xl flex items-center justify-center border transition duration-300 shrink-0 cursor-pointer ${
                isTyping || !inputText.trim()
                  ? 'bg-slate-800 text-slate-500 border-transparent cursor-not-allowed'
                  : 'bg-blue-700 hover:bg-blue-600 border-blue-500/20 text-white'
              }`}
              id="btn_live_chat_send"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
