/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../state/StateContext';
import { 
  Users, 
  Copy, 
  Check, 
  Award, 
  HelpCircle, 
  UserPlus, 
  Share2, 
  Network,
  DollarSign
} from 'lucide-react';

export const Invite: React.FC = () => {
  const { currentUser, users, transactions } = useAppState();
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  if (!currentUser) return null;

  // Build real referral link redirecting to Registration Page
  // In our preview environment, we use window.location.origin, or fall back to an elegant clean link
  const domain = window.location.origin || 'https://belvedere-investments.com';
  const referralLink = `${domain}?ref=${currentUser.referralCode}`;

  const copyLinkToClipboard = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const copyCodeToClipboard = () => {
    navigator.clipboard.writeText(currentUser.referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Find all team users across levels for detailed list stats
  // Level 1: direct referrers
  const level1Users = users.filter(u => u.referredBy === currentUser.referralCode);
  
  // Level 2: referred by Level 1
  const level1Codes = level1Users.map(u => u.referralCode);
  const level2Users = users.filter(u => u.referredBy && level1Codes.includes(u.referredBy));

  // Level 3: referred by Level 2
  const level2Codes = level2Users.map(u => u.referralCode);
  const level3Users = users.filter(u => u.referredBy && level2Codes.includes(u.referredBy));

  // Calculate team sizes
  const totalTeamSize = level1Users.length + level2Users.length + level3Users.length;

  // Filter commission transactions for this user
  const commissions = transactions.filter(t => t.userId === currentUser.id && t.type === 'commission');
  const totalCommissionEarned = commissions.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="w-full max-w-4xl mx-auto px-4 pt-2.5 pb-24 space-y-6" id="referral_page_container">
      
      {/* Title Header */}
      <div className="text-left" id="referral_title_header">
        <span className="text-[10px] font-black tracking-widest text-red-600 bg-red-50 px-2.5 py-1 rounded border border-red-200/50">PARTNER PROGRAM</span>
        <h2 className="text-2xl font-bold tracking-tight text-slate-800 mt-2">
          Affiliate & Team Center
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          Invite business colleagues and secure legal commissions across three nested levels of beverage asset purchases.
        </p>
      </div>

      {/* Level Commission Rules */}
      <div className="grid grid-cols-3 gap-3" id="commission_tiers_summary">
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-center" id="tier_l1">
          <span className="text-[10px] font-extrabold text-red-700 block tracking-wider">LEVEL 1 DIRECT</span>
          <span className="text-2xl font-extrabold text-[#C8102E] block mt-1">25%</span>
          <span className="text-[9px] text-red-600 block mt-1">Direct Referrals</span>
        </div>
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center" id="tier_l2">
          <span className="text-[10px] font-extrabold text-slate-500 block tracking-wider">LEVEL 2 TEAM</span>
          <span className="text-2xl font-bold text-slate-800 block mt-1">3%</span>
          <span className="text-[9px] text-slate-500 block mt-1">Sub-Referrals</span>
        </div>
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center" id="tier_l3">
          <span className="text-[10px] font-extrabold text-slate-500 block tracking-wider">LEVEL 3 TEAM</span>
          <span className="text-2xl font-bold text-slate-800 block mt-1">2%</span>
          <span className="text-[9px] text-slate-500 block mt-1">Grand-Referrals</span>
        </div>
      </div>

      {/* Referral Link Copy Section */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200 text-left space-y-4 shadow-sm" id="referral_links_box">
        <div className="flex items-center gap-2 text-slate-800 font-bold text-sm" id="referral_box_title">
          <Share2 className="w-4 h-4 text-red-600" />
          <span>YOUR UNIQUE RECRUITMENT LINK</span>
        </div>

        {/* Link input group */}
        <div className="flex gap-2 items-center" id="link_input_group">
          <input
            type="text"
            readOnly
            value={referralLink}
            className="w-full py-3 px-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 font-semibold select-all outline-none"
            id="ref_link_input"
          />
          <button
            onClick={copyLinkToClipboard}
            className="p-3.5 rounded-xl bg-red-600 text-white border border-red-500/10 hover:bg-red-700 transition shrink-0 flex items-center justify-center cursor-pointer"
            id="btn_copy_link"
            title="Copy Referral Link"
          >
            {copiedLink ? <Check className="w-5 h-5 text-emerald-400" /> : <Copy className="w-5 h-5" />}
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-between sm:items-center pt-2" id="code_input_group">
          <div className="flex items-center gap-3" id="code_display">
            <span className="text-xs text-slate-500 font-semibold uppercase">YOUR INVITE CODE:</span>
            <span className="font-mono text-base font-extrabold text-amber-600 bg-amber-50 px-3 py-1 rounded-lg border border-amber-200">
              {currentUser.referralCode}
            </span>
          </div>
          <button
            onClick={copyCodeToClipboard}
            className="px-4 py-2 rounded-lg bg-slate-50 border border-slate-200 hover:bg-slate-100 text-xs font-bold text-slate-700 transition flex items-center gap-2 self-start sm:self-auto cursor-pointer"
            id="btn_copy_code"
          >
            {copiedCode ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span>CODE COPIED</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-amber-600" />
                <span>COPY INVITE CODE</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Team Aggregation Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4" id="team_statistics_panel">
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-left" id="stat_total_team">
          <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest block">TOTAL TEAM SIZE</span>
          <span className="text-xl font-extrabold text-slate-800 mt-1 block">{totalTeamSize} Member(s)</span>
        </div>

        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-left" id="stat_total_earned_comm">
          <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest block">TOTAL COMMISSIONS</span>
          <span className="text-xl font-extrabold text-emerald-600 mt-1 block">UGX {totalCommissionEarned.toLocaleString()}</span>
        </div>

        <div className="p-4 bg-red-50 rounded-xl border border-red-200 text-left col-span-2 md:col-span-1" id="stat_direct_recruits">
          <span className="text-[9px] text-red-600 font-bold uppercase tracking-widest block">DIRECT RECRUITS (L1)</span>
          <span className="text-xl font-extrabold text-red-800 mt-1 block">{level1Users.length} Member(s)</span>
        </div>
      </div>

      {/* Team Breakdown Lists */}
      <div className="text-left" id="team_breakdown_section">
        <h3 className="text-xs font-black tracking-widest text-slate-600 uppercase mb-3 flex items-center gap-1.5">
          <Network className="w-4 h-4 text-red-600" />
          TEAM NETWORK LEVELS BREAKDOWN
        </h3>

        <div className="space-y-4" id="network_levels_list">
          {/* Level 1 Direct */}
          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm" id="network_l1">
            <div className="flex justify-between items-center mb-2 border-b border-slate-100 pb-2" id="l1_header">
              <span className="text-xs font-bold text-slate-800 tracking-wide">LEVEL 1 DIRECT ASSETS ({level1Users.length})</span>
              <span className="text-[10px] text-red-600 font-semibold">25% Commission Share</span>
            </div>
            {level1Users.length === 0 ? (
              <span className="text-slate-400 text-xs">No direct Level 1 referrals registered.</span>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2" id="l1_user_list">
                {level1Users.map(usr => (
                  <div key={usr.id} className="flex justify-between bg-slate-50 p-2 rounded-lg border border-slate-150 text-xs" id={`l1_user_${usr.id}`}>
                    <span className="font-mono text-slate-700">+{usr.countryCode} {usr.phone}</span>
                    <span className="text-slate-500 font-light">Reg: {new Date(usr.createdAt).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Level 2 Sub-Referrals */}
          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm" id="network_l2">
            <div className="flex justify-between items-center mb-2 border-b border-slate-100 pb-2" id="l2_header">
              <span className="text-xs font-bold text-slate-800 tracking-wide">LEVEL 2 INDIRECT RECRUITS ({level2Users.length})</span>
              <span className="text-[10px] text-slate-600 font-semibold">3% Commission Share</span>
            </div>
            {level2Users.length === 0 ? (
              <span className="text-slate-400 text-xs">No Level 2 referrals registered.</span>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2" id="l2_user_list">
                {level2Users.map(usr => (
                  <div key={usr.id} className="flex justify-between bg-slate-50 p-2 rounded-lg border border-slate-150 text-xs" id={`l2_user_${usr.id}`}>
                    <span className="font-mono text-slate-700">+{usr.countryCode} {usr.phone}</span>
                    <span className="text-slate-500 font-light">Reg: {new Date(usr.createdAt).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Level 3 Sub-Referrals */}
          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm" id="network_l3">
            <div className="flex justify-between items-center mb-2 border-b border-slate-100 pb-2" id="l3_header">
              <span className="text-xs font-bold text-slate-800 tracking-wide">LEVEL 3 DEEP NETWORK ({level3Users.length})</span>
              <span className="text-[10px] text-slate-600 font-semibold">2% Commission Share</span>
            </div>
            {level3Users.length === 0 ? (
              <span className="text-slate-400 text-xs">No Level 3 referrals registered.</span>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2" id="l3_user_list">
                {level3Users.map(usr => (
                  <div key={usr.id} className="flex justify-between bg-slate-50 p-2 rounded-lg border border-slate-150 text-xs" id={`l3_user_${usr.id}`}>
                    <span className="font-mono text-slate-700">+{usr.countryCode} {usr.phone}</span>
                    <span className="text-slate-500 font-light">Reg: {new Date(usr.createdAt).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
};
