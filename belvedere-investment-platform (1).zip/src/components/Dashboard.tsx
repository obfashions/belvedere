/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../state/StateContext';
import { 
  CreditCard, 
  DollarSign, 
  Bell, 
  ArrowRight, 
  HelpCircle, 
  Lock,
  ChevronRight,
  Sparkles,
  ShieldCheck,
  Award,
  BookOpen,
  MessageCircle,
  TrendingUp,
  History
} from 'lucide-react';

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { currentUser, investments, transactions, liveActivities, whatsappLink } = useAppState();
  const [activeSection, setActiveSection] = useState<'none' | 'audit' | 'activity'>('none');

  if (!currentUser) return null;

  // Calculate active products count
  const activeCount = investments.filter(i => i.userId === currentUser.id && i.status === 'active').length;

  // Format live activities for marquee ticker
  const tickerText = liveActivities.map(act => {
    const hiddenPhone = act.phone.replace(/(\+\d{3}|\d{3})\d{4}/, '*****');
    const label = act.type === 'recharge' ? 'Recharge' : act.type === 'withdraw' ? 'Withdrawal' : 'Investment';
    return `${hiddenPhone} ${label} UGX ${act.amount.toLocaleString()}`;
  }).join('   •   ');

  return (
    <div className="w-full max-w-lg mx-auto px-0 pt-0 pb-24 space-y-4" id="bud_dashboard_container">
      
      {/* 1. Header Navigation Buttons (Payment and Withdrawal) */}
      <div className="px-4 pt-3" id="payment_withdraw_grid">
        <div className="grid grid-cols-2 gap-4" id="deposit_withdraw_row">
          
          {/* Payment Card */}
          <button
            onClick={() => {
              localStorage.setItem('payout_active_tab', 'recharge');
              onNavigate('payout');
            }}
            className="bg-white hover:bg-slate-50 active:scale-95 transition-all rounded-xl p-4 flex flex-col items-center justify-center shadow-md cursor-pointer border border-slate-100"
            id="btn_payment_card"
          >
            <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mb-2">
              <CreditCard className="w-6 h-6 text-red-600" />
            </div>
            <span className="text-sm font-extrabold text-slate-800 tracking-wide">Payment</span>
          </button>

          {/* Withdrawal Card */}
          <button
            onClick={() => {
              localStorage.setItem('payout_active_tab', 'withdraw');
              onNavigate('payout');
            }}
            className="bg-white hover:bg-slate-50 active:scale-95 transition-all rounded-xl p-4 flex flex-col items-center justify-center shadow-md cursor-pointer border border-slate-100"
            id="btn_withdrawal_card"
          >
            <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mb-2">
              <div className="w-6 h-6 rounded-full border-2 border-red-600 flex items-center justify-center text-red-600 font-extrabold text-xs">
                $
              </div>
            </div>
            <span className="text-sm font-extrabold text-slate-800 tracking-wide">Withdrawal</span>
          </button>

        </div>
      </div>

      {/* 2. Main Generated Hero Image Banner */}
      <div className="px-4" id="hero_image_container">
        <div className="rounded-2xl overflow-hidden border border-slate-800/20 shadow-lg bg-slate-900 relative aspect-[16/9]" id="hero_banner_wrapper">
          <img 
            src="/src/assets/images/budweiser_banner_1782477094730.jpg" 
            alt="Belvedere Premium Spirits Banner" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />
        </div>
      </div>

      {/* 3. Notification Ticker Banner */}
      <div className="px-4" id="ticker_banner_container">
        <div className="bg-slate-50 border border-slate-150 rounded-xl px-3 py-2.5 flex items-center gap-3 shadow-sm" id="scrolling_ticker_bar">
          <div className="shrink-0 flex items-center justify-center text-red-600" id="ticker_bell">
            <Bell className="w-4 h-4 text-red-600 animate-bounce" />
          </div>
          <div className="flex-1 overflow-hidden" id="marquee_holder">
            {/* HTML Marquee for scrolling text - smooth and natively supported */}
            <marquee className="text-xs text-slate-700 font-semibold tracking-wide" scrollamount="4" id="marquee_text">
              {tickerText || 'Welcome to Belvedere Investment - Standard plan recharge is active!'}
            </marquee>
          </div>
        </div>
      </div>

      {/* 4. Bold Crimson Red Balance and Income Cards */}
      <div className="px-4" id="balance_cards_holder">
        <div className="grid grid-cols-2 gap-4" id="balance_cards_grid">
          
          {/* Card Left: Account Balance */}
          <div className="relative overflow-hidden bg-gradient-to-br from-red-600 to-red-700 rounded-2xl p-4 text-left shadow-lg text-white" id="card_account_balance">
            {/* Crown watermark in the bottom right corner with low opacity */}
            <div className="absolute right-2 bottom-2 text-white/10" id="crown_watermark_left">
              <svg className="w-16 h-16 transform rotate-12" viewBox="0 0 24 24" fill="currentColor">
                <path d="M2 5 L6 13 L12 6 L18 13 L22 5 L17 19 H7 L2 5 Z" />
              </svg>
            </div>
            
            <span className="text-[10px] text-white/80 font-bold tracking-widest uppercase block">
              Account balance
            </span>
            <span className="text-[17px] font-extrabold text-white mt-1 block">
              UGX {currentUser.balance.toLocaleString()}
            </span>
          </div>

          {/* Card Right: Cumulative Income */}
          <div className="relative overflow-hidden bg-gradient-to-br from-red-600 to-red-700 rounded-2xl p-4 text-left shadow-lg text-white" id="card_cumulative_income">
            {/* Crown watermark in the bottom right corner with low opacity */}
            <div className="absolute right-2 bottom-2 text-white/10" id="crown_watermark_right">
              <svg className="w-16 h-16 transform rotate-12" viewBox="0 0 24 24" fill="currentColor">
                <path d="M2 5 L6 13 L12 6 L18 13 L22 5 L17 19 H7 L2 5 Z" />
              </svg>
            </div>
            
            <span className="text-[10px] text-white/80 font-bold tracking-widest uppercase block">
              Cumulative income
            </span>
            <span className="text-[17px] font-extrabold text-white mt-1 block">
              UGX {currentUser.totalRevenue.toLocaleString()}
            </span>
          </div>

        </div>
      </div>

      {/* 5. Second Generated Banner: Support Military Families */}
      <div className="px-4" id="military_support_container">
        <div className="rounded-2xl overflow-hidden border border-slate-800/10 shadow-md bg-slate-950 aspect-[16/9] relative" id="military_banner_wrapper">
          <img 
            src="/src/assets/images/military_support_1782477112100.jpg" 
            alt="Belvedere Supporting Local Trade" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* 6. Accordion/Foldable Secondary Sections for Advanced Management & Auditing */}
      <div className="px-4 space-y-2" id="advanced_home_drawers">
        
        {/* Toggle Financial Audit Summary */}
        <div className="rounded-xl border border-slate-200 bg-slate-50 overflow-hidden shadow-sm" id="drawer_financial_audit">
          <button
            onClick={() => setActiveSection(activeSection === 'audit' ? 'none' : 'audit')}
            className="w-full py-3 px-4 flex items-center justify-between text-left text-slate-700 hover:text-slate-900 transition duration-200"
            id="btn_toggle_audit"
          >
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-red-600" />
              <span className="text-xs font-bold uppercase tracking-widest text-slate-800">Financial Audit Logs</span>
            </div>
            <ChevronRight className={`w-4 h-4 text-slate-500 transition-transform ${activeSection === 'audit' ? 'rotate-90' : ''}`} />
          </button>
          
          {activeSection === 'audit' && (
            <div className="p-4 border-t border-slate-200 bg-white text-left grid grid-cols-2 gap-3" id="audit_content">
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100" id="audit_col_1">
                <span className="text-[9px] text-slate-400 font-bold block uppercase">Recharged</span>
                <span className="text-xs font-bold text-slate-800 font-mono mt-0.5 block">UGX {currentUser.rechargeAmount.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100" id="audit_col_2">
                <span className="text-[9px] text-slate-400 font-bold block uppercase">Withdrawn</span>
                <span className="text-xs font-bold text-slate-800 font-mono mt-0.5 block">UGX {currentUser.withdrawAmount.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100" id="audit_col_3">
                <span className="text-[9px] text-slate-400 font-bold block uppercase">Referrals</span>
                <span className="text-xs font-bold text-[#d4af37] font-mono mt-0.5 block">UGX {currentUser.referralEarnings.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100" id="audit_col_4">
                <span className="text-[9px] text-slate-400 font-bold block uppercase">Active Products</span>
                <span className="text-xs font-bold text-emerald-600 font-mono mt-0.5 block">{activeCount} Pack(s)</span>
              </div>
            </div>
          )}
        </div>

        {/* Toggle WhatsApp Community Info */}
        <div className="rounded-xl border border-slate-200 bg-slate-50 overflow-hidden shadow-sm" id="drawer_whatsapp">
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3 px-4 flex items-center justify-between text-left text-slate-700 hover:text-slate-900 transition duration-200"
            id="wa_direct_link"
          >
            <div className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-emerald-600 animate-pulse" />
              <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">Join Official WhatsApp Group</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </a>
        </div>

      </div>

    </div>
  );
};
