/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../state/StateContext';
import { SPIN_REWARDS } from '../data/products';
import { SUPABASE_SQL_SCHEMA } from '../lib/supabase-schema';
import { 
  Users, 
  Settings, 
  Trash2, 
  Plus, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  MessageSquare, 
  Compass, 
  Gift, 
  Search, 
  ShieldCheck, 
  FileText,
  UserCheck,
  UserX,
  PlusCircle,
  TrendingUp,
  Clock,
  Database,
  Copy,
  RefreshCw,
  Check,
  CloudLightning,
  Upload,
  Image as ImageIcon
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const { 
    users, 
    products, 
    investments, 
    transactions, 
    tickets, 
    announcements, 
    giftCodes, 
    adminUpdateUserBalance, 
    adminResetUserPassword, 
    adminToggleFreezeUser, 
    adminApproveTransaction, 
    replyToTicket,
    adminAddProduct,
    adminAddAnnouncement,
    adminAddGiftCode,
    adminDeleteGiftCode,
    adminDeleteAnnouncement,
    supabaseStatus,
    triggerExportToSupabase,
    refreshSupabaseStatus,
    adminDeleteProduct,
    adminUpdateProduct,
    whatsappLink,
    adminUpdateWhatsappLink,
    wineBannerUrl,
    adminUpdateWineBannerUrl
  } = useAppState();

  const [activeTab, setActiveTab] = useState<'users' | 'withdrawals' | 'products' | 'tickets' | 'vouchers' | 'supabase'>('users');

  // Search user
  const [userSearch, setUserSearch] = useState('');

  // Balance adjustment state
  const [balanceAdjustUserId, setBalanceAdjustUserId] = useState<string | null>(null);
  const [adjustAmount, setAdjustAmount] = useState('');
  const [adjustType, setAdjustType] = useState<'add' | 'subtract'>('add');
  const [adjustFeedback, setAdjustFeedback] = useState('');

  // Password reset state
  const [passResetUserId, setPassResetUserId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [passFeedback, setPassFeedback] = useState('');

  // Ticket reply states
  const [answeringTicketId, setAnsweringTicketId] = useState<string | null>(null);
  const [replyMsg, setReplyMsg] = useState('');

  // Custom Product Creation States
  const [prodName, setProdName] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodPrice, setProdPrice] = useState('');
  const [prodDailyPct, setProdDailyPct] = useState('');
  const [prodCycle, setProdCycle] = useState('');
  const [prodImgUrl, setProdImgUrl] = useState('');
  const [prodFeedback, setProdFeedback] = useState('');

  // Product Editing States
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [editProdName, setEditProdName] = useState('');
  const [editProdDesc, setEditProdDesc] = useState('');
  const [editProdPrice, setEditProdPrice] = useState('');
  const [editProdDailyPct, setEditProdDailyPct] = useState('');
  const [editProdCycle, setEditProdCycle] = useState('');
  const [editProdImgUrl, setEditProdImgUrl] = useState('');
  const [editProdFeedback, setEditProdFeedback] = useState('');

  // WhatsApp group settings state
  const [whatsappInput, setWhatsappInput] = useState(whatsappLink);
  const [whatsappFeedback, setWhatsappFeedback] = useState('');

  // Wine Banner settings state
  const [wineBannerInput, setWineBannerInput] = useState(wineBannerUrl);
  const [wineBannerFeedback, setWineBannerFeedback] = useState('');

  // Announcement States
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annFeedback, setAnnFeedback] = useState('');

  // Voucher Creation States
  const [voucherCode, setVoucherCode] = useState('');
  const [voucherAmt, setVoucherAmt] = useState('');
  const [voucherLimit, setVoucherLimit] = useState('');
  const [voucherFeedback, setVoucherFeedback] = useState('');

  // Drag-and-drop state for product image uploads
  const [isDraggingNew, setIsDraggingNew] = useState(false);
  const [isDraggingEdit, setIsDraggingEdit] = useState(false);

  const handleFileChange = (file: File | undefined, isEdit: boolean) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        if (isEdit) {
          setEditProdImgUrl(reader.result);
        } else {
          setProdImgUrl(reader.result);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  // Supabase feedback states
  const [copied, setCopied] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportMessage, setExportMessage] = useState('');

  // Filter users by search
  const filteredUsers = users.filter(u => 
    u.phone.includes(userSearch) || 
    (u.referralCode && u.referralCode.includes(userSearch.toUpperCase()))
  );

  // Filter pending cashouts
  const pendingCashouts = transactions.filter(t => t.type === 'withdraw' && t.status === 'pending');

  // Filter open tickets
  const openTickets = tickets.filter(t => t.status === 'open');

  // Handle balance adjustment
  const handleAdjustBalanceSubmit = (userId: string) => {
    const amt = parseInt(adjustAmount, 10);
    if (isNaN(amt) || amt <= 0) {
      setAdjustFeedback('Please enter a valid amount.');
      return;
    }

    const multiplier = adjustType === 'add' ? 1 : -1;
    const res = adminUpdateUserBalance(userId, amt * multiplier);
    if (res.success) {
      setAdjustFeedback(`Successfully adjusted wallet by UGX ${(amt * multiplier).toLocaleString()}!`);
      setAdjustAmount('');
      setTimeout(() => {
        setAdjustFeedback('');
        setBalanceAdjustUserId(null);
      }, 2500);
    } else {
      setAdjustFeedback(res.error || 'Failed to adjust balance.');
    }
  };

  // Handle password reset
  const handlePassResetSubmit = (userId: string) => {
    if (!newPassword || newPassword.length < 4) {
      setPassFeedback('Password must be at least 4 characters long.');
      return;
    }

    const res = adminResetUserPassword(userId, newPassword);
    if (res.success) {
      setPassFeedback(`User password updated to: ${newPassword}`);
      setNewPassword('');
      setTimeout(() => {
        setPassFeedback('');
        setPassResetUserId(null);
      }, 2500);
    } else {
      setPassFeedback(res.error || 'Failed to reset password.');
    }
  };

  // Handle answering tickets
  const handleSendTicketReply = (ticketId: string) => {
    if (!replyMsg.trim()) return;

    const res = replyToTicket(ticketId, replyMsg, 'admin');
    if (res.success) {
      setReplyMsg('');
      setAnsweringTicketId(null);
    }
  };

  // Create new product plan
  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setProdFeedback('');

    const price = parseInt(prodPrice, 10);
    const dailyReturnPct = parseFloat(prodDailyPct);
    const cycleDays = parseInt(prodCycle, 10);

    if (!prodName || !prodDesc || isNaN(price) || isNaN(dailyReturnPct) || isNaN(cycleDays)) {
      setProdFeedback('All fields must be filled with correct formats.');
      return;
    }

    const fallbackImg = 'https://images.unsplash.com/photo-1569058242253-92a9c755a0ec?auto=format&fit=crop&q=80&w=600';
    const finalImg = prodImgUrl.trim() || fallbackImg;

    const res = adminAddProduct({
      name: prodName,
      description: prodDesc,
      price,
      dailyReturnPercent: dailyReturnPct,
      cycleDays,
      imageUrl: finalImg
    });

    if (res.success) {
      setProdFeedback(`Product "${prodName}" added successfully!`);
      setProdName('');
      setProdDesc('');
      setProdPrice('');
      setProdDailyPct('');
      setProdCycle('');
      setProdImgUrl('');
    } else {
      setProdFeedback(res.error || 'Failed to create plan.');
    }
  };

  // Create Announcement
  const handleCreateAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    setAnnFeedback('');

    if (!annTitle.trim() || !annContent.trim()) {
      setAnnFeedback('Please enter title and content.');
      return;
    }

    const res = adminAddAnnouncement(annTitle, annContent);
    if (res.success) {
      setAnnFeedback('Announcement published globally!');
      setAnnTitle('');
      setAnnContent('');
    } else {
      setAnnFeedback(res.error || 'Failed to publish.');
    }
  };

  // Create Voucher code
  const handleCreateVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    setVoucherFeedback('');

    const amt = parseInt(voucherAmt, 10);
    const limit = parseInt(voucherLimit, 10);

    if (!voucherCode.trim() || isNaN(amt) || isNaN(limit)) {
      setVoucherFeedback('Invalid inputs. Enter a word code, a UGX cash amount, and a usage count.');
      return;
    }

    const res = adminAddGiftCode(voucherCode.toUpperCase().trim(), amt, limit);
    if (res.success) {
      setVoucherFeedback(`Voucher "${voucherCode.toUpperCase()}" created successfully!`);
      setVoucherCode('');
      setVoucherAmt('');
      setVoucherLimit('');
    } else {
      setVoucherFeedback(res.error || 'Failed to create voucher.');
    }
  };

  // Handle Edit Product Plan
  const handleEditProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProductId) return;
    setEditProdFeedback('');

    const price = parseInt(editProdPrice, 10);
    const dailyReturnPct = parseFloat(editProdDailyPct);
    const cycleDays = parseInt(editProdCycle, 10);

    if (!editProdName || !editProdDesc || isNaN(price) || isNaN(dailyReturnPct) || isNaN(cycleDays)) {
      setEditProdFeedback('All fields must be filled with correct formats.');
      return;
    }

    adminUpdateProduct(editingProductId, {
      name: editProdName,
      description: editProdDesc,
      price,
      dailyReturnPercent: dailyReturnPct,
      cycleDays,
      imageUrl: editProdImgUrl.trim()
    });

    setEditProdFeedback('Investment plan updated successfully!');
    setTimeout(() => {
      setEditingProductId(null);
      setEditProdFeedback('');
    }, 2000);
  };

  // Handle WhatsApp Link save
  const handleUpdateWhatsapp = (e: React.FormEvent) => {
    e.preventDefault();
    setWhatsappFeedback('');
    if (!whatsappInput.trim().startsWith('http')) {
      setWhatsappFeedback('Please enter a valid URL (starting with http:// or https://).');
      return;
    }
    adminUpdateWhatsappLink(whatsappInput.trim());
    setWhatsappFeedback('WhatsApp join link updated successfully!');
    setTimeout(() => setWhatsappFeedback(''), 3000);
  };

  // Handle Wine Banner Image URL save
  const handleUpdateWineBanner = (e: React.FormEvent) => {
    e.preventDefault();
    setWineBannerFeedback('');
    if (!wineBannerInput.trim().startsWith('http')) {
      setWineBannerFeedback('Please enter a valid URL (starting with http:// or https://).');
      return;
    }
    adminUpdateWineBannerUrl(wineBannerInput.trim());
    setWineBannerFeedback('Wine banner image URL updated successfully!');
    setTimeout(() => setWineBannerFeedback(''), 3000);
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 pt-2.5 pb-24 space-y-6 text-left" id="admin_panel_container">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-4" id="admin_title_header">
        <div>
          <span className="text-[10px] font-black tracking-widest text-[#d4af37] uppercase bg-[#d4af37]/10 px-2.5 py-1 rounded">MASTER COMMAND CENTER</span>
          <h2 className="text-2xl font-bold tracking-tight text-white mt-2">
            Belvedere Administration Suite
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Supervise financial ledgers, approve user payouts, inspect tickets, and modify drink assets portfolios instantly.
          </p>
        </div>
        
        {/* Status indicator */}
        <div className="px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-500/20 text-xs font-bold text-emerald-400 flex items-center gap-1.5" id="admin_sec_badge">
          <ShieldCheck className="w-4 h-4" />
          <span>ADMIN PRIVILEGES GRANTED</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10" id="admin_tabs">
        <button
          onClick={() => setActiveTab('users')}
          className={`flex-1 pb-3 text-center text-xs font-bold tracking-wider transition ${activeTab === 'users' ? 'text-white border-b-2 border-[#d4af37]' : 'text-slate-400 hover:text-white'}`}
          id="admin_tab_users"
        >
          <Users className="inline-block w-4 h-4 mr-1.5 -mt-0.5 text-blue-400" />
          USER BASE ({users.length})
        </button>
        <button
          onClick={() => setActiveTab('withdrawals')}
          className={`flex-1 pb-3 text-center text-xs font-bold tracking-wider transition relative ${activeTab === 'withdrawals' ? 'text-white border-b-2 border-[#d4af37]' : 'text-slate-400 hover:text-white'}`}
          id="admin_tab_withdrawals"
        >
          <Clock className="inline-block w-4 h-4 mr-1.5 -mt-0.5 text-emerald-400" />
          CASHOUTS ({pendingCashouts.length})
          {pendingCashouts.length > 0 && (
            <span className="absolute top-0 right-2 bg-red-500 text-white font-mono text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
              {pendingCashouts.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('products')}
          className={`flex-1 pb-3 text-center text-xs font-bold tracking-wider transition ${activeTab === 'products' ? 'text-white border-b-2 border-[#d4af37]' : 'text-slate-400 hover:text-white'}`}
          id="admin_tab_products"
        >
          <Compass className="inline-block w-4 h-4 mr-1.5 -mt-0.5 text-indigo-400" />
          PRODUCTS & ANNOUNCEMENTS
        </button>
        <button
          onClick={() => setActiveTab('tickets')}
          className={`flex-1 pb-3 text-center text-xs font-bold tracking-wider transition relative ${activeTab === 'tickets' ? 'text-white border-b-2 border-[#d4af37]' : 'text-slate-400 hover:text-white'}`}
          id="admin_tab_tickets"
        >
          <MessageSquare className="inline-block w-4 h-4 mr-1.5 -mt-0.5 text-[#d4af37]" />
          TICKETS ({openTickets.length})
          {openTickets.length > 0 && (
            <span className="absolute top-0 right-2 bg-amber-500 text-black font-mono text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
              {openTickets.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('vouchers')}
          className={`flex-1 pb-3 text-center text-xs font-bold tracking-wider transition ${activeTab === 'vouchers' ? 'text-white border-b-2 border-[#d4af37]' : 'text-slate-400 hover:text-white'}`}
          id="admin_tab_vouchers"
        >
          <Gift className="inline-block w-4 h-4 mr-1.5 -mt-0.5 text-amber-400" />
          GIFT CODES
        </button>
        <button
          onClick={() => setActiveTab('supabase')}
          className={`flex-1 pb-3 text-center text-xs font-bold tracking-wider transition ${activeTab === 'supabase' ? 'text-white border-b-2 border-[#d4af37]' : 'text-slate-400 hover:text-white'}`}
          id="admin_tab_supabase"
        >
          <Settings className="inline-block w-4 h-4 mr-1.5 -mt-0.5 text-[#d4af37]" />
          SUPABASE SYNC
        </button>
      </div>

      {/* Aggregate metrics for administrative overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="admin_aggregate_grid">
        <div className="p-4 bg-slate-900/40 rounded-xl border border-white/5" id="stat_total_accounts">
          <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest block">REGISTERED USERS</span>
          <span className="text-xl font-extrabold text-white mt-1 block font-mono">{users.length} accounts</span>
        </div>

        <div className="p-4 bg-slate-900/40 rounded-xl border border-white/5" id="stat_total_purchases">
          <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest block">ACTIVE TRANSACTIONS</span>
          <span className="text-xl font-extrabold text-emerald-400 mt-1 block font-mono">{investments.length} plans</span>
        </div>

        <div className="p-4 bg-[#0c1f44]/40 rounded-xl border border-blue-500/10" id="stat_escrow_pool">
          <span className="text-[9px] text-blue-400 font-bold uppercase tracking-widest block">ACTIVE ESCROW VOLUME</span>
          <span className="text-xl font-extrabold text-white mt-1 block font-mono">
            UGX {investments.reduce((acc, curr) => acc + curr.purchasePrice, 0).toLocaleString()}
          </span>
        </div>

        <div className="p-4 bg-slate-900/40 rounded-xl border border-white/5" id="stat_system_tickets">
          <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest block">OPEN SYSTEM QUERIES</span>
          <span className="text-xl font-bold text-amber-400 mt-1 block font-mono">{openTickets.length} unresolved</span>
        </div>
      </div>

      {/* Panels content */}

      {/* USERS MANAGEMENT */}
      {activeTab === 'users' && (
        <div className="space-y-4" id="admin_users_panel">
          {/* Search tool */}
          <div className="relative flex items-center bg-black/40 border border-white/10 rounded-xl" id="admin_user_search">
            <Search className="absolute left-4 text-slate-500 w-4 h-4 pointer-events-none" />
            <input
              type="text"
              placeholder="Search user profile by Ugandan phone code number or Invite code..."
              value={userSearch}
              onChange={e => setUserSearch(e.target.value)}
              className="w-full bg-transparent py-3.5 pl-12 pr-4 text-white text-xs outline-none focus:ring-0 placeholder:text-slate-600 font-semibold"
              id="user_search_input"
            />
          </div>

          <div className="bg-slate-900/40 border border-white/10 rounded-2xl overflow-x-auto" id="users_table_container">
            <table className="w-full text-xs text-left text-slate-300" id="users_table">
              <thead className="text-[9px] text-slate-500 uppercase bg-black/25 border-b border-white/5 tracking-widest font-black" id="users_thead">
                <tr>
                  <th className="px-4 py-3">PHONE NUMBER</th>
                  <th className="px-4 py-3">SPENDABLE BALANCE</th>
                  <th className="px-4 py-3">INCOME YIELD</th>
                  <th className="px-4 py-3">INVITE CODE</th>
                  <th className="px-4 py-3">REFERRED BY</th>
                  <th className="px-4 py-3">STATUS</th>
                  <th className="px-4 py-3 text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5" id="users_tbody">
                {filteredUsers.map((usr) => (
                  <tr key={usr.id} className="hover:bg-white/5 transition" id={`user_row_${usr.id}`}>
                    <td className="px-4 py-3 font-mono font-bold text-white">
                      <div>+{usr.countryCode} {usr.phone}</div>
                      <div className="text-[10px] text-slate-500 font-sans font-normal mt-0.5">
                        Pass: <span className="font-mono text-[#d4af37] font-semibold">{JSON.parse(localStorage.getItem('bel_passwords') || '{}')[usr.id] || 'admin123'}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono text-blue-400 font-semibold">
                      UGX {usr.balance.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 font-mono text-emerald-400">
                      UGX {usr.incomeBalance.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 font-mono font-bold text-amber-500">
                      {usr.referralCode}
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-500">
                      {usr.referredBy || 'Direct'}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase ${usr.isFrozen ? 'bg-red-950 text-red-400 border border-red-500/30' : 'bg-emerald-950 text-emerald-400 border border-emerald-500/20'}`}>
                        {usr.isFrozen ? 'Frozen' : 'Active'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right space-x-1.5 shrink-0 whitespace-nowrap">
                      {/* Adjust balance button */}
                      <button
                        onClick={() => { setBalanceAdjustUserId(usr.id); setAdjustFeedback(''); }}
                        className="px-2 py-1 bg-blue-900/30 text-blue-400 border border-blue-500/20 hover:bg-blue-800/40 rounded transition uppercase text-[9px] font-bold cursor-pointer"
                        id={`btn_adjust_${usr.id}`}
                      >
                        Adjust Wallet
                      </button>

                      {/* Password reset button */}
                      <button
                        onClick={() => { setPassResetUserId(usr.id); setPassFeedback(''); }}
                        className="px-2 py-1 bg-slate-800 text-slate-300 border border-white/5 hover:bg-slate-700 rounded transition uppercase text-[9px] font-bold cursor-pointer"
                        id={`btn_pass_${usr.id}`}
                      >
                        Pass
                      </button>

                      {/* Freeze toggle */}
                      <button
                        onClick={() => adminToggleFreezeUser(usr.id)}
                        className={`px-2 py-1 rounded border transition uppercase text-[9px] font-bold cursor-pointer ${usr.isFrozen ? 'bg-green-950/40 text-green-400 border-green-500/20' : 'bg-red-950/40 text-red-400 border-red-500/20'}`}
                        id={`btn_freeze_${usr.id}`}
                      >
                        {usr.isFrozen ? 'Unfreeze' : 'Freeze'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Balance adjustment Dialogue */}
          {balanceAdjustUserId && (
            <div className="p-5 rounded-2xl bg-[#0c1f44] border border-blue-500/30 space-y-4" id="adjust_balance_modal">
              <div className="flex justify-between items-center" id="adjust_hdr">
                <h4 className="font-bold text-white text-sm">Adjust Spendable Balance</h4>
                <button onClick={() => setBalanceAdjustUserId(null)} className="text-xs text-slate-400 hover:text-white">✕ Close</button>
              </div>

              {adjustFeedback && (
                <p className="text-xs font-bold text-emerald-400">{adjustFeedback}</p>
              )}

              <div className="flex flex-col sm:flex-row gap-3 items-center" id="adjust_form">
                <select
                  value={adjustType}
                  onChange={e => setAdjustType(e.target.value as 'add' | 'subtract')}
                  className="w-full sm:w-auto bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs text-white"
                  id="adjust_select_type"
                >
                  <option value="add">Add Cash (+)</option>
                  <option value="subtract">Subtract Cash (-)</option>
                </select>

                <input
                  type="number"
                  placeholder="Amount (UGX)"
                  value={adjustAmount}
                  onChange={e => setAdjustAmount(e.target.value.replace(/\D/g, ''))}
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs text-white"
                  id="adjust_amount_input"
                />

                <button
                  onClick={() => handleAdjustBalanceSubmit(balanceAdjustUserId)}
                  className="w-full sm:w-auto py-3 px-5 bg-blue-700 hover:bg-blue-600 border border-blue-500/20 text-white font-bold text-xs uppercase rounded-xl cursor-pointer"
                  id="adjust_submit"
                >
                  Apply Adjustment
                </button>
              </div>
            </div>
          )}

          {/* Password reset Dialogue */}
          {passResetUserId && (
            <div className="p-5 rounded-2xl bg-slate-900 border border-white/10 space-y-4" id="reset_password_modal">
              <div className="flex justify-between items-center" id="reset_pass_hdr">
                <h4 className="font-bold text-white text-sm">Reset Password for User</h4>
                <button onClick={() => setPassResetUserId(null)} className="text-xs text-slate-400 hover:text-white">✕ Close</button>
              </div>

              {passFeedback && (
                <p className="text-xs font-bold text-emerald-400">{passFeedback}</p>
              )}

              <div className="flex flex-col sm:flex-row gap-3 items-center" id="reset_pass_form">
                <input
                  type="text"
                  placeholder="New Security Password"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs text-white"
                  id="new_pass_input"
                />

                <button
                  onClick={() => handlePassResetSubmit(passResetUserId)}
                  className="w-full sm:w-auto py-3 px-5 bg-[#d4af37] hover:bg-[#b5952d] text-black font-extrabold text-xs uppercase rounded-xl cursor-pointer"
                  id="new_pass_submit"
                >
                  Apply Reset
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* WITHDRAWALS APPROVAL */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4" id="admin_withdrawals_panel">
          <h3 className="text-xs font-black tracking-widest text-slate-400 uppercase mb-3">
            PENDING CASHOUT APPROVAL QUEUE ({pendingCashouts.length})
          </h3>

          {pendingCashouts.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-900/20 border border-white/5 text-center text-slate-500 text-sm" id="no_pending_payouts">
              <CheckCircle className="w-10 h-10 mx-auto text-slate-600 mb-2" />
              <p>There are no pending mobile money cashout requests currently.</p>
            </div>
          ) : (
            <div className="space-y-3" id="pending_withdrawals_list">
              {pendingCashouts.map((tx) => (
                <div key={tx.id} className="p-4 rounded-xl bg-gradient-to-r from-slate-900 to-black border border-white/10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" id={`pending_tx_${tx.id}`}>
                  <div id="pending_tx_left">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">+{tx.countryCode || '256'} {tx.userPhone}</span>
                      <span className="px-1.5 py-0.5 rounded bg-amber-500/10 text-[#d4af37] text-[8px] font-bold uppercase border border-amber-500/20">PENDING PAYOUT</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">
                      Dest: {tx.paymentMethod} (+256 {tx.description.split('+256')[1] || ''}) • Date: {new Date(tx.createdAt).toLocaleDateString()}
                    </p>
                    <div className="flex items-center gap-4 mt-2 text-[10px]" id="pending_tx_values">
                      <div><span className="text-slate-500 uppercase">Gross:</span> <span className="font-mono text-slate-300">UGX {tx.amount.toLocaleString()}</span></div>
                      <div><span className="text-slate-500 uppercase">10% Fee:</span> <span className="font-mono text-rose-400">UGX {tx.fee.toLocaleString()}</span></div>
                      <div><span className="text-slate-500 uppercase">Net receive:</span> <span className="font-mono text-emerald-400 font-bold">UGX {tx.netAmount.toLocaleString()}</span></div>
                    </div>
                  </div>

                  <div className="flex gap-2 shrink-0 self-end sm:self-auto" id="pending_tx_actions">
                    <button
                      onClick={() => adminApproveTransaction(tx.id, 'completed')}
                      className="px-3 py-2 bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-900/40 rounded-xl font-bold uppercase text-[10px] tracking-wider transition cursor-pointer flex items-center gap-1"
                      id={`approve_btn_${tx.id}`}
                    >
                      <CheckCircle className="w-4 h-4" />
                      Approve MM
                    </button>
                    <button
                      onClick={() => adminApproveTransaction(tx.id, 'rejected')}
                      className="px-3 py-2 bg-red-950/40 text-red-400 border border-red-500/30 hover:bg-red-900/40 rounded-xl font-bold uppercase text-[10px] tracking-wider transition cursor-pointer flex items-center gap-1"
                      id={`reject_btn_${tx.id}`}
                    >
                      <XCircle className="w-4 h-4" />
                      Decline & Refund
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PRODUCTS & ANNOUNCEMENTS CREATION */}
      {activeTab === 'products' && (
        <>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fadeIn" id="admin_products_panel">
          
          {/* Create Product Plan Card */}
          <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 text-left space-y-4" id="create_product_card">
            <h3 className="text-sm font-extrabold text-white uppercase border-b border-white/5 pb-2 flex items-center gap-2">
              <PlusCircle className="w-5 h-5 text-blue-400" />
              CREATE CUSTOM INVESTMENT PLAN
            </h3>

            {prodFeedback && <p className="text-xs font-bold text-emerald-400">{prodFeedback}</p>}

            <form onSubmit={handleCreateProduct} className="space-y-4" id="product_create_form">
              <div>
                <label className="block text-[10px] font-bold text-slate-300 mb-1">PLAN NAME</label>
                <input
                  type="text"
                  placeholder="E.g. Belvedere Organic Infusions"
                  value={prodName}
                  onChange={e => setProdName(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                  id="add_prod_name"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-300 mb-1">DESCRIPTION</label>
                <textarea
                  rows={2}
                  placeholder="Summarize beverage asset quality..."
                  value={prodDesc}
                  onChange={e => setProdDesc(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                  id="add_prod_desc"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-3" id="add_prod_inputs_row">
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">PRICE (UGX)</label>
                  <input
                    type="number"
                    placeholder="E.g. 150000"
                    value={prodPrice}
                    onChange={e => setProdPrice(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                    id="add_prod_price"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">DAILY (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="E.g. 4.25"
                    value={prodDailyPct}
                    onChange={e => setProdDailyPct(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                    id="add_prod_pct"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">CYCLE (DAYS)</label>
                  <input
                    type="number"
                    placeholder="E.g. 50"
                    value={prodCycle}
                    onChange={e => setProdCycle(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                    id="add_prod_cycle"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-300 mb-1">UPLOAD PLAN IMAGE</label>
                <div 
                  className={`relative border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center transition cursor-pointer ${
                    isDraggingNew 
                      ? 'border-blue-500 bg-blue-500/10' 
                      : prodImgUrl 
                        ? 'border-emerald-500/50 bg-emerald-500/5' 
                        : 'border-white/10 hover:border-white/25 bg-black/40'
                  }`}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDraggingNew(true);
                  }}
                  onDragLeave={() => setIsDraggingNew(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDraggingNew(false);
                    const file = e.dataTransfer.files?.[0];
                    handleFileChange(file, false);
                  }}
                  onClick={() => document.getElementById('add_prod_image_file')?.click()}
                  id="add_prod_image_dropzone"
                >
                  <input 
                    type="file" 
                    id="add_prod_image_file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      handleFileChange(file, false);
                    }}
                  />
                  
                  {prodImgUrl ? (
                    <div className="w-full flex items-center gap-3" id="add_prod_preview_container">
                      <img 
                        src={prodImgUrl} 
                        alt="Preview" 
                        className="w-12 h-12 rounded-lg object-cover border border-white/10 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 min-w-0 text-left">
                        <p className="text-[10px] font-bold text-emerald-400">✓ Image Uploaded Successfully</p>
                        <p className="text-[9px] text-slate-500 truncate">Click or drag new file to replace</p>
                      </div>
                      <button 
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setProdImgUrl('');
                        }}
                        className="p-1 rounded bg-red-950/60 border border-red-500/30 text-red-400 hover:text-white hover:bg-red-900 text-[10px]"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div className="text-center py-2 space-y-1" id="add_prod_upload_prompt">
                      <Upload className="w-5 h-5 text-slate-400 mx-auto animate-pulse" />
                      <p className="text-[11px] text-slate-300 font-medium">Drag & drop plan image, or <span className="text-blue-400 underline">browse</span></p>
                      <p className="text-[9px] text-slate-500">Supports PNG, JPG, JPEG, GIF</p>
                    </div>
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-700 hover:bg-blue-600 border border-blue-500/20 text-white font-bold text-xs uppercase rounded-xl cursor-pointer"
                id="add_prod_submit"
              >
                DEPLOY BEVERAGE INVESTMENT CONTRACT
              </button>
            </form>
          </div>

          {/* Create Global Announcement Card */}
          <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 text-left space-y-4 flex flex-col justify-between" id="create_announcement_card">
            
            <div className="space-y-4" id="create_ann_body">
              <h3 className="text-sm font-extrabold text-white uppercase border-b border-white/5 pb-2 flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                PUBLISH SYSTEM ANNOUNCEMENT
              </h3>

              {annFeedback && <p className="text-xs font-bold text-emerald-400">{annFeedback}</p>}

              <form onSubmit={handleCreateAnnouncement} className="space-y-4" id="announcement_create_form">
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">TITLE</label>
                  <input
                    type="text"
                    placeholder="E.g. System Audit Complete"
                    value={annTitle}
                    onChange={e => setAnnTitle(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                    id="add_ann_title"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">CONTENT</label>
                  <textarea
                    rows={4}
                    placeholder="Write announcement body details for dashboards..."
                    value={annContent}
                    onChange={e => setAnnContent(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                    id="add_ann_content"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-indigo-700 hover:bg-indigo-600 border border-indigo-500/20 text-white font-bold text-xs uppercase rounded-xl cursor-pointer"
                  id="add_ann_submit"
                >
                  PUBLISH GLOBALLY
                </button>
              </form>
            </div>

            {/* List and delete existing announcements */}
            <div className="space-y-2 mt-6 border-t border-white/5 pt-4" id="announcements_list_box">
              <h4 className="font-bold text-slate-400 uppercase tracking-widest text-[9px]">Existing Announcements ({announcements.length})</h4>
              <div className="max-h-[120px] overflow-y-auto space-y-1 text-xs" id="announcements_inner_list">
                {announcements.map(ann => (
                  <div key={ann.id} className="flex justify-between items-center bg-black/20 p-2 rounded-lg border border-white/5" id={`ann_log_${ann.id}`}>
                    <span className="truncate max-w-[180px] font-semibold text-slate-300">{ann.title}</span>
                    <button onClick={() => adminDeleteAnnouncement(ann.id)} className="p-1 text-red-400 hover:text-red-300 cursor-pointer" title="Delete">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* WhatsApp Link Configuration Card */}
            <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 text-left space-y-4 mt-6 animate-fadeIn" id="whatsapp_settings_card">
              <h3 className="text-sm font-extrabold text-white uppercase border-b border-white/5 pb-2 flex items-center gap-2">
                <span className="w-5 h-5 text-emerald-400 font-extrabold">☏</span>
                WHATSAPP GROUP CONFIGURATION
              </h3>
              
              <p className="text-xs text-slate-400 font-sans leading-relaxed">
                Provide the invitation link for the official Belvedere VIP investors WhatsApp discussion group. This button will show up on user dashboards.
              </p>

              {whatsappFeedback && <p className="text-xs font-bold text-emerald-400">{whatsappFeedback}</p>}

              <form onSubmit={handleUpdateWhatsapp} className="space-y-4" id="whatsapp_update_form">
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">WHATSAPP INVITATION LINK</label>
                  <input
                    type="text"
                    placeholder="https://chat.whatsapp.com/..."
                    value={whatsappInput}
                    onChange={e => setWhatsappInput(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-emerald-400 font-mono"
                    id="update_wa_link"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 border border-emerald-500/20 text-white font-bold text-xs uppercase rounded-xl cursor-pointer"
                  id="update_wa_submit"
                >
                  SAVE WHATSAPP LINK
                </button>
              </form>
            </div>

            {/* Wine Banner Image Configuration Card */}
            <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 text-left space-y-4 mt-6 animate-fadeIn" id="wine_banner_settings_card">
              <h3 className="text-sm font-extrabold text-white uppercase border-b border-white/5 pb-2 flex items-center gap-2">
                <span className="w-5 h-5 text-amber-400 font-extrabold">🖼</span>
                WINE BANNER IMAGE CONFIGURATION
              </h3>
              
              <p className="text-xs text-slate-400 font-sans leading-relaxed">
                Provide the URL of the primary elegant wine illustration or photo banner displayed on the user dashboard.
              </p>

              {wineBannerFeedback && <p className="text-xs font-bold text-amber-400">{wineBannerFeedback}</p>}

              <form onSubmit={handleUpdateWineBanner} className="space-y-4" id="wine_banner_update_form">
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">BANNER IMAGE URL</label>
                  <input
                    type="text"
                    placeholder="https://images.unsplash.com/photo-..."
                    value={wineBannerInput}
                    onChange={e => setWineBannerInput(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-amber-400 font-mono"
                    id="update_wine_banner_url_input"
                    required
                  />
                </div>

                {wineBannerInput.trim().startsWith('http') && (
                  <div className="space-y-1.5" id="banner_preview_box">
                    <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider">LIVE BANNER PREVIEW:</span>
                    <div className="relative h-24 w-full rounded-xl overflow-hidden border border-white/5 bg-slate-950/80">
                      <img
                        src={wineBannerInput.trim()}
                        alt="Wine Banner Preview"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1200&q=80';
                        }}
                      />
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#d4af37] hover:bg-[#b5952d] border border-amber-500/20 text-black font-black text-xs uppercase rounded-xl cursor-pointer transition-all duration-300"
                  id="update_wine_banner_submit"
                >
                  SAVE WINE BANNER IMAGE
                </button>
              </form>
            </div>

          </div>

        </div>

        {/* Edit Plan Modal Overlay */}
        {editingProductId && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn" id="edit_plan_modal_overlay">
            <div className="bg-slate-950 border border-white/10 p-6 rounded-2xl w-full max-w-lg space-y-4 shadow-2xl" id="edit_plan_modal">
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">EDIT INVESTMENT PLAN</h3>
                <button onClick={() => setEditingProductId(null)} className="text-xs text-slate-500 hover:text-white transition">✕ Close</button>
              </div>

              {editProdFeedback && <p className="text-xs font-bold text-emerald-400">{editProdFeedback}</p>}

              <form onSubmit={handleEditProductSubmit} className="space-y-4" id="product_edit_form">
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">PLAN NAME</label>
                  <input
                    type="text"
                    value={editProdName}
                    onChange={e => setEditProdName(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">DESCRIPTION</label>
                  <textarea
                    rows={2}
                    value={editProdDesc}
                    onChange={e => setEditProdDesc(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                    required
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-1">PRICE (UGX)</label>
                    <input
                      type="number"
                      value={editProdPrice}
                      onChange={e => setEditProdPrice(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-1">DAILY (%)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={editProdDailyPct}
                      onChange={e => setEditProdDailyPct(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-1">CYCLE (DAYS)</label>
                    <input
                      type="number"
                      value={editProdCycle}
                      onChange={e => setEditProdCycle(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">UPLOAD PLAN IMAGE</label>
                  <div 
                    className={`relative border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center transition cursor-pointer ${
                      isDraggingEdit 
                        ? 'border-blue-500 bg-blue-500/10' 
                        : editProdImgUrl 
                          ? 'border-emerald-500/50 bg-emerald-500/5' 
                          : 'border-white/10 hover:border-white/25 bg-black/40'
                    }`}
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDraggingEdit(true);
                    }}
                    onDragLeave={() => setIsDraggingEdit(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setIsDraggingEdit(false);
                      const file = e.dataTransfer.files?.[0];
                      handleFileChange(file, true);
                    }}
                    onClick={() => document.getElementById('edit_prod_image_file')?.click()}
                    id="edit_prod_image_dropzone"
                  >
                    <input 
                      type="file" 
                      id="edit_prod_image_file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        handleFileChange(file, true);
                      }}
                    />
                    
                    {editProdImgUrl ? (
                      <div className="w-full flex items-center gap-3" id="edit_prod_preview_container">
                        <img 
                          src={editProdImgUrl} 
                          alt="Preview" 
                          className="w-12 h-12 rounded-lg object-cover border border-white/10 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0 text-left">
                          <p className="text-[10px] font-bold text-emerald-400">✓ Image Uploaded Successfully</p>
                          <p className="text-[9px] text-slate-500 truncate">Click or drag new file to replace</p>
                        </div>
                        <button 
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditProdImgUrl('');
                          }}
                          className="p-1 rounded bg-red-950/60 border border-red-500/30 text-red-400 hover:text-white hover:bg-red-900 text-[10px]"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <div className="text-center py-2 space-y-1" id="edit_prod_upload_prompt">
                        <Upload className="w-5 h-5 text-slate-400 mx-auto animate-pulse" />
                        <p className="text-[11px] text-slate-300 font-medium">Drag & drop plan image, or <span className="text-blue-400 underline">browse</span></p>
                        <p className="text-[9px] text-slate-500">Supports PNG, JPG, JPEG, GIF</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingProductId(null)}
                    className="py-2.5 px-4 bg-slate-800 text-slate-300 text-xs font-bold uppercase rounded-xl hover:bg-slate-700 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="py-2.5 px-5 bg-blue-700 text-white text-xs font-bold uppercase rounded-xl hover:bg-blue-600 transition"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* List existing plans for edits */}
        <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 text-left space-y-4 mt-8" id="manage_plans_full_card">
          <h3 className="text-sm font-extrabold text-white uppercase border-b border-white/5 pb-2 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#d4af37]" />
            MANAGE & EDIT INVESTMENT PLANS
          </h3>
          
          <p className="text-xs text-slate-400 font-sans">
            Edit beverage photos, change investment pricing, modify cycles, adjust daily percentages, or retire old packages.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="admin_plans_grid">
            {products.map(p => (
              <div key={p.id} className="p-4 bg-black/30 border border-white/5 rounded-xl flex flex-col justify-between space-y-4" id={`plan_card_${p.id}`}>
                <div className="space-y-3">
                  <div className="h-32 rounded-lg bg-cover bg-center border border-white/5" style={{ backgroundImage: `url(${p.imageUrl})` }}></div>
                  <div>
                    <h4 className="font-extrabold text-white text-sm">{p.name}</h4>
                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">{p.description}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px] font-mono border-t border-white/5 pt-2">
                    <div><span className="text-slate-500 uppercase">Price:</span> <span className="text-slate-300">UGX {p.price.toLocaleString()}</span></div>
                    <div><span className="text-slate-500 uppercase">Daily:</span> <span className="text-emerald-400">{p.dailyReturnPercent}%</span></div>
                    <div><span className="text-slate-500 uppercase">Cycle:</span> <span className="text-[#d4af37]">{p.cycleDays} Days</span></div>
                    <div><span className="text-slate-500 uppercase">Total:</span> <span className="text-blue-400">UGX {p.totalEarnings.toLocaleString()}</span></div>
                  </div>
                </div>

                <div className="flex gap-2 border-t border-white/5 pt-3">
                  <button
                    onClick={() => {
                      setEditingProductId(p.id);
                      setEditProdName(p.name);
                      setEditProdDesc(p.description);
                      setEditProdPrice(p.price.toString());
                      setEditProdDailyPct(p.dailyReturnPercent.toString());
                      setEditProdCycle(p.cycleDays.toString());
                      setEditProdImgUrl(p.imageUrl);
                      setEditProdFeedback('');
                    }}
                    className="flex-1 py-1.5 bg-blue-900/30 text-blue-400 border border-blue-500/20 hover:bg-blue-800/40 rounded-lg text-center text-xs font-bold transition cursor-pointer"
                    id={`edit_plan_btn_${p.id}`}
                  >
                    Edit Plan / Photo
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Are you sure you want to retire and delete the "${p.name}" plan?`)) {
                        adminDeleteProduct(p.id);
                      }
                    }}
                    className="p-1.5 bg-rose-950/30 text-rose-400 border border-rose-500/20 hover:bg-rose-900/40 rounded-lg transition cursor-pointer"
                    title="Retire Plan"
                    id={`delete_plan_btn_${p.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        </>
      )}

      {/* RESOLVING SUPPORT TICKETS */}
      {activeTab === 'tickets' && (
        <div className="space-y-4" id="admin_tickets_panel">
          <h3 className="text-xs font-black tracking-widest text-slate-400 uppercase mb-3">
            OPEN USER SUPPORT INQUIRIES ({openTickets.length})
          </h3>

          {openTickets.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-900/20 border border-white/5 text-center text-slate-500 text-sm" id="no_unresolved_tickets">
              <CheckCircle className="w-10 h-10 mx-auto text-slate-600 mb-2" />
              <p>Great! All user support queries have been answered.</p>
            </div>
          ) : (
            <div className="space-y-4" id="open_tickets_list">
              {openTickets.map((tk) => {
                const isAnswering = answeringTicketId === tk.id;
                return (
                  <div key={tk.id} className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-950 border border-white/10 space-y-3 text-xs" id={`admin_ticket_card_${tk.id}`}>
                    <div className="flex justify-between items-center border-b border-white/5 pb-2" id={`tk_card_hdr_${tk.id}`}>
                      <div>
                        <span className="font-bold text-white block">+{tk.countryCode || '256'} {tk.userPhone} ({tk.subject})</span>
                        <span className="text-[10px] text-slate-500 mt-0.5 block">Ticket ID: {tk.id} • Submitted: {new Date(tk.createdAt).toLocaleDateString()}</span>
                      </div>
                      <span className="px-1.5 py-0.5 rounded bg-amber-500/10 text-[#d4af37] text-[8px] font-bold uppercase border border-amber-500/20">Open Ticket</span>
                    </div>

                    <p className="text-slate-300 font-light bg-black/20 p-3 rounded-lg border border-white/5">{tk.message}</p>

                    {/* Replies count */}
                    {tk.replies.length > 0 && (
                      <div className="space-y-1 pl-4 border-l-2 border-white/10" id={`tk_replies_box_${tk.id}`}>
                        {tk.replies.map(rep => (
                          <div key={rep.id} className="text-[11px] text-slate-400">
                            <span className="font-bold uppercase tracking-wider text-[9px] text-[#d4af37]">{rep.sender}:</span> {rep.message}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Action toggler */}
                    {!isAnswering ? (
                      <button
                        onClick={() => setAnsweringTicketId(tk.id)}
                        className="py-1.5 px-3 bg-blue-700 hover:bg-blue-600 rounded-lg text-white font-bold text-[10px] uppercase cursor-pointer"
                        id={`btn_answer_toggle_${tk.id}`}
                      >
                        REPLY TO TICKET
                      </button>
                    ) : (
                      <div className="space-y-3 pt-2" id={`tk_reply_form_box_${tk.id}`}>
                        <input
                          type="text"
                          placeholder="Type answer to customer..."
                          value={replyMsg}
                          onChange={e => setReplyMsg(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs text-white"
                          id={`tk_reply_input_${tk.id}`}
                          required
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleSendTicketReply(tk.id)}
                            className="py-2 px-4 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-[10px] uppercase cursor-pointer"
                            id={`btn_submit_reply_${tk.id}`}
                          >
                            TRANSMIT REPLY
                          </button>
                          <button
                            onClick={() => { setAnsweringTicketId(null); setReplyMsg(''); }}
                            className="py-2 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-[10px] uppercase cursor-pointer"
                            id={`btn_cancel_reply_${tk.id}`}
                          >
                            CANCEL
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* GIFT CODES / VOUCHERS CREATION */}
      {activeTab === 'vouchers' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8" id="admin_vouchers_panel">
          
          {/* Create voucher form */}
          <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 text-left space-y-4" id="create_voucher_form_card">
            <h3 className="text-sm font-extrabold text-white uppercase border-b border-white/5 pb-2 flex items-center gap-2">
              <Gift className="w-5 h-5 text-amber-500 animate-pulse" />
              GENERATE PROMOTIONAL VOUCHERS
            </h3>

            {voucherFeedback && <p className="text-xs font-bold text-emerald-400">{voucherFeedback}</p>}

            <form onSubmit={handleCreateVoucher} className="space-y-4" id="voucher_generate_form">
              <div>
                <label className="block text-[10px] font-bold text-slate-300 mb-1">VOUCHER TEXT CODE (UPPERCASE)</label>
                <input
                  type="text"
                  placeholder="E.g. BELVMEMBER"
                  value={voucherCode}
                  onChange={e => setVoucherCode(e.target.value.toUpperCase())}
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white uppercase tracking-wider font-mono font-bold"
                  id="add_vouch_code"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3" id="add_vouch_row">
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">CASH REWARD (UGX)</label>
                  <input
                    type="number"
                    placeholder="E.g. 20000"
                    value={voucherAmt}
                    onChange={e => setVoucherAmt(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white font-mono"
                    id="add_vouch_amt"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-300 mb-1">USAGE REDEEM LIMIT</label>
                  <input
                    type="number"
                    placeholder="E.g. 50"
                    value={voucherLimit}
                    onChange={e => setVoucherLimit(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 px-4 text-xs text-white font-mono"
                    id="add_vouch_limit"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#d4af37] hover:bg-[#b5952d] text-black font-extrabold text-xs uppercase rounded-xl cursor-pointer"
                id="add_vouch_submit"
              >
                CREATE SECURE GIFT CODE
              </button>
            </form>
          </div>

          {/* List existing voucher codes */}
          <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 text-left space-y-4 flex flex-col justify-between" id="existing_vouchers_card">
            
            <div className="space-y-4" id="vouchers_list_body">
              <h3 className="text-sm font-extrabold text-white uppercase border-b border-white/5 pb-2">
                ACTIVE REDEEMABLE VOUCHERS
              </h3>

              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1" id="vouchers_inner_scroll">
                {giftCodes.map((code) => (
                  <div key={code.code} className="p-3 bg-black/30 rounded-xl border border-white/5 flex justify-between items-center text-xs" id={`vouch_row_${code.code}`}>
                    <div>
                      <span className="font-mono font-bold text-[#d4af37] text-sm tracking-wider">{code.code}</span>
                      <span className="text-[10px] text-slate-500 block mt-1">Reward: UGX {code.reward.toLocaleString()} • Limits: {code.uses} / {code.maxUses} Claims</span>
                    </div>

                    <button
                      onClick={() => adminDeleteGiftCode(code.code)}
                      className="p-2 text-rose-400 hover:text-rose-300 cursor-pointer"
                      title="Delete Voucher Code"
                      id={`del_vouch_${code.code}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* SUPABASE CONNECTION & SCHEMA PANELS */}
      {activeTab === 'supabase' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in text-left font-sans" id="admin_supabase_panel">
          
          {/* Left Column: Connection status and sync actions */}
          <div className="space-y-6" id="supabase_conn_col">
            <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 space-y-4" id="supabase_connection_card">
              <h3 className="text-sm font-extrabold text-white uppercase border-b border-b-white/5 pb-2 flex items-center gap-2">
                <Database className="w-5 h-5 text-[#d4af37]" />
                DATABASE CONNECTION STATUS
              </h3>
              
              <div className="flex items-start gap-4 p-4 bg-black/40 rounded-xl border border-white/5" id="supabase_status_indicator">
                <div className={`p-3 rounded-full ${supabaseStatus.connected && supabaseStatus.missingTables.length === 0 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/10 text-[#d4af37] border border-amber-500/30'} flex-shrink-0`}>
                  <CloudLightning className="w-5 h-5 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-300">INTEGRATION ENGINE</div>
                  <div className="text-sm font-extrabold text-white">{supabaseStatus.connected ? 'ACTIVE CONNECTION' : 'DISCONNECTED'}</div>
                  <p className="text-xs text-slate-400 mt-1">{supabaseStatus.message}</p>
                </div>
              </div>

              {/* Server connection details */}
              <div className="space-y-2 text-xs" id="supabase_details_box">
                <div className="flex justify-between items-center py-2 border-b border-white/5 font-sans">
                  <span className="text-slate-400">Project Name:</span>
                  <span className="font-mono font-bold text-slate-200">DEMO</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-white/5 font-sans">
                  <span className="text-slate-400">Project ID:</span>
                  <span className="font-mono font-bold text-slate-200 text-right">texodiaxoffmirssnham</span>
                </div>
                <div className="flex flex-col gap-1 py-2 border-b border-white/5 font-sans">
                  <span className="text-slate-400">Project Endpoint:</span>
                  <span className="font-mono font-bold text-slate-300 text-xs break-all bg-black/20 p-1.5 rounded border border-white/5">https://texodiaxoffmirssnham.supabase.co</span>
                </div>
              </div>

              {/* Connection trigger buttons */}
              <div className="grid grid-cols-2 gap-3 pt-2 font-sans" id="supabase_btn_grid">
                <button
                  onClick={() => refreshSupabaseStatus()}
                  className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-extrabold text-xs uppercase rounded-xl border border-white/5 cursor-pointer flex items-center justify-center gap-2 transition"
                  id="btn_refresh_supabase"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>REFRESH</span>
                </button>
                <button
                  onClick={async () => {
                    setExporting(true);
                    setExportMessage('');
                    const res = await triggerExportToSupabase();
                    setExporting(false);
                    setExportMessage(res.message);
                    if (res.success) {
                      refreshSupabaseStatus();
                    }
                  }}
                  disabled={exporting || !supabaseStatus.connected}
                  className={`py-2.5 px-4 font-extrabold text-xs uppercase rounded-xl cursor-pointer flex items-center justify-center gap-2 transition ${
                    supabaseStatus.connected 
                      ? 'bg-[#d4af37] hover:bg-[#b5952d] text-black' 
                      : 'bg-slate-800 text-slate-500 border border-white/5 cursor-not-allowed'
                  }`}
                  id="btn_export_supabase"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>{exporting ? 'EXPORTING...' : 'EXPORT LOCAL'}</span>
                </button>
              </div>

              {exportMessage && (
                <div className={`p-3 rounded-xl border text-xs text-center font-sans font-semibold mt-2 ${exportMessage.includes('successfully') ? 'bg-emerald-950/40 text-emerald-400 border-emerald-500/20' : 'bg-rose-950/40 text-rose-400 border-rose-500/20'}`}>
                  {exportMessage}
                </div>
              )}
            </div>

            {/* Table verification checklist */}
            <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 space-y-4" id="supabase_tables_card">
              <h3 className="text-sm font-extrabold text-white uppercase border-b border-b-white/5 pb-2">
                VERIFIED DATABASE TABLES
              </h3>
              <p className="text-xs text-slate-400 font-sans">
                The synchronized client maps active state variables to the following tables. Checked tables exist in your Supabase DB.
              </p>

              <div className="grid grid-cols-1 gap-2 pt-1 font-sans" id="supabase_tables_grid">
                {[
                  { name: 'bel_users', desc: 'Saves client profiles, Uganda wallets, & refer counts' },
                  { name: 'bel_products', desc: 'Lists beverage plans available for active buying' },
                  { name: 'bel_investments', desc: 'Tracks investment payout days remaining' },
                  { name: 'bel_transactions', desc: 'Stores transactions audits for deposits/claims' },
                  { name: 'bel_tickets', desc: 'Preserves interactive customer support chat records' },
                  { name: 'bel_announcements', desc: 'Publishes global news board broadcasts' },
                  { name: 'bel_gift_codes', desc: 'Maintains redeemable high-reward voucher codes' },
                ].map(tbl => {
                  const isMissing = supabaseStatus.missingTables.includes(tbl.name);
                  const isVerified = supabaseStatus.connected && !isMissing;
                  return (
                    <div key={tbl.name} className="flex justify-between items-center p-3 bg-black/20 rounded-xl border border-white/5 text-xs">
                      <div className="space-y-0.5">
                        <span className="font-mono font-extrabold text-slate-200">{tbl.name}</span>
                        <span className="text-[10px] text-slate-500 block">{tbl.desc}</span>
                      </div>
                      <div>
                        {isVerified ? (
                          <span className="px-2 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-[9px] font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-1">
                            <Check className="w-3 h-3" /> VERIFIED
                          </span>
                        ) : supabaseStatus.connected ? (
                          <span className="px-2 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-[9px] font-bold text-[#d4af37] uppercase tracking-widest flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" /> MISSING
                          </span>
                        ) : (
                          <span className="px-2 py-1 rounded bg-slate-800 border border-white/5 text-[9px] font-bold text-slate-500 uppercase tracking-widest">
                            UNCHECKED
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: SQL Schema setup instructions */}
          <div className="space-y-6 animate-fade-in" id="supabase_setup_col">
            <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 flex flex-col h-full justify-between space-y-4" id="supabase_schema_setup_card">
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-b-white/5 pb-2">
                  <h3 className="text-sm font-extrabold text-white uppercase flex items-center gap-2">
                    <FileText className="w-5 h-5 text-[#d4af37]" />
                    SUPABASE SQL DDL SCHEMA
                  </h3>
                  
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="py-1.5 px-3 bg-white/5 hover:bg-white/10 text-xs font-bold text-[#d4af37] uppercase rounded-lg border border-white/5 cursor-pointer flex items-center gap-1.5 transition"
                    id="btn_copy_sql"
                  >
                    {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'COPIED!' : 'COPY SQL'}</span>
                  </button>
                </div>

                <p className="text-xs text-slate-400 font-sans">
                  Execute this SQL script inside your Supabase Dashboard SQL Editor to instantly provision all database tables, configure RLS, and seed drink plans:
                </p>

                <div className="relative bg-black/60 rounded-xl border border-white/10 p-4 font-mono text-[10px] text-slate-300 h-[380px] overflow-y-auto" id="sql_schema_snippet_pane">
                  <pre className="text-left whitespace-pre">{SUPABASE_SQL_SCHEMA}</pre>
                </div>
              </div>

              <div className="p-4 bg-amber-500/5 rounded-xl border border-amber-500/10 text-xs text-amber-300 flex items-start gap-2.5 font-sans" id="sql_schema_notice">
                <AlertTriangle className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5 animate-pulse" />
                <p className="leading-relaxed">
                  Important: Running this schema sets up Row Level Security (RLS) policies allowing public read/write access. It also populates the base `bel_products` drink items so they appear instantly on the breweries dashboard!
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
