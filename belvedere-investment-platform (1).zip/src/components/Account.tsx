/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { useAppState } from '../state/StateContext';
import { 
  CreditCard, 
  DollarSign, 
  Calendar, 
  ChevronRight, 
  X, 
  Lock, 
  ShieldAlert, 
  CheckCircle, 
  Bot, 
  Send, 
  Activity, 
  Beer,
  User,
  Smartphone
} from 'lucide-react';

interface AccountProps {
  onNavigate: (tab: string) => void;
}

// Mini Budweiser-style Beer Can Vector SVG
const MiniBeerCanSVG: React.FC = () => (
  <svg className="w-5.5 h-5.5 shrink-0 filter drop-shadow-[0_1px_2px_rgba(0,0,0,0.15)]" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Can body */}
    <rect x="7" y="4" width="10" height="16" rx="2.5" fill="#C8102E" />
    {/* Can top lid */}
    <ellipse cx="12" cy="4" rx="5" ry="1.5" fill="#E2E8F0" />
    <ellipse cx="12" cy="4" rx="3.5" ry="1" fill="#94A3B8" />
    {/* Can bottom base */}
    <ellipse cx="12" cy="20" rx="5" ry="1.5" fill="#94A3B8" />
    {/* Label silver/white diagonal strip */}
    <path d="M7 8 L17 11 V13 L7 10 Z" fill="#F8FAFC" opacity="0.95" />
    {/* Red/gold tiny logo dot */}
    <circle cx="12" cy="11.5" r="1.5" fill="#D4AF37" />
  </svg>
);

export const Account: React.FC<AccountProps> = ({ onNavigate }) => {
  const { currentUser, transactions, investments, adminResetUserPassword, logout } = useAppState();

  // Active sub-drawers/modals
  const [activeModal, setActiveModal] = useState<'none' | 'records' | 'purchased' | 'about' | 'rules' | 'bank' | 'security' | 'ai'>('none');

  // Bank account settings stored locally
  const [bankPhone, setBankPhone] = useState(() => {
    return localStorage.getItem('bud_bank_phone') || currentUser?.phone || '';
  });
  const [bankProvider, setBankProvider] = useState(() => {
    return localStorage.getItem('bud_bank_provider') || 'MTN';
  });
  const [bankSuccess, setBankSuccess] = useState('');

  // Password reset states
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passSuccess, setPassSuccess] = useState('');
  const [passError, setPassError] = useState('');

  // AI Concierge assistant states
  const [assistantMessages, setAssistantMessages] = useState([
    { role: 'assistant', text: 'Greetings, Belvedere VIP Investor! I am your server-side Gemini AI concierge. Ask me how to maximize your daily dividends, check your referral commission rates, or verify mobile money withdrawal cycles.' }
  ]);
  const [assistantQuery, setAssistantQuery] = useState('');
  const [isAssistantTyping, setIsAssistantTyping] = useState(false);
  const assistantEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll assistant chat
  useEffect(() => {
    if (activeModal === 'ai') {
      assistantEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [assistantMessages, isAssistantTyping, activeModal]);

  if (!currentUser) return null;

  // Handle Bank Update
  const handleBankUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('bud_bank_phone', bankPhone);
    localStorage.setItem('bud_bank_provider', bankProvider);
    setBankSuccess('Mobile money banking details saved successfully!');
    setTimeout(() => {
      setBankSuccess('');
      setActiveModal('none');
    }, 1500);
  };

  // Change password handler
  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    setPassError('');
    setPassSuccess('');

    if (!newPassword || newPassword.length < 4) {
      setPassError('Password must be at least 4 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPassError('Passwords do not match.');
      return;
    }

    adminResetUserPassword(currentUser.id, newPassword);
    localStorage.setItem(`pass_${currentUser.id}`, newPassword);

    setPassSuccess('Security Password changed successfully!');
    setNewPassword('');
    setConfirmPassword('');
    setTimeout(() => {
      setPassSuccess('');
      setActiveModal('none');
    }, 1500);
  };

  const handleSendAssistantQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assistantQuery.trim() || isAssistantTyping) return;

    const userMsg = assistantQuery.trim();
    setAssistantQuery('');
    setAssistantMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsAssistantTyping(true);

    try {
      const response = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: userMsg })
      });
      if (response.ok) {
        const data = await response.json();
        setAssistantMessages(prev => [...prev, { role: 'assistant', text: data.reply }]);
      } else {
        setAssistantMessages(prev => [...prev, { role: 'assistant', text: 'Communication links are busy. Please try again shortly.' }]);
      }
    } catch (err) {
      setAssistantMessages(prev => [...prev, { role: 'assistant', text: 'Network exception. Please check connection.' }]);
    } finally {
      setIsAssistantTyping(false);
    }
  };

  // Extract records
  const myInvestments = investments.filter(i => i.userId === currentUser.id);
  const myRecharges = transactions.filter(t => t.userId === currentUser.id && t.type === 'recharge');
  const myWithdrawals = transactions.filter(t => t.userId === currentUser.id && t.type === 'withdraw');

  return (
    <div className="w-full max-w-lg mx-auto px-0 pt-0 pb-24 space-y-4 text-slate-800 font-sans" id="bud_account_container">
      
      {/* 1. White Action Buttons Panel */}
      <div className="px-4 pt-3" id="account_top_controls">
        <div className="bg-white rounded-xl py-4 px-2 shadow-md grid grid-cols-3 gap-1 border border-slate-100" id="deposit_withdraw_records_bar">
          
          {/* Online Deposit */}
          <button
            onClick={() => {
              localStorage.setItem('payout_active_tab', 'recharge');
              onNavigate('payout');
            }}
            className="flex flex-col items-center justify-center text-center cursor-pointer active:scale-95 transition-all"
            id="account_btn_deposit"
          >
            <CreditCard className="w-6 h-6 text-[#C8102E] mb-1.5" />
            <span className="text-[11px] font-bold text-slate-700">Online deposit</span>
          </button>

          {/* Withdraw Money */}
          <button
            onClick={() => {
              localStorage.setItem('payout_active_tab', 'withdraw');
              onNavigate('payout');
            }}
            className="flex flex-col items-center justify-center text-center cursor-pointer active:scale-95 transition-all"
            id="account_btn_withdraw"
          >
            <div className="w-6 h-6 rounded-full border-2 border-[#C8102E] flex items-center justify-center text-[#C8102E] font-black text-xs mb-1.5">
              $
            </div>
            <span className="text-[11px] font-bold text-slate-700">Withdraw money</span>
          </button>

          {/* Account Records */}
          <button
            onClick={() => setActiveModal('records')}
            className="flex flex-col items-center justify-center text-center cursor-pointer active:scale-95 transition-all"
            id="account_btn_records"
          >
            <Calendar className="w-6 h-6 text-[#C8102E] mb-1.5" />
            <span className="text-[11px] font-bold text-slate-700">Account records</span>
          </button>

        </div>
      </div>

      {/* 2. Double Status Red Cards (Same as Dashboard for layout fidelity) */}
      <div className="px-4" id="account_balance_cards_holder">
        <div className="grid grid-cols-2 gap-4" id="account_balance_grid">
          
          {/* Left: Account Balance */}
          <div className="relative overflow-hidden bg-gradient-to-br from-red-600 to-red-700 rounded-2xl p-4 text-left shadow-lg text-white" id="account_balance_card">
            <div className="absolute right-2 bottom-2 text-white/10">
              <svg className="w-16 h-16 transform rotate-12" viewBox="0 0 24 24" fill="currentColor">
                <path d="M2 5 L6 13 L12 6 L18 13 L22 5 L17 19 H7 L2 5 Z" />
              </svg>
            </div>
            <span className="text-[10px] text-white/80 font-bold tracking-widest uppercase block">
              Account balance
            </span>
            <span className="text-[17px] font-extrabold text-white mt-1 block">
              UGX {currentUser.balance.toLocaleString()}
            </span>
          </div>

          {/* Right: Cumulative Income */}
          <div className="relative overflow-hidden bg-gradient-to-br from-red-600 to-red-700 rounded-2xl p-4 text-left shadow-lg text-white" id="account_income_card">
            <div className="absolute right-2 bottom-2 text-white/10">
              <svg className="w-16 h-16 transform rotate-12" viewBox="0 0 24 24" fill="currentColor">
                <path d="M2 5 L6 13 L12 6 L18 13 L22 5 L17 19 H7 L2 5 Z" />
              </svg>
            </div>
            <span className="text-[10px] text-white/80 font-bold tracking-widest uppercase block">
              Cumulative income
            </span>
            <span className="text-[17px] font-extrabold text-white mt-1 block">
              UGX {currentUser.totalRevenue.toLocaleString()}
            </span>
          </div>

        </div>
      </div>

      {/* 3. Vertical White Menu Items list */}
      <div className="px-4" id="account_menu_container">
        <div className="bg-white rounded-xl shadow-md border border-slate-100 overflow-hidden divide-y divide-slate-100" id="mine_menu_list">
          
          {/* Item 1: The product you purchased */}
          <button
            onClick={() => setActiveModal('purchased')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_purchased_products"
          >
            <div className="flex items-center gap-3">
              <MiniBeerCanSVG />
              <span className="text-sm font-semibold text-slate-700">The product you purchased</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Item 2: Daily wage plan */}
          <button
            onClick={() => onNavigate('income')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_daily_wage"
          >
            <div className="flex items-center gap-3">
              <MiniBeerCanSVG />
              <span className="text-sm font-semibold text-slate-700">Daily wage plan</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Item 3: Gift code */}
          <button
            onClick={() => onNavigate('gift_center')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_gift_code"
          >
            <div className="flex items-center gap-3">
              <MiniBeerCanSVG />
              <span className="text-sm font-semibold text-slate-700">Gift code</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Item 4: About Us */}
          <button
            onClick={() => setActiveModal('about')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_about_us"
          >
            <div className="flex items-center gap-3">
              <MiniBeerCanSVG />
              <span className="text-sm font-semibold text-slate-700">About Us</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Item 5: Platform rules */}
          <button
            onClick={() => setActiveModal('rules')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_platform_rules"
          >
            <div className="flex items-center gap-3">
              <MiniBeerCanSVG />
              <span className="text-sm font-semibold text-slate-700">Platform rules</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Item 6: Customer service */}
          <button
            onClick={() => onNavigate('chat_support')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_customer_service"
          >
            <div className="flex items-center gap-3">
              <MiniBeerCanSVG />
              <span className="text-sm font-semibold text-slate-700">Customer service</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Item 7: Bank account management */}
          <button
            onClick={() => setActiveModal('bank')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_bank_management"
          >
            <div className="flex items-center gap-3">
              <MiniBeerCanSVG />
              <span className="text-sm font-semibold text-slate-700">Bank account management</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Extra: Advanced Security */}
          <button
            onClick={() => setActiveModal('security')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_security_passwords"
          >
            <div className="flex items-center gap-3">
              <MiniBeerCanSVG />
              <span className="text-sm font-semibold text-slate-700">Reset password</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Extra: Talk to Gemini AI Concierge */}
          <button
            onClick={() => setActiveModal('ai')}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-slate-50 cursor-pointer transition-all"
            id="item_ai_concierge"
          >
            <div className="flex items-center gap-3 text-[#C8102E]">
              <Bot className="w-5.5 h-5.5 text-[#C8102E]" />
              <span className="text-sm font-bold">Talk to Belvedere AI Concierge</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Item 8: Exit the application */}
          <button
            onClick={() => logout()}
            className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-red-50 cursor-pointer transition-all"
            id="item_exit_app"
          >
            <div className="flex items-center gap-3 text-red-600">
              <MiniBeerCanSVG />
              <span className="text-sm font-bold">Exit the application</span>
            </div>
            <ChevronRight className="w-4 h-4 text-red-500" />
          </button>

        </div>
      </div>

      {/* --- ALL DYNAMIC MODALS AND DRAWERS --- */}
      {activeModal !== 'none' && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-end justify-center font-sans" id="account_dialog_overlay">
          <div className="w-full max-w-lg bg-white rounded-t-3xl p-5 space-y-4 max-h-[85vh] overflow-y-auto shadow-2xl relative text-left" id="account_dialog_box">
            
            {/* Header close */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3" id="dialog_header">
              <h3 className="text-base font-extrabold text-slate-800 uppercase tracking-wide">
                {activeModal === 'records' && 'Account Records History'}
                {activeModal === 'purchased' && 'Your Purchased Products'}
                {activeModal === 'about' && 'About Belvedere Investment'}
                {activeModal === 'rules' && 'Official Platform Rules'}
                {activeModal === 'bank' && 'Mobile Money Accounts'}
                {activeModal === 'security' && 'Modify Password Security'}
                {activeModal === 'ai' && 'Belvedere AI Concierge (Gemini)'}
              </h3>
              <button 
                onClick={() => {
                  setActiveModal('none');
                  setPassError('');
                  setPassSuccess('');
                  setBankSuccess('');
                }}
                className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer"
                id="dialog_close_btn"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            {/* Content: Account Records */}
            {activeModal === 'records' && (
              <div className="space-y-4" id="records_content">
                <div className="grid grid-cols-2 gap-2 text-xs" id="records_summary">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10px] text-slate-500 font-bold block">TOTAL RECHARGED</span>
                    <span className="text-sm font-bold text-slate-800 mt-1 block">UGX {currentUser.rechargeAmount.toLocaleString()}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10px] text-slate-500 font-bold block">TOTAL WITHDRAWN</span>
                    <span className="text-sm font-bold text-slate-800 mt-1 block">UGX {currentUser.withdrawAmount.toLocaleString()}</span>
                  </div>
                </div>

                <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1" id="records_list">
                  {transactions.filter(t => t.userId === currentUser.id).length === 0 ? (
                    <div className="py-12 text-center text-slate-400 font-bold">No transaction records logged yet.</div>
                  ) : (
                    transactions.filter(t => t.userId === currentUser.id).map(tx => (
                      <div key={tx.id} className="p-3 rounded-xl border border-slate-100 bg-slate-50 flex justify-between items-center text-xs" id={`tx_record_${tx.id}`}>
                        <div>
                          <span className="font-bold text-slate-700 capitalize">{tx.type} via {tx.paymentMethod || 'Mobile Money'}</span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">{new Date(tx.createdAt).toLocaleString()}</span>
                        </div>
                        <div className="text-right">
                          <span className={`font-bold block ${tx.type === 'recharge' ? 'text-blue-600' : 'text-red-600'}`}>
                            {tx.type === 'recharge' ? '+' : '-'}UGX {tx.amount.toLocaleString()}
                          </span>
                          <span className="text-[9px] text-slate-500 font-mono block mt-0.5 uppercase">{tx.status}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Content: Purchased Products */}
            {activeModal === 'purchased' && (
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1" id="purchased_content">
                {myInvestments.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 font-bold">You haven't purchased any Belvedere contracts yet. Go to the Product tab to buy!</div>
                ) : (
                  myInvestments.map(inv => {
                    const progress = Math.min(100, Math.max(0, ((inv.cycleDays - inv.daysRemaining) / inv.cycleDays) * 100));
                    return (
                      <div key={inv.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50 space-y-3 text-xs" id={`purchased_item_${inv.id}`}>
                        <div className="flex justify-between items-center">
                          <h4 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
                            <Beer className="w-4 h-4 text-red-600 animate-pulse" />
                            {inv.productName}
                          </h4>
                          <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 border border-emerald-200 text-[9px] font-bold uppercase rounded">
                            {inv.status}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-slate-600 text-[11px]" id="purchased_item_details">
                          <div>Purchase Price: <span className="font-bold text-slate-800 font-mono">UGX {inv.purchasePrice.toLocaleString()}</span></div>
                          <div>Daily Return: <span className="font-bold text-red-600 font-mono">UGX {inv.dailyEarnings.toLocaleString()}</span></div>
                          <div>Maturation Cycle: <span className="font-bold text-slate-800">{inv.cycleDays} Days</span></div>
                          <div>Remaining Term: <span className="font-bold text-slate-800">{inv.daysRemaining} Days</span></div>
                        </div>
                        <div className="space-y-1">
                          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                            <div className="bg-red-600 h-full rounded-full" style={{ width: `${progress}%` }} />
                          </div>
                          <span className="text-[9px] text-slate-400 font-bold block text-right">Cycle progress: {Math.round(progress)}%</span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* Content: About Us */}
            {activeModal === 'about' && (
              <div className="space-y-3 text-xs text-slate-600 leading-relaxed text-left" id="about_content">
                <div className="w-full flex justify-center py-2">
                  <MiniBeerCanSVG />
                </div>
                <p>
                  Welcome to <strong>Belvedere Investment</strong>, a premium fractional-ownership network that operates in cooperation with elite regional beverage wholesale distributors.
                </p>
                <p>
                  Every contract purchased is linked to real-world beverage stock batches and active dispatch lines. This allows participants to receive secure, automated daily dividends straight to their spendable account balance, backing community-driven trade optimization.
                </p>
                <p>
                  All transactions are audited directly in Uganda Shillings (UGX) with immediate carrier settlement for continuous, secure, and long-term passive yields.
                </p>
              </div>
            )}

            {/* Content: Platform Rules */}
            {activeModal === 'rules' && (
              <div className="space-y-3 text-xs text-slate-600 leading-relaxed text-left" id="rules_content">
                <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-800 font-bold mb-2">
                  Please review the official operational terms carefully to prevent settlement delays.
                </div>
                <ul className="list-disc pl-4 space-y-2">
                  <li><strong>Minimum Limits:</strong> Minimum recharge is UGX 5,000. Minimum withdrawal cashout is UGX 5,000.</li>
                  <li><strong>Processing Hours:</strong> Recharges are processed instantly via instant push. Withdrawals are settled within 2 to 24 hours daily.</li>
                  <li><strong>Withdrawal Fee:</strong> A standard 10% banking processing fee is applicable on all cashouts.</li>
                  <li><strong>Dividends Timing:</strong> Daily earnings accrue exactly 24 hours after plan acquisition. Claim manually from your Dashboard!</li>
                  <li><strong>Referral Bonuses:</strong> Level 1 refers earn 25%, Level 2 refers earn 3%, Level 3 refers earn 2% commission instantly credited to your spendable ledger.</li>
                </ul>
              </div>
            )}

            {/* Content: Bank account management */}
            {activeModal === 'bank' && (
              <form onSubmit={handleBankUpdate} className="space-y-4 text-xs text-left" id="bank_form">
                {bankSuccess && (
                  <div className="p-2 bg-emerald-50 text-emerald-700 font-bold rounded-lg text-center" id="bank_feedback">
                    {bankSuccess}
                  </div>
                )}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Select Carrier Mobile Money Network</label>
                  <select
                    value={bankProvider}
                    onChange={e => setBankProvider(e.target.value)}
                    className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 outline-none text-slate-800 font-bold"
                    id="select_bank_provider"
                  >
                    <option value="MTN">MTN Uganda Mobile Money</option>
                    <option value="Airtel">Airtel Uganda Mobile money</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Recipient Phone Number (For Cashout Payouts)</label>
                  <div className="relative flex items-center bg-slate-50 border border-slate-200 focus-within:border-red-500/50 rounded-xl">
                    <span className="pl-3 pr-2 text-slate-400 font-bold border-r border-slate-200 select-none">+256</span>
                    <input
                      type="tel"
                      value={bankPhone}
                      onChange={e => setBankPhone(e.target.value.replace(/\D/g, ''))}
                      className="w-full bg-transparent py-3 pl-2 pr-8 text-slate-800 outline-none font-bold"
                      placeholder="763273733"
                      id="input_bank_phone"
                      required
                    />
                    <Smartphone className="absolute right-3 text-slate-400 w-4 h-4" />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#C8102E] text-white font-extrabold rounded-xl tracking-wider text-xs uppercase cursor-pointer"
                  id="btn_save_bank"
                >
                  Save Account Settings
                </button>
              </form>
            )}

            {/* Content: Security resetting */}
            {activeModal === 'security' && (
              <form onSubmit={handlePasswordChange} className="space-y-4 text-xs text-left" id="pass_form">
                {passSuccess && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-center font-bold" id="pass_success_box">
                    {passSuccess}
                  </div>
                )}
                {passError && (
                  <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-center font-bold" id="pass_error_box">
                    {passError}
                  </div>
                )}

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">New Account Password</label>
                  <div className="relative flex items-center bg-slate-50 border border-slate-200 rounded-xl">
                    <input
                      type="password"
                      placeholder="At least 4 characters"
                      value={newPassword}
                      onChange={e => setNewPassword(e.target.value)}
                      className="w-full bg-transparent py-3 pl-3 pr-8 text-slate-800 outline-none"
                      id="pass_input_dialog_new"
                      required
                    />
                    <Lock className="absolute right-3 text-slate-400 w-4 h-4" />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Confirm New Password</label>
                  <div className="relative flex items-center bg-slate-50 border border-slate-200 rounded-xl">
                    <input
                      type="password"
                      placeholder="Repeat new password"
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      className="w-full bg-transparent py-3 pl-3 pr-8 text-slate-800 outline-none"
                      id="pass_input_dialog_confirm"
                      required
                    />
                    <Lock className="absolute right-3 text-slate-400 w-4 h-4" />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#C8102E] text-white font-extrabold rounded-xl tracking-wider text-xs uppercase cursor-pointer"
                  id="btn_submit_dialog_pass"
                >
                  Apply Security Encodings
                </button>
              </form>
            )}

            {/* Content: AI Concierge assistant */}
            {activeModal === 'ai' && (
              <div className="space-y-4 text-xs text-left" id="ai_concierge_dialog">
                <div className="h-64 overflow-y-auto space-y-3 pr-1 text-xs" id="ai_msg_scroller">
                  {assistantMessages.map((msg, idx) => (
                    <div 
                      key={idx} 
                      className={`flex gap-2.5 max-w-[85%] ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
                      id={`ai_msg_item_${idx}`}
                    >
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-sm ${
                        msg.role === 'user' ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-[#C8102E]'
                      }`}>
                        {msg.role === 'user' ? '👤' : '🤖'}
                      </div>
                      <div className={`p-3 rounded-2xl leading-normal text-slate-700 ${
                        msg.role === 'user' 
                          ? 'bg-blue-50 border border-blue-100 rounded-tr-none' 
                          : 'bg-slate-100 border border-slate-200 rounded-tl-none'
                      }`}>
                        {msg.text}
                      </div>
                    </div>
                  ))}

                  {isAssistantTyping && (
                    <div className="flex gap-2.5 max-w-[80%] items-center" id="ai_typing">
                      <div className="w-7 h-7 rounded-full bg-red-100 text-[#C8102E] flex items-center justify-center">🤖</div>
                      <div className="p-3 bg-slate-100 border border-slate-200 rounded-2xl rounded-tl-none text-slate-500 flex items-center gap-2">
                        <Activity className="w-3.5 h-3.5 text-red-600 animate-spin" />
                        <span>Concierge is typing...</span>
                      </div>
                    </div>
                  )}
                  <div ref={assistantEndRef} />
                </div>

                <form onSubmit={handleSendAssistantQuery} className="flex gap-2 border-t border-slate-100 pt-3" id="ai_concierge_form">
                  <input
                    type="text"
                    placeholder="Ask about active interest rates or payout models..."
                    value={assistantQuery}
                    onChange={e => setAssistantQuery(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-slate-800 outline-none focus:border-red-500/40 text-xs"
                    id="ai_dialog_input"
                    required
                  />
                  <button
                    type="submit"
                    disabled={isAssistantTyping || !assistantQuery.trim()}
                    className="px-4 bg-[#C8102E] text-white rounded-xl flex items-center justify-center disabled:opacity-50 cursor-pointer active:scale-95 transition-all"
                    id="ai_dialog_submit"
                  >
                    Send
                  </button>
                </form>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
