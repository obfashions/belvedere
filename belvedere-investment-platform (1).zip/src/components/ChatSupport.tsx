/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../state/StateContext';
import { MessageSquare, Send, CheckCircle, HelpCircle, ShieldAlert, ChevronRight, MessageCircle } from 'lucide-react';

export const ChatSupport: React.FC = () => {
  const { tickets, createTicket, replyToTicket, currentUser } = useAppState();

  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  
  // Create ticket states
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [ticketSuccess, setTicketSuccess] = useState('');
  const [ticketError, setTicketError] = useState('');

  // Reply states
  const [replyMsg, setReplyMsg] = useState('');

  if (!currentUser) return null;

  // Filter tickets belonging to this user
  const myTickets = tickets.filter(t => t.userId === currentUser.id);
  const activeTicket = tickets.find(t => t.id === activeTicketId);

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    setTicketError('');
    setTicketSuccess('');

    if (!subject.trim() || !message.trim()) {
      setTicketError('Subject and detailed message are required.');
      return;
    }

    const res = createTicket(subject, message);
    if (res.success) {
      setTicketSuccess('Your ticket has been logged successfully! The customer support team will reply within 5 minutes.');
      setSubject('');
      setMessage('');
    } else {
      setTicketError(res.error || 'Failed to open ticket.');
    }
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMsg.trim() || !activeTicketId) return;

    const res = replyToTicket(activeTicketId, replyMsg, 'user');
    if (res.success) {
      setReplyMsg('');

      // Auto simulation: Let the admin respond automatically after 3 seconds for high fidelity!
      const currentId = activeTicketId;
      setTimeout(() => {
        replyToTicket(currentId, 'We have received your message regarding your Belvedere contract. Our financial node is auditing the logs. Please check your balance or payout logs.', 'admin');
      }, 3500);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 pt-2.5 pb-24 space-y-6 text-left" id="chat_support_container">
      
      {/* Title Header */}
      <div id="chat_title_header">
        <span className="text-[10px] font-black tracking-widest text-[#d4af37] uppercase bg-[#d4af37]/10 px-2.5 py-1 rounded">SERVICE TICKETS</span>
        <h2 className="text-2xl font-bold tracking-tight text-white mt-2">
          Announcements & Built-in Support Chat
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Open secure service requests directly with our European asset auditing desks. Track statuses in real-time.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="chat_main_grid">
        
        {/* Left Column: Tickets List */}
        <div className="md:col-span-1 bg-slate-900/40 border border-white/10 rounded-2xl p-4 space-y-4" id="tickets_sidebar">
          <h3 className="text-xs font-black tracking-widest text-slate-400 uppercase border-b border-white/5 pb-2">
            YOUR SUPPORT TICKETS
          </h3>

          {myTickets.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs font-semibold" id="no_tickets">
              No tickets found. Submit a query on the right to start a dialogue.
            </div>
          ) : (
            <div className="space-y-2 max-h-[400px] overflow-y-auto" id="tickets_list">
              {myTickets.map((t) => {
                const isActive = t.id === activeTicketId;
                return (
                  <button
                    key={t.id}
                    onClick={() => setActiveTicketId(t.id)}
                    className={`w-full p-3 rounded-xl border text-left text-xs flex flex-col justify-between gap-1.5 transition cursor-pointer ${
                      isActive 
                        ? 'bg-[#112a5c] border-blue-500/40 text-white' 
                        : 'bg-black/30 border-white/5 text-slate-300 hover:border-white/10'
                    }`}
                    id={`ticket_btn_${t.id}`}
                  >
                    <div className="flex justify-between items-center w-full">
                      <span className="font-bold tracking-wide truncate max-w-[120px]">{t.subject}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase ${t.status === 'open' ? 'bg-amber-500/10 text-[#d4af37] border border-amber-500/20' : 'bg-slate-800 text-slate-400'}`}>
                        {t.status}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 block truncate">{t.message}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column: Active chat thread or Ticket Creation */}
        <div className="md:col-span-2 bg-slate-900/40 border border-white/10 rounded-2xl p-5 flex flex-col justify-between min-h-[450px]" id="tickets_chat_panel">
          {activeTicket ? (
            // Chat active dialogue block
            <div className="flex flex-col justify-between h-full space-y-4" id="chat_dialogue_panel">
              {/* Header */}
              <div className="flex justify-between items-center border-b border-white/5 pb-3" id="chat_hdr">
                <div>
                  <h4 className="font-bold text-white text-sm">RE: {activeTicket.subject}</h4>
                  <span className="text-[9px] text-slate-500">Ticket ID: {activeTicket.id} • Registered: {new Date(activeTicket.createdAt).toLocaleDateString()}</span>
                </div>
                <button
                  onClick={() => setActiveTicketId(null)}
                  className="text-[10px] text-blue-400 font-bold hover:underline"
                  id="close_chat_thread"
                >
                  BACK TO CREATE TICKET
                </button>
              </div>

              {/* Message scroll thread */}
              <div className="flex-1 space-y-4 overflow-y-auto max-h-[300px] pr-2 text-xs flex flex-col" id="chat_scroll_thread">
                {/* Seed Initial Query */}
                <div className="bg-[#112a5c]/30 border border-blue-500/10 rounded-xl p-3 max-w-[85%] self-start text-left" id="seed_query">
                  <span className="text-[9px] font-bold text-blue-400 uppercase tracking-widest block mb-1">Your query</span>
                  <p className="text-slate-200">{activeTicket.message}</p>
                  <span className="text-[8px] text-slate-500 block text-right mt-1">{new Date(activeTicket.createdAt).toLocaleTimeString()}</span>
                </div>

                {/* Replies list */}
                {activeTicket.replies.map((rep) => {
                  const isAdmin = rep.sender === 'admin';
                  return (
                    <div
                      key={rep.id}
                      className={`rounded-xl p-3 max-w-[85%] text-left ${
                        isAdmin
                          ? 'bg-[#d4af37]/10 border border-[#d4af37]/20 self-end text-slate-200'
                          : 'bg-[#112a5c]/30 border border-blue-500/10 self-start text-slate-200'
                      }`}
                      id={`reply_${rep.id}`}
                    >
                      <span className={`text-[9px] font-bold uppercase tracking-widest block mb-1 ${isAdmin ? 'text-[#d4af37]' : 'text-blue-400'}`}>
                        {isAdmin ? 'Belvedere Auditor (Support)' : 'You'}
                      </span>
                      <p>{rep.message}</p>
                      <span className="text-[8px] text-slate-500 block text-right mt-1">{new Date(rep.createdAt).toLocaleTimeString()}</span>
                    </div>
                  );
                })}
              </div>

              {/* Send input box */}
              <form onSubmit={handleSendReply} className="flex gap-2 pt-3 border-t border-white/5" id="chat_reply_form">
                <input
                  type="text"
                  placeholder="Type secure response..."
                  value={replyMsg}
                  onChange={e => setReplyMsg(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs text-white outline-none focus:border-blue-500/40"
                  id="chat_reply_input"
                  required
                />
                <button
                  type="submit"
                  className="p-3 bg-blue-700 hover:bg-blue-600 border border-blue-500/20 rounded-xl text-white flex items-center justify-center cursor-pointer shrink-0"
                  id="btn_send_reply"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          ) : (
            // Create ticket form
            <div className="space-y-4" id="ticket_creator_panel">
              <div className="border-b border-white/5 pb-3" id="create_ticket_hdr">
                <h4 className="font-bold text-white text-sm">Submit New Support Query</h4>
                <p className="text-[10px] text-slate-400 mt-1">Our technical assistance desks are online 24/7. Response times average under 5 minutes.</p>
              </div>

              {ticketSuccess && (
                <div className="p-4 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-200 flex gap-3" id="ticket_success">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{ticketSuccess}</span>
                </div>
              )}

              {ticketError && (
                <div className="p-4 bg-red-950/40 border border-red-500/30 rounded-xl text-xs text-red-300 flex gap-3" id="ticket_error">
                  <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                  <span>{ticketError}</span>
                </div>
              )}

              <form onSubmit={handleCreateTicket} className="space-y-4" id="new_ticket_form">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">SUBJECT TITLE</label>
                  <input
                    type="text"
                    placeholder="E.g. Recharge Delay, Withdrawal Inquiry, Commission question"
                    value={subject}
                    onChange={e => setSubject(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs text-white outline-none focus:border-blue-500/40"
                    id="new_ticket_subject"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">DETAILED ENQUIRY MESSAGE</label>
                  <textarea
                    rows={5}
                    placeholder="Describe your issue with transacting or plans in details. Include any mobile money numbers or reference numbers."
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs text-white outline-none focus:border-blue-500/40"
                    id="new_ticket_msg"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-gradient-to-r from-blue-700 to-[#102a5c] border border-blue-500/20 rounded-xl text-xs font-bold tracking-widest text-white uppercase hover:shadow-lg transition cursor-pointer"
                  id="submit_new_ticket"
                >
                  TRANSMIT QUERY TICKET
                </button>
              </form>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
