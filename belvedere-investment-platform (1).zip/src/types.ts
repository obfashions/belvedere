/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  phone: string; // Used as username, e.g. "763273733"
  countryCode: string; // Default "+256"
  balance: number; // Account Balance (available for withdrawal/buying plans)
  incomeBalance: number; // Income earned from plans, can be accumulated or transferred to balance
  rechargeAmount: number;
  withdrawAmount: number;
  dailyEarnings: number;
  referralEarnings: number;
  teamEarnings: number;
  totalRevenue: number;
  referralCode: string;
  referredBy?: string; // Referral code of the person who invited this user
  level1Count: number;
  level2Count: number;
  level3Count: number;
  isFrozen: boolean;
  isAdmin: boolean;
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  price: number; // Investment Amount in UGX
  cycleDays: number; // Duration of investment in days
  dailyReturnPercent: number; // Daily return rate e.g. 16.67%
  dailyEarnings: number; // System-calculated (price * dailyReturnPercent / 100)
  totalEarnings: number; // System-calculated (dailyEarnings * cycleDays)
  roi: number; // System-calculated ROI percentage
  imageUrl: string;
  description: string;
}

export interface Investment {
  id: string;
  userId: string;
  productId: string;
  productName: string;
  purchasePrice: number;
  dailyEarnings: number;
  totalEarnings: number;
  cycleDays: number;
  daysRemaining: number;
  nextPayoutTime: string; // ISO String (Exactly 24 hours from purchase, then updates)
  lastPayoutTime?: string; // To track daily limits
  purchaseTime: string; // Earnings start 24 hours after purchase
  status: 'active' | 'expired';
}

export interface Transaction {
  id: string;
  userId: string;
  userPhone: string;
  type: 'recharge' | 'withdraw' | 'earnings' | 'commission' | 'gift' | 'spin_win';
  amount: number;
  fee: number; // For withdrawals
  netAmount: number; // For withdrawals (amount - fee)
  status: 'pending' | 'completed' | 'rejected';
  paymentMethod?: string; // e.g. "MTN Mobile Money", "Airtel Money"
  txRef?: string; // LWorx reference placeholder
  description: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userPhone: string;
  subject: string;
  message: string;
  status: 'open' | 'closed';
  createdAt: string;
  replies: TicketReply[];
}

export interface TicketReply {
  id: string;
  sender: 'user' | 'admin';
  message: string;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  isPinned: boolean;
  createdAt: string;
}

export interface GiftCode {
  id: string;
  code: string;
  rewardAmount: number;
  usageLimit: number;
  usageCount: number;
  claimedBy: string[]; // User IDs who have claimed this code
  createdAt: string;
}

export interface SpinReward {
  id: string;
  name: string; // e.g. "UGX 5,000 Cash", "Belvedere Pure Plan", "Try Again"
  type: 'cash' | 'product' | 'none';
  value: number; // Cash amount or plan ID
  probability: number; // Probability weight
  color: string;
}

export interface LiveActivity {
  id: string;
  phone: string;
  type: 'recharge' | 'withdraw' | 'investment';
  amount: number;
  timeAgo: string;
}
