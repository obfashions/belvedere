/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { StateProvider, useAppState } from './state/StateContext';
import { LuxuryBackground, BelvedereLogo } from './components/Branding';
import { RegistrationLanding } from './components/RegistrationLanding';
import { Dashboard } from './components/Dashboard';
import { Breweries } from './components/Breweries';
import { Income } from './components/Income';
import { Invite } from './components/Invite';
import { Payout } from './components/Payout';
import { GiftCenter } from './components/GiftCenter';
import { ChatSupport } from './components/ChatSupport';
import { Account } from './components/Account';
import { AdminPanel } from './components/AdminPanel';
import { LiveChatSupport } from './components/LiveChatSupport';
import { 
  Home, 
  Compass, 
  Users, 
  User, 
  ShieldAlert, 
  LogOut, 
  MessageSquare, 
  Beer
} from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentUser, logout } = useAppState();
  const [activeTab, setActiveTab] = useState('dashboard');

  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeTab]);

  // If visitor is not authenticated, lock into Registration Landing
  if (!currentUser) {
    return (
      <div className="relative min-h-screen text-slate-800 flex flex-col justify-start items-center overflow-x-hidden pt-1.5 pb-12" id="unauth_app_gate">
        <LuxuryBackground />
        <div className="relative z-10 w-full animate-fadeIn" id="landing_wrapper">
          <RegistrationLanding onSuccess={() => setActiveTab('dashboard')} />
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen text-slate-800 bg-white font-sans antialiased flex flex-col justify-between" id="auth_app_workspace">
      {/* Dynamic Ambient Background with bubbles and glows */}
      <LuxuryBackground />

      {/* Solid Red Budweiser Header bar */}
      <header className="relative z-40 bg-[#C8102E] shadow-md px-4 py-3" id="app_header_bar">
        <div className="max-w-lg mx-auto flex justify-between items-center" id="app_header_box">
          
          {/* Centered Brand Logo */}
          <div className="flex-1 flex justify-center" id="header_brand_holder">
            <BelvedereLogo compact={true} />
          </div>

          {/* Quick Header Controls (Aligned on right overlay) */}
          <div className="absolute right-4 flex items-center gap-1.5" id="header_controls">
            
            {/* Admin Panel Button - Strictly reserved for phone number 762201984 */}
            {currentUser.phone === '762201984' && (
              <button
                onClick={() => setActiveTab(activeTab === 'admin' ? 'dashboard' : 'admin')}
                className={`px-2.5 py-1 rounded-lg text-[9px] font-black tracking-wider border uppercase transition cursor-pointer flex items-center gap-1 ${
                  activeTab === 'admin'
                    ? 'bg-yellow-500 text-black border-yellow-600'
                    : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
                }`}
                id="global_admin_switch"
                title="Admin Control Center"
              >
                <ShieldAlert className="w-3 h-3" />
                <span>{activeTab === 'admin' ? 'USER' : 'ADMIN'}</span>
              </button>
            )}

            {/* Support ticket shortcut */}
            <button
              onClick={() => setActiveTab('chat_support')}
              className={`p-1.5 rounded-lg border transition cursor-pointer ${
                activeTab === 'chat_support' ? 'bg-white/20 border-white/30 text-white' : 'bg-white/5 border-transparent text-white/80 hover:text-white'
              }`}
              id="shortcut_support_btn"
              title="Help Ticket Center"
            >
              <MessageSquare className="w-4 h-4" />
            </button>

            {/* Header Log out button */}
            <button
              onClick={() => logout()}
              className="p-1.5 rounded-lg bg-black/10 hover:bg-black/25 text-white/90 transition cursor-pointer"
              id="global_logout_btn"
              title="Secure Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

        </div>
      </header>

      {/* Main active frame */}
      <main className="relative z-10 flex-1 flex flex-col justify-start" id="app_main_workspace">
        {activeTab === 'dashboard' && <Dashboard onNavigate={(tab) => setActiveTab(tab)} />}
        {activeTab === 'breweries' && <Breweries />}
        {activeTab === 'income' && <Income onBackToMine={() => setActiveTab('my_account')} />}
        {activeTab === 'invite' && <Invite />}
        {activeTab === 'payout' && <Payout />}
        {activeTab === 'gift_center' && <GiftCenter />}
        {activeTab === 'chat_support' && <ChatSupport />}
        {activeTab === 'my_account' && <Account onNavigate={(tab) => setActiveTab(tab)} />}
        {activeTab === 'admin' && currentUser.phone === '762201984' && <AdminPanel />}
      </main>

      {/* Global Inbuilt Live Chat Support Bubble & Overlay */}
      <LiveChatSupport />

      {/* Persistent Red/Gold Mobile Bottom Navigation Bar matching Screenshots */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-xl border-t border-slate-200/80 py-2.5 px-4 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]" id="app_bottom_navbar">
        <div className="max-w-lg mx-auto flex justify-between items-center" id="nav_links_container">
          
          {/* Home Tab */}
          <button
            onClick={() => setActiveTab('dashboard')}
            className="flex flex-col items-center justify-center flex-1 transition duration-200 cursor-pointer"
            id="nav_btn_dashboard"
          >
            <div className={`p-2 rounded-xl transition-all duration-200 ${
              activeTab === 'dashboard' 
                ? 'bg-[#C8102E] text-white shadow-md shadow-red-600/20' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`} style={{ width: '40px', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Home className="w-5.5 h-5.5" />
            </div>
            <span className={`text-[10px] font-bold mt-1 tracking-wide ${activeTab === 'dashboard' ? 'text-[#C8102E]' : 'text-slate-600'}`}>
              Home
            </span>
          </button>

          {/* Product (Breweries) Tab */}
          <button
            onClick={() => setActiveTab('breweries')}
            className="flex flex-col items-center justify-center flex-1 transition duration-200 cursor-pointer"
            id="nav_btn_breweries"
          >
            <div className={`p-2 rounded-xl transition-all duration-200 ${
              activeTab === 'breweries' 
                ? 'bg-[#C8102E] text-white shadow-md shadow-red-600/20' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`} style={{ width: '40px', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Beer className="w-5.5 h-5.5" />
            </div>
            <span className={`text-[10px] font-bold mt-1 tracking-wide ${activeTab === 'breweries' ? 'text-[#C8102E]' : 'text-slate-600'}`}>
              Product
            </span>
          </button>

          {/* Team (Invite) Tab */}
          <button
            onClick={() => setActiveTab('invite')}
            className="flex flex-col items-center justify-center flex-1 transition duration-200 cursor-pointer"
            id="nav_btn_invite"
          >
            <div className={`p-2 rounded-xl transition-all duration-200 ${
              activeTab === 'invite' 
                ? 'bg-[#C8102E] text-white shadow-md shadow-red-600/20' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`} style={{ width: '40px', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Users className="w-5.5 h-5.5" />
            </div>
            <span className={`text-[10px] font-bold mt-1 tracking-wide ${activeTab === 'invite' ? 'text-[#C8102E]' : 'text-slate-600'}`}>
              Team
            </span>
          </button>

          {/* Mine (Account) Tab */}
          <button
            onClick={() => setActiveTab('my_account')}
            className="flex flex-col items-center justify-center flex-1 transition duration-200 cursor-pointer"
            id="nav_btn_account"
          >
            <div className={`p-2 rounded-xl transition-all duration-200 ${
              activeTab === 'my_account' 
                ? 'bg-[#C8102E] text-white shadow-md shadow-red-600/20' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`} style={{ width: '40px', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <User className="w-5.5 h-5.5" />
            </div>
            <span className={`text-[10px] font-bold mt-1 tracking-wide ${activeTab === 'my_account' ? 'text-[#C8102E]' : 'text-slate-600'}`}>
              Mine
            </span>
          </button>

        </div>
      </nav>
    </div>
  );
};

export default function App() {
  return (
    <StateProvider>
      <AppContent />
    </StateProvider>
  );
}
