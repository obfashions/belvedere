import { supabase } from './supabase';
import { 
  User, 
  Product, 
  Investment, 
  Transaction, 
  SupportTicket, 
  Announcement, 
  GiftCode,
  TicketReply
} from '../types';

// Helper to check if a specific error is a "relation does not exist" error
export function isTableMissingError(error: any): boolean {
  if (!error) return false;
  const errMsg = error.message || '';
  return errMsg.includes('relation') && errMsg.includes('does not exist');
}

// ==========================================
// MAPPINGS: CAMELCASE <=> SNAKE_CASE
// ==========================================

export function mapUserFromDb(row: any): User {
  return {
    id: row.id,
    phone: row.phone,
    countryCode: row.country_code || '+256',
    balance: Number(row.balance ?? 0),
    incomeBalance: Number(row.income_balance ?? 0),
    rechargeAmount: Number(row.recharge_amount ?? 0),
    withdrawAmount: Number(row.withdraw_amount ?? 0),
    dailyEarnings: Number(row.daily_earnings ?? 0),
    referralEarnings: Number(row.referral_earnings ?? 0),
    teamEarnings: Number(row.team_earnings ?? 0),
    totalRevenue: Number(row.total_revenue ?? 0),
    referralCode: row.referral_code,
    referredBy: row.referred_by || undefined,
    level1Count: row.level1_count ?? 0,
    level2Count: row.level2_count ?? 0,
    level3Count: row.level3_count ?? 0,
    isFrozen: !!row.is_frozen,
    isAdmin: !!row.is_admin,
    createdAt: row.created_at || new Date().toISOString()
  };
}

export function mapUserToDb(user: User): any {
  return {
    id: user.id,
    phone: user.phone,
    country_code: user.countryCode,
    balance: user.balance,
    income_balance: user.incomeBalance,
    recharge_amount: user.rechargeAmount,
    withdraw_amount: user.withdrawAmount,
    daily_earnings: user.dailyEarnings,
    referral_earnings: user.referralEarnings,
    team_earnings: user.teamEarnings,
    total_revenue: user.totalRevenue,
    referral_code: user.referralCode,
    referred_by: user.referredBy || null,
    level1_count: user.level1Count,
    level2_count: user.level2Count,
    level3_count: user.level3Count,
    is_frozen: user.isFrozen,
    is_admin: user.isAdmin,
    created_at: user.createdAt
  };
}

export function mapProductFromDb(row: any): Product {
  return {
    id: row.id,
    name: row.name,
    price: Number(row.price ?? 0),
    cycleDays: row.cycle_days ?? 30,
    dailyReturnPercent: Number(row.daily_return_percent ?? 0),
    dailyEarnings: Number(row.daily_earnings ?? 0),
    totalEarnings: Number(row.total_earnings ?? 0),
    roi: Number(row.roi ?? 0),
    imageUrl: row.image_url || '',
    description: row.description || ''
  };
}

export function mapProductToDb(product: Product): any {
  return {
    id: product.id,
    name: product.name,
    price: product.price,
    cycle_days: product.cycleDays,
    daily_return_percent: product.dailyReturnPercent,
    daily_earnings: product.dailyEarnings,
    total_earnings: product.totalEarnings,
    roi: product.roi,
    image_url: product.imageUrl,
    description: product.description
  };
}

export function mapInvestmentFromDb(row: any): Investment {
  return {
    id: row.id,
    userId: row.user_id,
    productId: row.product_id,
    productName: row.product_name,
    purchasePrice: Number(row.purchase_price ?? 0),
    dailyEarnings: Number(row.daily_earnings ?? 0),
    totalEarnings: Number(row.total_earnings ?? 0),
    cycleDays: row.cycle_days ?? 0,
    daysRemaining: row.days_remaining ?? 0,
    nextPayoutTime: row.next_payout_time,
    lastPayoutTime: row.last_payout_time || undefined,
    purchaseTime: row.purchase_time,
    status: row.status as 'active' | 'expired'
  };
}

export function mapInvestmentToDb(inv: Investment): any {
  return {
    id: inv.id,
    user_id: inv.userId,
    product_id: inv.productId,
    product_name: inv.productName,
    purchase_price: inv.purchasePrice,
    daily_earnings: inv.dailyEarnings,
    total_earnings: inv.totalEarnings,
    cycle_days: inv.cycleDays,
    days_remaining: inv.daysRemaining,
    next_payout_time: inv.nextPayoutTime,
    last_payout_time: inv.lastPayoutTime || null,
    purchase_time: inv.purchaseTime,
    status: inv.status
  };
}

export function mapTransactionFromDb(row: any): Transaction {
  return {
    id: row.id,
    userId: row.user_id,
    userPhone: row.user_phone,
    type: row.type,
    amount: Number(row.amount ?? 0),
    fee: Number(row.fee ?? 0),
    netAmount: Number(row.net_amount ?? 0),
    status: row.status,
    paymentMethod: row.payment_method || undefined,
    txRef: row.tx_ref || undefined,
    description: row.description || '',
    createdAt: row.created_at
  };
}

export function mapTransactionToDb(tx: Transaction): any {
  return {
    id: tx.id,
    user_id: tx.userId,
    user_phone: tx.userPhone,
    type: tx.type,
    amount: tx.amount,
    fee: tx.fee,
    net_amount: tx.netAmount,
    status: tx.status,
    payment_method: tx.paymentMethod || null,
    tx_ref: tx.txRef || null,
    description: tx.description,
    created_at: tx.createdAt
  };
}

export function mapTicketFromDb(row: any): SupportTicket {
  let repliesParsed: TicketReply[] = [];
  try {
    if (typeof row.replies === 'string') {
      repliesParsed = JSON.parse(row.replies);
    } else if (Array.isArray(row.replies)) {
      repliesParsed = row.replies;
    }
  } catch (e) {
    console.error('Failed to parse replies json', e);
  }
  return {
    id: row.id,
    userId: row.user_id,
    userPhone: row.user_phone,
    subject: row.subject,
    message: row.message,
    status: row.status || 'open',
    createdAt: row.created_at,
    replies: repliesParsed
  };
}

export function mapTicketToDb(ticket: SupportTicket): any {
  return {
    id: ticket.id,
    user_id: ticket.userId,
    user_phone: ticket.userPhone,
    subject: ticket.subject,
    message: ticket.message,
    status: ticket.status,
    replies: JSON.stringify(ticket.replies),
    created_at: ticket.createdAt
  };
}

export function mapAnnouncementFromDb(row: any): Announcement {
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    isPinned: !!row.is_pinned,
    createdAt: row.created_at
  };
}

export function mapAnnouncementToDb(ann: Announcement): any {
  return {
    id: ann.id,
    title: ann.title,
    content: ann.content,
    is_pinned: ann.isPinned,
    created_at: ann.createdAt
  };
}

export function mapGiftCodeFromDb(row: any): GiftCode {
  let claimedByParsed: string[] = [];
  try {
    if (typeof row.claimed_by === 'string') {
      claimedByParsed = JSON.parse(row.claimed_by);
    } else if (Array.isArray(row.claimed_by)) {
      claimedByParsed = row.claimed_by;
    }
  } catch (e) {
    console.error('Failed to parse claimed_by json', e);
  }
  return {
    id: row.id,
    code: row.code,
    rewardAmount: Number(row.reward_amount ?? 0),
    usageLimit: row.usage_limit ?? 0,
    usageCount: row.usage_count ?? 0,
    claimedBy: claimedByParsed,
    createdAt: row.created_at
  };
}

export function mapGiftCodeToDb(code: GiftCode): any {
  return {
    id: code.id,
    code: code.code,
    reward_amount: code.rewardAmount,
    usage_limit: code.usageLimit,
    usage_count: code.usageCount,
    claimed_by: JSON.stringify(code.claimedBy),
    created_at: code.createdAt
  };
}

// ==========================================
// DB QUERIES & SYNCHRONIZATION
// ==========================================

export interface SupabaseDataState {
  users?: User[];
  products?: Product[];
  investments?: Investment[];
  transactions?: Transaction[];
  tickets?: SupportTicket[];
  announcements?: Announcement[];
  giftCodes?: GiftCode[];
}

export async function checkSupabaseStatus(): Promise<{
  connected: boolean;
  missingTables: string[];
  message: string;
}> {
  const missingTables: string[] = [];
  let connected = false;
  let message = 'Checking connection...';

  try {
    // Attempt simple queries on each table
    const checks = [
      { name: 'bel_users', query: supabase.from('bel_users').select('id').limit(1) },
      { name: 'bel_products', query: supabase.from('bel_products').select('id').limit(1) },
      { name: 'bel_investments', query: supabase.from('bel_investments').select('id').limit(1) },
      { name: 'bel_transactions', query: supabase.from('bel_transactions').select('id').limit(1) },
      { name: 'bel_tickets', query: supabase.from('bel_tickets').select('id').limit(1) },
      { name: 'bel_announcements', query: supabase.from('bel_announcements').select('id').limit(1) },
      { name: 'bel_gift_codes', query: supabase.from('bel_gift_codes').select('id').limit(1) },
    ];

    const results = await Promise.all(checks.map(c => c.query));
    let hasConnectionError = false;
    let firstConnectionError: any = null;

    results.forEach((res, index) => {
      if (res.error) {
        if (isTableMissingError(res.error)) {
          missingTables.push(checks[index].name);
        } else {
          hasConnectionError = true;
          if (!firstConnectionError) {
            firstConnectionError = res.error;
          }
          console.warn(`Supabase offline or unconfigured for ${checks[index].name}:`, res.error.message || res.error);
        }
      }
    });

    if (hasConnectionError) {
      connected = false;
      message = `Supabase integration offline or unconfigured. Falling back to local offline mode. (${firstConnectionError?.message || 'Check credentials'})`;
    } else {
      connected = true;
      if (missingTables.length > 0) {
        message = `Connected, but missing table(s): ${missingTables.join(', ')}. Run the provided schema SQL.`;
      } else {
        message = 'Connected successfully! All tables ready.';
      }
    }
  } catch (err: any) {
    connected = false;
    message = `Failed to connect: ${err?.message || err}`;
  }

  return { connected, missingTables, message };
}

export async function loadAllDataFromSupabase(): Promise<SupabaseDataState> {
  const state: SupabaseDataState = {};

  try {
    // 1. Users
    const uRes = await supabase.from('bel_users').select('*');
    if (!uRes.error && uRes.data) {
      state.users = uRes.data.map(mapUserFromDb);
    }

    // 2. Products
    const pRes = await supabase.from('bel_products').select('*');
    if (!pRes.error && pRes.data) {
      state.products = pRes.data.map(mapProductFromDb);
    }

    // 3. Investments
    const iRes = await supabase.from('bel_investments').select('*');
    if (!iRes.error && iRes.data) {
      state.investments = iRes.data.map(mapInvestmentFromDb);
    }

    // 4. Transactions
    const txRes = await supabase.from('bel_transactions').select('*').order('created_at', { ascending: false });
    if (!txRes.error && txRes.data) {
      state.transactions = txRes.data.map(mapTransactionFromDb);
    }

    // 5. Tickets
    const ticketRes = await supabase.from('bel_tickets').select('*');
    if (!ticketRes.error && ticketRes.data) {
      state.tickets = ticketRes.data.map(mapTicketFromDb);
    }

    // 6. Announcements
    const annRes = await supabase.from('bel_announcements').select('*');
    if (!annRes.error && annRes.data) {
      state.announcements = annRes.data.map(mapAnnouncementFromDb);
    }

    // 7. Gift Codes
    const gcRes = await supabase.from('bel_gift_codes').select('*');
    if (!gcRes.error && gcRes.data) {
      state.giftCodes = gcRes.data.map(mapGiftCodeFromDb);
    }

  } catch (err) {
    console.warn('Error loading state from Supabase:', err);
  }

  return state;
}

// Single item database synchronization methods
export async function dbSaveUser(user: User): Promise<boolean> {
  try {
    const payload = mapUserToDb(user);
    const { error } = await supabase.from('bel_users').upsert(payload);
    return !error;
  } catch (e) {
    return false;
  }
}

export async function dbDeleteUser(userId: string): Promise<boolean> {
  try {
    const { error } = await supabase.from('bel_users').delete().eq('id', userId);
    return !error;
  } catch (e) {
    return false;
  }
}

export async function dbSaveInvestment(inv: Investment): Promise<boolean> {
  try {
    const payload = mapInvestmentToDb(inv);
    const { error } = await supabase.from('bel_investments').upsert(payload);
    return !error;
  } catch (e) {
    return false;
  }
}

export async function dbSaveTransaction(tx: Transaction): Promise<boolean> {
  try {
    const payload = mapTransactionToDb(tx);
    const { error } = await supabase.from('bel_transactions').upsert(payload);
    return !error;
  } catch (e) {
    return false;
  }
}

export async function dbSaveTicket(ticket: SupportTicket): Promise<boolean> {
  try {
    const payload = mapTicketToDb(ticket);
    const { error } = await supabase.from('bel_tickets').upsert(payload);
    return !error;
  } catch (e) {
    return false;
  }
}

export async function dbSaveAnnouncement(ann: Announcement): Promise<boolean> {
  try {
    const payload = mapAnnouncementToDb(ann);
    const { error } = await supabase.from('bel_announcements').upsert(payload);
    return !error;
  } catch (e) {
    return false;
  }
}

export async function dbSaveGiftCode(code: GiftCode): Promise<boolean> {
  try {
    const payload = mapGiftCodeToDb(code);
    const { error } = await supabase.from('bel_gift_codes').upsert(payload);
    return !error;
  } catch (e) {
    return false;
  }
}

export async function dbSaveProduct(product: Product): Promise<boolean> {
  try {
    const payload = mapProductToDb(product);
    const { error } = await supabase.from('bel_products').upsert(payload);
    return !error;
  } catch (e) {
    return false;
  }
}

export async function dbDeleteProduct(productId: string): Promise<boolean> {
  try {
    const { error } = await supabase.from('bel_products').delete().eq('id', productId);
    return !error;
  } catch (e) {
    return false;
  }
}

// Bulk exports local to database
export async function exportLocalDataToSupabase(localState: {
  users: User[];
  products: Product[];
  investments: Investment[];
  transactions: Transaction[];
  tickets: SupportTicket[];
  announcements: Announcement[];
  giftCodes: GiftCode[];
}): Promise<{ success: boolean; message: string }> {
  try {
    // 1. Export users
    if (localState.users.length > 0) {
      const usersPayload = localState.users.map(mapUserToDb);
      const { error } = await supabase.from('bel_users').upsert(usersPayload);
      if (error) return { success: false, message: `Failed to export users: ${error.message}` };
    }

    // 2. Export products
    if (localState.products.length > 0) {
      const productsPayload = localState.products.map(mapProductToDb);
      const { error } = await supabase.from('bel_products').upsert(productsPayload);
      if (error) return { success: false, message: `Failed to export products: ${error.message}` };
    }

    // 3. Export investments
    if (localState.investments.length > 0) {
      const investmentsPayload = localState.investments.map(mapInvestmentToDb);
      const { error } = await supabase.from('bel_investments').upsert(investmentsPayload);
      if (error) return { success: false, message: `Failed to export investments: ${error.message}` };
    }

    // 4. Export transactions
    if (localState.transactions.length > 0) {
      const transactionsPayload = localState.transactions.map(mapTransactionToDb);
      const { error } = await supabase.from('bel_transactions').upsert(transactionsPayload);
      if (error) return { success: false, message: `Failed to export transactions: ${error.message}` };
    }

    // 5. Export tickets
    if (localState.tickets.length > 0) {
      const ticketsPayload = localState.tickets.map(mapTicketToDb);
      const { error } = await supabase.from('bel_tickets').upsert(ticketsPayload);
      if (error) return { success: false, message: `Failed to export tickets: ${error.message}` };
    }

    // 6. Export announcements
    if (localState.announcements.length > 0) {
      const announcementsPayload = localState.announcements.map(mapAnnouncementToDb);
      const { error } = await supabase.from('bel_announcements').upsert(announcementsPayload);
      if (error) return { success: false, message: `Failed to export announcements: ${error.message}` };
    }

    // 7. Export gift codes
    if (localState.giftCodes.length > 0) {
      const giftCodesPayload = localState.giftCodes.map(mapGiftCodeToDb);
      const { error } = await supabase.from('bel_gift_codes').upsert(giftCodesPayload);
      if (error) return { success: false, message: `Failed to export gift codes: ${error.message}` };
    }

    return { success: true, message: 'All local data successfully exported to Supabase!' };
  } catch (err: any) {
    return { success: false, message: `Export exception: ${err?.message || err}` };
  }
}
