export const SUPABASE_SQL_SCHEMA = `-- PostgreSQL SQL DDL Schema for Belvedere UGX Portfolio (Supabase)
-- Copy and paste this directly into your Supabase SQL Editor (https://supabase.com) and click "Run".

-- 1. Create bel_users table
CREATE TABLE IF NOT EXISTS bel_users (
  id TEXT PRIMARY KEY,
  phone TEXT UNIQUE NOT NULL,
  country_code TEXT DEFAULT '+256',
  balance NUMERIC DEFAULT 5000,
  income_balance NUMERIC DEFAULT 0,
  recharge_amount NUMERIC DEFAULT 0,
  withdraw_amount NUMERIC DEFAULT 0,
  daily_earnings NUMERIC DEFAULT 0,
  referral_earnings NUMERIC DEFAULT 0,
  team_earnings NUMERIC DEFAULT 0,
  total_revenue NUMERIC DEFAULT 5000,
  referral_code TEXT UNIQUE NOT NULL,
  referred_by TEXT,
  level1_count INTEGER DEFAULT 0,
  level2_count INTEGER DEFAULT 0,
  level3_count INTEGER DEFAULT 0,
  is_frozen BOOLEAN DEFAULT FALSE,
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS & Policies for bel_users
ALTER TABLE bel_users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read/write access for users" ON bel_users;
CREATE POLICY "Allow public read/write access for users" ON bel_users FOR ALL USING (true) WITH CHECK (true);

-- 2. Create bel_products table
CREATE TABLE IF NOT EXISTS bel_products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price NUMERIC NOT NULL,
  cycle_days INTEGER NOT NULL,
  daily_return_percent NUMERIC NOT NULL,
  daily_earnings NUMERIC NOT NULL,
  total_earnings NUMERIC NOT NULL,
  roi NUMERIC NOT NULL,
  image_url TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bel_products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read/write access for products" ON bel_products;
CREATE POLICY "Allow public read/write access for products" ON bel_products FOR ALL USING (true) WITH CHECK (true);

-- 3. Create bel_investments table
CREATE TABLE IF NOT EXISTS bel_investments (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES bel_users(id) ON DELETE CASCADE,
  product_id TEXT,
  product_name TEXT NOT NULL,
  purchase_price NUMERIC NOT NULL,
  daily_earnings NUMERIC NOT NULL,
  total_earnings NUMERIC NOT NULL,
  cycle_days INTEGER NOT NULL,
  days_remaining INTEGER NOT NULL,
  next_payout_time TIMESTAMPTZ NOT NULL,
  last_payout_time TIMESTAMPTZ,
  purchase_time TIMESTAMPTZ DEFAULT NOW(),
  status TEXT DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bel_investments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read/write access for investments" ON bel_investments;
CREATE POLICY "Allow public read/write access for investments" ON bel_investments FOR ALL USING (true) WITH CHECK (true);

-- 4. Create bel_transactions table
CREATE TABLE IF NOT EXISTS bel_transactions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  user_phone TEXT NOT NULL,
  type TEXT NOT NULL, -- 'recharge' | 'withdraw' | 'earnings' | 'commission' | 'gift' | 'spin_win'
  amount NUMERIC NOT NULL,
  fee NUMERIC DEFAULT 0,
  net_amount NUMERIC NOT NULL,
  status TEXT DEFAULT 'pending', -- 'pending' | 'completed' | 'rejected'
  payment_method TEXT,
  tx_ref TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bel_transactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read/write access for transactions" ON bel_transactions;
CREATE POLICY "Allow public read/write access for transactions" ON bel_transactions FOR ALL USING (true) WITH CHECK (true);

-- 5. Create bel_tickets table
CREATE TABLE IF NOT EXISTS bel_tickets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  user_phone TEXT NOT NULL,
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT DEFAULT 'open', -- 'open' | 'closed'
  replies JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bel_tickets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read/write access for tickets" ON bel_tickets;
CREATE POLICY "Allow public read/write access for tickets" ON bel_tickets FOR ALL USING (true) WITH CHECK (true);

-- 6. Create bel_announcements table
CREATE TABLE IF NOT EXISTS bel_announcements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  is_pinned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bel_announcements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read/write access for announcements" ON bel_announcements;
CREATE POLICY "Allow public read/write access for announcements" ON bel_announcements FOR ALL USING (true) WITH CHECK (true);

-- 7. Create bel_gift_codes table
CREATE TABLE IF NOT EXISTS bel_gift_codes (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  reward_amount NUMERIC NOT NULL,
  usage_limit INTEGER NOT NULL,
  usage_count INTEGER DEFAULT 0,
  claimed_by JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bel_gift_codes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public read/write access for gift codes" ON bel_gift_codes;
CREATE POLICY "Allow public read/write access for gift codes" ON bel_gift_codes FOR ALL USING (true) WITH CHECK (true);

-- 8. Seed Default Products
INSERT INTO bel_products (id, name, price, cycle_days, daily_return_percent, daily_earnings, total_earnings, roi, image_url, description)
VALUES 
('bel_classic_1', 'Belvedere Classic Plan 1', 15000, 30, 16.67, 2500, 75000, 500, 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=200&auto=format&fit=crop&q=60', 'Start small and witness immediate returns. The entry-level standard for Belvedere lovers.')
ON CONFLICT (id) DO NOTHING;

INSERT INTO bel_products (id, name, price, cycle_days, daily_return_percent, daily_earnings, total_earnings, roi, image_url, description)
VALUES 
('bel_pure_2', 'Belvedere Pure Plan 2', 30000, 35, 18.00, 5400, 189000, 630, 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=200&auto=format&fit=crop&q=60', 'The standard beverage enthusiast plan. Unlock higher daily earnings with a stable cycle duration.')
ON CONFLICT (id) DO NOTHING;

INSERT INTO bel_products (id, name, price, cycle_days, daily_return_percent, daily_earnings, total_earnings, roi, image_url, description)
VALUES 
('bel_reserve_3', 'Belvedere Reserve Plan 3', 70000, 40, 20.00, 14000, 560000, 800, 'https://images.unsplash.com/photo-1527661591475-527312dd65f5?w=200&auto=format&fit=crop&q=60', 'Our premium tier plan designed for maximum consistent returns. Includes double referral commission privileges.')
ON CONFLICT (id) DO NOTHING;
`;
