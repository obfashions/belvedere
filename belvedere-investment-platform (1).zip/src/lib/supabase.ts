import { createClient } from '@supabase/supabase-js';

// Supabase configuration
// Falls back to direct user-provided credentials if environment variables are not yet populated.
const supabaseUrl = (import.meta as any).env?.VITE_SUPABASE_URL || 'https://texodiaxoffmirssnham.supabase.co';
const supabaseAnonKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_secret_30eOcKLyvsBD_bTSLiJ29g_l-5ltv8O';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface SupabaseSyncStatus {
  connected: boolean;
  checked: boolean;
  message: string;
  missingTables: string[];
}
