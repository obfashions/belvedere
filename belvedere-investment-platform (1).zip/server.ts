import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

// Resolve __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json({
  verify: (req: any, _res, buf) => {
    req.rawBody = buf;
  }
}));

// In-memory request and response logs for LWorx Pay
interface ApiLog {
  id: string;
  timestamp: string;
  type: 'deposit' | 'withdrawal';
  endpoint: string;
  requestBody: any;
  responseStatus: number;
  responseBody: any;
  error?: string;
}

const apiLogs: ApiLog[] = [];

// Local in-memory store for local sandbox/offline fallback sync
interface LocalTransaction {
  id: string;
  userId: string;
  type: 'recharge' | 'withdraw';
  amount: number;
  status: 'pending' | 'completed' | 'rejected';
  reference: string;
  description: string;
  updatedAt: string;
}

const localTransactions: LocalTransaction[] = [];
const localUserBalances: Record<string, { balance: number; rechargeAmount: number; withdrawAmount: number }> = {};

const addLog = (log: Omit<ApiLog, 'id' | 'timestamp'>) => {
  apiLogs.unshift({
    id: Math.random().toString(36).substring(2, 9),
    timestamp: new Date().toISOString(),
    ...log
  });
  // Keep only the last 50 logs
  if (apiLogs.length > 50) {
    apiLogs.pop();
  }
};

// API Logs Endpoint
app.get("/api/logs", (req, res) => {
  res.json(apiLogs);
});

// Clear Logs Endpoint
app.post("/api/clear-logs", (req, res) => {
  apiLogs.length = 0;
  res.json({ success: true, message: "Logs cleared successfully." });
});

// GET: Sync local transaction and balance changes for offline sandbox mode
app.get("/api/sync-local-state", (req, res) => {
  const { userId } = req.query;
  if (!userId) {
    return res.status(400).json({ error: "Missing userId" });
  }

  // Auto-cancel pending recharges older than 10 minutes in the backend fallback in-memory store
  const now = Date.now();
  const tenMinutesInMs = 10 * 60 * 1000;
  localTransactions.forEach(t => {
    if (t.userId === userId && t.type === 'recharge' && t.status === 'pending') {
      const updatedAtTime = new Date(t.updatedAt).getTime();
      if (now - updatedAtTime >= tenMinutesInMs) {
        t.status = 'rejected';
        t.description = `${t.description} (Cancelled - 10-minute timeout exceeded)`;
        t.updatedAt = new Date().toISOString();
      }
    }
  });

  const userBalance = localUserBalances[userId as string] || { balance: 0, rechargeAmount: 0, withdrawAmount: 0 };
  const txs = localTransactions.filter(t => t.userId === userId);
  res.json({
    userBalance,
    transactions: txs
  });
});

// LWorx API Keys
const getLworxConfig = () => {
  return {
    apiKey: process.env.LWORX_API_KEY || "lworx_key_live_be62bd15c9594ba29dae3ae9a26773e5",
    merchantId: process.env.LWORX_MERCHANT_ID || "LWORX995510"
  };
};

// POST: Secure Recharge proxy
app.post("/api/recharge", async (req, res) => {
  const { amount, phone, method, reference, userId } = req.body;
  const config = getLworxConfig();

  // Normalize phone number to Ugandan international format starting with 256
  let formattedPhone = phone ? phone.toString().trim() : "";
  if (formattedPhone.startsWith("0")) {
    formattedPhone = "256" + formattedPhone.substring(1);
  } else if (!formattedPhone.startsWith("256") && formattedPhone.length === 9) {
    formattedPhone = "256" + formattedPhone;
  }

  // Determine dynamic callback URL based on the incoming request headers to always point to this active environment
  const proto = req.headers['x-forwarded-proto'] || 'https';
  const host = req.headers['host'] || 'belvedere-platform.com';
  const callbackUrl = `${proto}://${host}/api/lworx-webhook`;

  const payload = {
    merchant_id: config.merchantId,
    account_number: config.merchantId,
    amount: Number(amount),
    currency: "UGX",
    reference: reference,
    external_reference: reference,
    tx_ref: reference,
    customer_phone: formattedPhone,
    phone: formattedPhone,
    callback_url: callbackUrl
  };

  // Register in local in-memory DB for fallback offline synchronization
  const existingLocalIndex = localTransactions.findIndex(t => t.reference === reference);
  if (existingLocalIndex > -1) {
    localTransactions[existingLocalIndex].status = 'pending';
    localTransactions[existingLocalIndex].updatedAt = new Date().toISOString();
  } else {
    localTransactions.push({
      id: Math.random().toString(36).substring(2, 9),
      userId: userId || "local-user",
      type: 'recharge',
      amount: Number(amount),
      status: 'pending',
      reference: reference,
      description: `Recharge via ${method} - LWorx Pay Initiated`,
      updatedAt: new Date().toISOString()
    });
  }

  const endpoints = [
    "https://www.lworx-pay.com/api/lworx-api/collect",
    "https://api.lworx-pay.com/v1/charge",
    "https://payments.relworx.com/api/v1/mobile_money/request_payment",
    "https://api.lworx-pay.com/v1/deposits",
    "https://api.lworxpaysolutions.com/v1/charge",
    "https://www.lworx-pay.com/api/v1/charge"
  ];

  let lastError: any = null;
  let successResponse: any = null;
  let usedEndpoint = "";
  let responseStatus = 0;

  // Try calling the active LWorx Pay endpoints sequentially
  for (const url of endpoints) {
    try {
      usedEndpoint = url;
      const headers = {
        "Authorization": `Bearer ${config.apiKey}`,
        "Content-Type": "application/json"
      };

      console.log(`[LWorx Pay Proxy] Trying deposit of UGX ${amount} via ${formattedPhone} at endpoint: ${url}`);
      
      const response = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify(payload)
      });

      responseStatus = response.status;
      const responseText = await response.text();
      let responseBody: any;
      try {
        responseBody = JSON.parse(responseText);
      } catch {
        responseBody = { raw: responseText };
      }

      if (response.ok) {
        successResponse = responseBody;
      } else {
        lastError = responseBody;
      }

      addLog({
        type: 'deposit',
        endpoint: url,
        requestBody: { ...payload, api_key_masked: config.apiKey.substring(0, 15) + "..." },
        responseStatus,
        responseBody: responseBody || lastError
      });

      if (response.ok) {
        break; // Stop loop on success
      }
    } catch (error: any) {
      console.error(`[LWorx Pay Proxy] Connection Error for endpoint ${url}:`, error);
      lastError = { message: error.message || "Failed to establish network connection to LWorx Pay API" };
      
      addLog({
        type: 'deposit',
        endpoint: url,
        requestBody: { ...payload, api_key_masked: config.apiKey.substring(0, 15) + "..." },
        responseStatus: 500,
        responseBody: null,
        error: error.message
      });
    }
  }

  // Return API response to frontend
  if (successResponse) {
    res.json({
      success: true,
      live: true,
      endpoint: usedEndpoint,
      data: successResponse
    });
  } else {
    // Return failed state strictly when live connection fails
    res.json({
      success: false,
      live: false,
      endpoint: usedEndpoint,
      error: lastError,
      message: "The LWorx Pay live transaction could not be registered on any payment gateway node. Transaction aborted."
    });
  }
});

// POST: Secure Withdraw proxy
app.post("/api/withdraw", async (req, res) => {
  const { amount, phone, method, reference, userId } = req.body;
  const config = getLworxConfig();

  // Normalize phone number to Ugandan international format starting with 256
  let formattedPhone = phone ? phone.toString().trim() : "";
  if (formattedPhone.startsWith("0")) {
    formattedPhone = "256" + formattedPhone.substring(1);
  } else if (!formattedPhone.startsWith("256") && formattedPhone.length === 9) {
    formattedPhone = "256" + formattedPhone;
  }

  // Determine dynamic callback URL based on the incoming request headers to always point to this active environment
  const proto = req.headers['x-forwarded-proto'] || 'https';
  const host = req.headers['host'] || 'belvedere-platform.com';
  const callbackUrl = `${proto}://${host}/api/lworx-webhook`;

  const payload = {
    merchant_id: config.merchantId,
    account_number: config.merchantId,
    amount: Number(amount),
    currency: "UGX",
    reference: reference,
    external_reference: reference,
    tx_ref: reference,
    customer_phone: formattedPhone,
    phone: formattedPhone,
    callback_url: callbackUrl
  };

  // Register in local in-memory DB for fallback offline synchronization
  const existingLocalIndex = localTransactions.findIndex(t => t.reference === reference);
  if (existingLocalIndex > -1) {
    localTransactions[existingLocalIndex].status = 'pending';
    localTransactions[existingLocalIndex].updatedAt = new Date().toISOString();
  } else {
    localTransactions.push({
      id: Math.random().toString(36).substring(2, 9),
      userId: userId || "local-user",
      type: 'withdraw',
      amount: Number(amount),
      status: 'pending',
      reference: reference,
      description: `Withdrawal payout via ${method} to ${phone}`,
      updatedAt: new Date().toISOString()
    });
  }

  const endpoints = [
    "https://www.lworx-pay.com/api/lworx-api/payout",
    "https://api.lworx-pay.com/v1/payout",
    "https://payments.relworx.com/api/v1/mobile_money/send_payment",
    "https://api.lworx-pay.com/v1/withdraws",
    "https://api.lworxpaysolutions.com/v1/payout",
    "https://www.lworx-pay.com/api/v1/payout"
  ];

  let lastError: any = null;
  let successResponse: any = null;
  let usedEndpoint = "";
  let responseStatus = 0;

  for (const url of endpoints) {
    try {
      usedEndpoint = url;
      const headers = {
        "Authorization": `Bearer ${config.apiKey}`,
        "Content-Type": "application/json"
      };

      console.log(`[LWorx Pay Proxy] Trying payout of UGX ${amount} via ${formattedPhone} at endpoint: ${url}`);

      const response = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify(payload)
      });

      responseStatus = response.status;
      const responseText = await response.text();
      let responseBody: any;
      try {
        responseBody = JSON.parse(responseText);
      } catch {
        responseBody = { raw: responseText };
      }

      if (response.ok) {
        successResponse = responseBody;
      } else {
        lastError = responseBody;
      }

      addLog({
        type: 'withdrawal',
        endpoint: url,
        requestBody: { ...payload, api_key_masked: config.apiKey.substring(0, 15) + "..." },
        responseStatus,
        responseBody: responseBody || lastError
      });

      if (response.ok) {
        break; // Stop loop on success
      }
    } catch (error: any) {
      console.error(`[LWorx Pay Proxy] Withdrawal Connection Error for endpoint ${url}:`, error);
      lastError = { message: error.message || "Failed to establish network connection to LWorx Pay API" };

      addLog({
        type: 'withdrawal',
        endpoint: url,
        requestBody: { ...payload, api_key_masked: config.apiKey.substring(0, 15) + "..." },
        responseStatus: 500,
        responseBody: null,
        error: error.message
      });
    }
  }

  if (successResponse) {
    res.json({
      success: true,
      live: true,
      endpoint: usedEndpoint,
      data: successResponse
    });
  } else {
    // Return failed state strictly when live connection fails
    res.json({
      success: false,
      live: false,
      endpoint: usedEndpoint,
      error: lastError,
      message: "The LWorx Pay live withdrawal could not be registered on any payout node. Transaction aborted."
    });
  }
});

// POST: Secure LWorx Webhook Callback
app.post("/api/lworx-webhook", async (req, res) => {
  // 1. Signature Verification
  const signature = req.get('X-LworxPay-Signature') || req.get('x-lworxpay-signature') || '';
  const signingSecret = process.env.LWORX_SIGNING_SECRET || 'whsec_7xutyi816jzr8v7jujushwnv';
  
  if (signature && signingSecret) {
    try {
      const crypto = await import("crypto");
      const rawBody = (req as any).rawBody;
      if (rawBody) {
        const expected = 'sha256=' + crypto.createHmac('sha256', signingSecret).update(rawBody).digest('hex');
        if (signature !== expected) {
          console.error(`[LWorx Webhook] Invalid signature. Expected: ${expected}, Got: ${signature}`);
          return res.status(401).json({ success: false, message: "Invalid webhook signature" });
        }
        console.log(`[LWorx Webhook] Webhook signature verified successfully.`);
      } else {
        console.warn(`[LWorx Webhook] Raw body buffer missing, signature verification bypassed.`);
      }
    } catch (sigErr) {
      console.error("[LWorx Webhook] Signature verification error:", sigErr);
    }
  }

  // 2. Parse payload (support both LWorx { event, data } and flat formats)
  const isNested = req.body && req.body.event && req.body.data;
  const payloadData = isNested ? req.body.data : req.body;
  
  const external_reference = payloadData.external_reference || payloadData.reference || payloadData.merchant_reference;
  const tx_ref = payloadData.tx_ref || payloadData.reference;
  const reference = external_reference || tx_ref;
  
  let status = payloadData.status;
  if (!status && req.body.event) {
    if (req.body.event.endsWith('.success')) {
      status = 'completed';
    } else if (req.body.event.endsWith('.failed')) {
      status = 'failed';
    } else if (req.body.event.endsWith('.pending')) {
      status = 'pending';
    }
  }
  
  const amount = Number(payloadData.amount || 0);
  const state = payloadData.state;

  console.log(`[LWorx Webhook] Received webhook notification. Event: ${req.body.event || 'none'}, Ref: ${reference}, Status: ${status}, Amount: ${amount}`);

  // Log webhook payload
  addLog({
    type: reference && (reference.includes('-OUT-') || reference.includes('-WDR-')) ? 'withdrawal' : 'deposit',
    endpoint: '/api/lworx-webhook',
    requestBody: req.body,
    responseStatus: 200,
    responseBody: { acknowledged: true }
  });

  if (!reference) {
    return res.status(400).json({ success: false, message: "Missing reference" });
  }

  const statusStr = String(status || '').toLowerCase();
  const stateStr = String(state || '').toLowerCase();
  const isCompleted = ['completed', 'success', 'successful', 'approved'].includes(statusStr) || 
                      ['completed', 'success', 'successful', 'approved'].includes(stateStr);
  const isRejected = ['failed', 'rejected', 'error', 'cancelled'].includes(statusStr) || 
                     ['failed', 'rejected', 'error', 'cancelled'].includes(stateStr);

  // Decode user ID and transaction type from reference if encoded
  let extractedUserId: string | null = null;
  let extractedType: 'recharge' | 'withdraw' | null = null;

  if (reference) {
    if (reference.startsWith('LWRX-REC-')) {
      const parts = reference.split('-');
      if (parts.length >= 4) {
        extractedUserId = parts[2];
        extractedType = 'recharge';
      }
    } else if (reference.startsWith('LWRX-WDR-')) {
      const parts = reference.split('-');
      if (parts.length >= 4) {
        extractedUserId = parts[2];
        extractedType = 'withdraw';
      }
    }
  }

  // 1. Update in-memory fallback state
  let localTx = localTransactions.find(t => t.reference === reference);
  if (!localTx && extractedUserId && extractedType) {
    // Auto-create local transaction to handle race condition where client hasn't registered it locally yet
    localTx = {
      id: Math.random().toString(36).substring(2, 9),
      userId: extractedUserId,
      type: extractedType,
      amount: amount || 0,
      status: 'pending',
      reference: reference,
      description: `${extractedType === 'recharge' ? 'Recharge' : 'Withdrawal'} via LWorx Pay - Auto-created`,
      updatedAt: new Date().toISOString()
    };
    localTransactions.push(localTx);
    console.log(`[LWorx Webhook] Auto-created local transaction record in memory fallback.`);
  }

  if (localTx && localTx.status === 'pending') {
    if (isCompleted) {
      localTx.status = 'completed';
      localTx.description = `${localTx.description} - Webhook Verified`;
      
      if (!localUserBalances[localTx.userId]) {
        localUserBalances[localTx.userId] = { balance: 0, rechargeAmount: 0, withdrawAmount: 0 };
      }
      if (localTx.type === 'recharge') {
        localUserBalances[localTx.userId].balance += localTx.amount;
        localUserBalances[localTx.userId].rechargeAmount += localTx.amount;
      }
      console.log(`[LWorx Webhook] Completed transaction and credited balance in-memory for user: ${localTx.userId}`);
    } else if (isRejected) {
      localTx.status = 'rejected';
      localTx.description = `${localTx.description} - Failed via Webhook`;
      
      if (localTx.type === 'withdraw') {
        if (!localUserBalances[localTx.userId]) {
          localUserBalances[localTx.userId] = { balance: 0, rechargeAmount: 0, withdrawAmount: 0 };
        }
        localUserBalances[localTx.userId].balance += localTx.amount;
        localUserBalances[localTx.userId].withdrawAmount = Math.max(0, localUserBalances[localTx.userId].withdrawAmount - localTx.amount);
      }
      console.log(`[LWorx Webhook] Rejected transaction in-memory for user: ${localTx.userId}`);
    }
  }

  // 2. Check if Supabase envs are available and update real database
  const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY;

  if (supabaseUrl && supabaseAnonKey) {
    try {
      const { createClient } = await import("@supabase/supabase-js");
      const supabaseServer = createClient(supabaseUrl, supabaseAnonKey);

      // Find the transaction in the database
      const { data: txData, error: txError } = await supabaseServer
        .from('bel_transactions')
        .select('*')
        .eq('tx_ref', reference);

      const existingTx = txData && txData.length > 0 ? txData[0] : null;

      if (!existingTx) {
        // If transaction not found in database but we have an extracted userId, insert it immediately as completed/rejected
        if (extractedUserId && extractedType) {
          console.log(`[LWorx Webhook] Transaction not found in DB but decoded user ID ${extractedUserId}. Auto-recording transaction...`);
          
          // Get user to get phone number and current balance
          const { data: userData } = await supabaseServer
            .from('bel_users')
            .select('balance, recharge_amount, phone')
            .eq('id', extractedUserId)
            .single();

          if (userData && isCompleted) {
            const txId = Math.random().toString(36).substring(2, 9);
            
            // 1. Insert completed transaction
            await supabaseServer
              .from('bel_transactions')
              .insert({
                id: txId,
                user_id: extractedUserId,
                user_phone: userData.phone,
                type: extractedType,
                amount: amount,
                fee: 0,
                net_amount: amount,
                status: 'completed',
                payment_method: 'LWorx Pay',
                tx_ref: reference,
                description: `Recharge via LWorx Pay - Completed via Webhook (Autorecorded)`,
                created_at: new Date().toISOString()
              });

            // 2. Update user balance
            if (extractedType === 'recharge') {
              const newBalance = Number(userData.balance || 0) + Number(amount);
              const newRecharge = Number(userData.recharge_amount || 0) + Number(amount);
              await supabaseServer
                .from('bel_users')
                .update({ balance: newBalance, recharge_amount: newRecharge })
                .eq('id', extractedUserId);
            }
            console.log(`[LWorx Webhook] Successfully auto-recorded and completed transaction in database.`);
          }
        } else {
          console.warn(`[LWorx Webhook] Transaction not found in database and cannot decode userId from reference: ${reference}`);
        }
      } else if (existingTx.status === 'pending') {
        if (isCompleted) {
          // Complete the transaction
          await supabaseServer
            .from('bel_transactions')
            .update({ status: 'completed', description: `${existingTx.description} - Webhook Verified` })
            .eq('id', existingTx.id);

          // Update user balance if it is a recharge
          if (existingTx.type === 'recharge') {
            const { data: userData } = await supabaseServer
              .from('bel_users')
              .select('balance, recharge_amount')
              .eq('id', existingTx.user_id)
              .single();

            if (userData) {
              const newBalance = Number(userData.balance || 0) + Number(existingTx.amount);
              const newRecharge = Number(userData.recharge_amount || 0) + Number(existingTx.amount);
              await supabaseServer
                .from('bel_users')
                .update({ balance: newBalance, recharge_amount: newRecharge })
                .eq('id', existingTx.user_id);
            }
          }
          console.log(`[LWorx Webhook] Successfully completed transaction ${existingTx.id} via webhook`);
        } else if (isRejected) {
          // Transaction failed
          await supabaseServer
            .from('bel_transactions')
            .update({ status: 'rejected', description: `${existingTx.description} - Failed via Webhook` })
            .eq('id', existingTx.id);

          // If withdrawal failed, refund the money to user's balance
          if (existingTx.type === 'withdraw') {
            const { data: userData } = await supabaseServer
              .from('bel_users')
              .select('balance, withdraw_amount')
              .eq('id', existingTx.user_id)
              .single();

            if (userData) {
              const newBalance = Number(userData.balance || 0) + Number(existingTx.amount);
              const newWithdraw = Math.max(0, Number(userData.withdraw_amount || 0) - Number(existingTx.amount));
              await supabaseServer
                .from('bel_users')
                .update({ balance: newBalance, withdraw_amount: newWithdraw })
                .eq('id', existingTx.user_id);
            }
          }
          console.log(`[LWorx Webhook] Transaction ${existingTx.id} marked rejected/refunded via webhook`);
        }
      }
    } catch (dbErr) {
      console.error("[LWorx Webhook] Database update exception:", dbErr);
    }
  } else {
    console.log("[LWorx Webhook] Supabase keys missing on server, skipping database write.");
  }

  res.status(200).json({ success: true, acknowledged: true });
});

// Initialize Gemini client lazily
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is not defined. AI Assistant will use simulated helpful responses.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// POST: Talk to AI assistant endpoint
app.post("/api/assistant", async (req, res) => {
  const { message, history } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ error: "Message is required." });
  }

  const client = getGeminiClient();

  if (!client) {
    // Elegant fallback simulation
    const simulatedAnswers: Record<string, string> = {
      recharge: "To recharge your balance, tap the 'Recharge' button on the dashboard or 'Recharge Balance' in your Account or Dashboard. Enter the amount in UGX and your Mobile Money number, select MTN or Airtel, then confirm. Recharges are usually approved automatically within 5 minutes.",
      withdraw: "To withdraw, click 'Withdraw' or 'Income Balance' to see your withdrawable funds. Payouts are made directly to MTN or Airtel Mobile Money. Minimum withdrawal is 5,000 UGX, and standard mobile network processing fees apply.",
      invest: "Belvedere products pay secure daily returns! For example, 'Belvedere Midnight Intense' costs UGX 30,000 and yields UGX 5,200 daily for 30 days. Higher plans unlock premium features, including the Daily Sign-In on the Lucky Wheel!",
      wheel: "The Lucky Wheel is located in the Gift Center. Users with higher plans (Midnight Intense or above, i.e., UGX 30,000+) can activate the special 'Daily Sign-In' button for guaranteed daily UGX cash rewards!",
      liquid: "Our premium 'Liquid Background' effect is an aesthetic representation of premium, pure flowing vodka nectar, moving seamlessly to give an elite luxury experience without distracting your browsing.",
      beverage: "To see your purchased items, navigate to the Account tab and check the 'My Products History' panel.",
      password: "To secure your account, go to the Account tab, look for 'Security Controls', enter your new password, and click 'Apply Security Encryptions'."
    };

    const lowercaseMsg = message.toLowerCase();
    let reply = "Hello! I am your Belvedere Luxury Distillery Assistant. I can help you with your account, beverage products, and payouts. How can I assist you today?";
    
    if (lowercaseMsg.includes("recharge") || lowercaseMsg.includes("deposit") || lowercaseMsg.includes("add money")) {
      reply = simulatedAnswers.recharge;
    } else if (lowercaseMsg.includes("withdraw") || lowercaseMsg.includes("cashout") || lowercaseMsg.includes("payout")) {
      reply = simulatedAnswers.withdraw;
    } else if (lowercaseMsg.includes("invest") || lowercaseMsg.includes("product") || lowercaseMsg.includes("plan") || lowercaseMsg.includes("beverage")) {
      reply = simulatedAnswers.invest;
    } else if (lowercaseMsg.includes("wheel") || lowercaseMsg.includes("spin") || lowercaseMsg.includes("sign")) {
      reply = simulatedAnswers.wheel;
    } else if (lowercaseMsg.includes("liquid") || lowercaseMsg.includes("background")) {
      reply = simulatedAnswers.liquid;
    } else if (lowercaseMsg.includes("password") || lowercaseMsg.includes("change")) {
      reply = simulatedAnswers.password;
    }

    return res.json({ reply });
  }

  try {
    const formattedHistory = (history || []).slice(-10).map((msg: any) => ({
      role: msg.sender === 'user' ? 'user' as const : 'model' as const,
      parts: [{ text: msg.message || msg.text || "" }]
    }));

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        ...formattedHistory,
        { role: "user", parts: [{ text: message }] }
      ],
      config: {
        systemInstruction: `You are the official Belvedere Luxury Beverage Distillery Assistant (AI Concierge). 
You help users understand their investments, mobile money recharges, withdraws, and beverage assets on the Belvedere platform. 
The platform pays daily yields in UGX (Ugandan Shillings) for owning fractional shares in premium vodka brands.
Here are the official products and tiers:
1. Belvedere Pure Elegance: price UGX 15,000, returns UGX 2,500 daily.
2. Belvedere Midnight Intense: price UGX 30,000, returns UGX 5,200 daily.
3. Belvedere Organic Citrus: price UGX 70,000, returns UGX 12,600 daily.
4. Belvedere Lake Bartężek Single Rye: price UGX 100,000, returns UGX 18,500 daily.
5. Belvedere Smogóry Forest Single Rye: price UGX 150,000, returns UGX 28,500 daily.
6. Belvedere Heritage 176 Malted: price UGX 300,000, returns UGX 60,000 daily.
7. Belvedere Bespoke Imperial Gold: price UGX 500,000, returns UGX 105,000 daily.
8. Belvedere Luminous Royal Reserve: price UGX 1,000,000, returns UGX 230,000 daily.

A 'higher plan' is any purchased product with a price of UGX 30,000 or more (i.e. Midnight Intense or above). 
Having a higher plan unlocks the Daily Sign-In button on the Lucky Wheel in the Gift Center, which awards a guaranteed bonus of less than UGX 5,000 daily.
Recharges can be done via MTN and Airtel Mobile Money using the 'Recharge Balance' options. Withdrawals require a minimum of UGX 5,000.
Always be professional, polite, and reassuring. Keep replies concise and formatting elegant. Always specify amounts in UGX.`
      }
    });

    res.json({ reply: response.text });
  } catch (err: any) {
    console.error("Gemini Assistant route error:", err);
    res.status(500).json({ error: "Failed to generate AI response", message: err.message });
  }
});

// GET health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "Belvedere Liquid Proxy Gateway", lworxReady: true });
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

if (!process.env.VERCEL && !process.env.NETLIFY) {
  startServer();
}

export default app;
